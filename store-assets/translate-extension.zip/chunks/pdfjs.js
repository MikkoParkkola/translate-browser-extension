const ut = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser"), as = [1e-3, 0, 0, 1e-3, 0, 0], Je = 1.35, bt = {
  ANY: 1,
  DISPLAY: 2,
  PRINT: 4,
  ANNOTATIONS_FORMS: 16,
  ANNOTATIONS_STORAGE: 32,
  ANNOTATIONS_DISABLE: 64,
  IS_EDITING: 128,
  OPLIST: 256
}, Dt = {
  DISABLE: 0,
  ENABLE: 1,
  ENABLE_FORMS: 2,
  ENABLE_STORAGE: 3
}, pe = "pdfjs_internal_editor_", F = {
  DISABLE: -1,
  NONE: 0,
  FREETEXT: 3,
  HIGHLIGHT: 9,
  STAMP: 13,
  INK: 15,
  POPUP: 16,
  SIGNATURE: 101,
  COMMENT: 102
}, N = {
  RESIZE: 1,
  CREATE: 2,
  FREETEXT_SIZE: 11,
  FREETEXT_COLOR: 12,
  FREETEXT_OPACITY: 13,
  INK_COLOR: 21,
  INK_THICKNESS: 22,
  INK_OPACITY: 23,
  HIGHLIGHT_COLOR: 31,
  HIGHLIGHT_THICKNESS: 32,
  HIGHLIGHT_FREE: 33,
  HIGHLIGHT_SHOW_ALL: 34,
  DRAW_STEP: 41
}, ci = {
  PRINT: 4,
  MODIFY_CONTENTS: 8,
  COPY: 16,
  MODIFY_ANNOTATIONS: 32,
  FILL_INTERACTIVE_FORMS: 256,
  COPY_FOR_ACCESSIBILITY: 512,
  ASSEMBLE: 1024,
  PRINT_HIGH_QUALITY: 2048
}, os = {
  TRIANGLES: 1,
  LATTICE: 2
}, rt = {
  FILL: 0,
  STROKE: 1,
  FILL_STROKE: 2,
  INVISIBLE: 3,
  FILL_STROKE_MASK: 3,
  ADD_TO_PATH_FLAG: 4
}, ue = {
  GRAYSCALE_1BPP: 1,
  RGB_24BPP: 2,
  RGBA_32BPP: 3
}, J = {
  TEXT: 1,
  LINK: 2,
  FREETEXT: 3,
  LINE: 4,
  SQUARE: 5,
  CIRCLE: 6,
  POLYGON: 7,
  POLYLINE: 8,
  HIGHLIGHT: 9,
  UNDERLINE: 10,
  SQUIGGLY: 11,
  STRIKEOUT: 12,
  STAMP: 13,
  CARET: 14,
  INK: 15,
  POPUP: 16,
  FILEATTACHMENT: 17,
  SOUND: 18,
  MOVIE: 19,
  WIDGET: 20,
  SCREEN: 21,
  PRINTERMARK: 22,
  TRAPNET: 23,
  WATERMARK: 24,
  THREED: 25,
  REDACT: 26
}, Vt = {
  SOLID: 1,
  DASHED: 2,
  BEVELED: 3,
  INSET: 4,
  UNDERLINE: 5
}, ye = {
  ERRORS: 0,
  WARNINGS: 1,
  INFOS: 5
}, te = {
  dependency: 1,
  setLineWidth: 2,
  setLineCap: 3,
  setLineJoin: 4,
  setMiterLimit: 5,
  setDash: 6,
  setRenderingIntent: 7,
  setFlatness: 8,
  setGState: 9,
  save: 10,
  restore: 11,
  transform: 12,
  moveTo: 13,
  lineTo: 14,
  curveTo: 15,
  curveTo2: 16,
  curveTo3: 17,
  closePath: 18,
  rectangle: 19,
  stroke: 20,
  closeStroke: 21,
  fill: 22,
  eoFill: 23,
  fillStroke: 24,
  eoFillStroke: 25,
  closeFillStroke: 26,
  closeEOFillStroke: 27,
  endPath: 28,
  clip: 29,
  eoClip: 30,
  beginText: 31,
  endText: 32,
  setCharSpacing: 33,
  setWordSpacing: 34,
  setHScale: 35,
  setLeading: 36,
  setFont: 37,
  setTextRenderingMode: 38,
  setTextRise: 39,
  moveText: 40,
  setLeadingMoveText: 41,
  setTextMatrix: 42,
  nextLine: 43,
  showText: 44,
  showSpacedText: 45,
  nextLineShowText: 46,
  nextLineSetSpacingShowText: 47,
  setCharWidth: 48,
  setCharWidthAndBounds: 49,
  setStrokeColorSpace: 50,
  setFillColorSpace: 51,
  setStrokeColor: 52,
  setStrokeColorN: 53,
  setFillColor: 54,
  setFillColorN: 55,
  setStrokeGray: 56,
  setFillGray: 57,
  setStrokeRGBColor: 58,
  setFillRGBColor: 59,
  setStrokeCMYKColor: 60,
  setFillCMYKColor: 61,
  shadingFill: 62,
  beginInlineImage: 63,
  beginImageData: 64,
  endInlineImage: 65,
  paintXObject: 66,
  markPoint: 67,
  markPointProps: 68,
  beginMarkedContent: 69,
  beginMarkedContentProps: 70,
  endMarkedContent: 71,
  beginCompat: 72,
  endCompat: 73,
  paintFormXObjectBegin: 74,
  paintFormXObjectEnd: 75,
  beginGroup: 76,
  endGroup: 77,
  beginAnnotation: 80,
  endAnnotation: 81,
  paintImageMaskXObject: 83,
  paintImageMaskXObjectGroup: 84,
  paintImageXObject: 85,
  paintInlineImageXObject: 86,
  paintInlineImageXObjectGroup: 87,
  paintImageXObjectRepeat: 88,
  paintImageMaskXObjectRepeat: 89,
  paintSolidColorImageMask: 90,
  constructPath: 91,
  setStrokeTransparent: 92,
  setFillTransparent: 93,
  rawFillPath: 94
}, re = {
  moveTo: 0,
  lineTo: 1,
  curveTo: 2,
  quadraticCurveTo: 3,
  closePath: 4
}, di = {
  NEED_PASSWORD: 1,
  INCORRECT_PASSWORD: 2
};
let Be = ye.WARNINGS;
function Qi(d) {
  Number.isInteger(d) && (Be = d);
}
function Ji() {
  return Be;
}
function Ue(d) {
  Be >= ye.INFOS && console.info(`Info: ${d}`);
}
function R(d) {
  Be >= ye.WARNINGS && console.warn(`Warning: ${d}`);
}
function j(d) {
  throw new Error(d);
}
function $(d, t) {
  d || j(t);
}
function Zi(d) {
  switch (d?.protocol) {
    case "http:":
    case "https:":
    case "ftp:":
    case "mailto:":
    case "tel:":
      return !0;
    default:
      return !1;
  }
}
function bs(d, t = null, e = null) {
  if (!d)
    return null;
  if (e && typeof d == "string" && (e.addDefaultProtocol && d.startsWith("www.") && d.match(/\./g)?.length >= 2 && (d = `http://${d}`), e.tryConvertEncoding))
    try {
      d = an(d);
    } catch {
    }
  const s = t ? URL.parse(d, t) : URL.parse(d);
  return Zi(s) ? s : null;
}
function As(d, t, e = !1) {
  const s = URL.parse(d);
  return s ? (s.hash = t, s.href) : e && bs(d, "http://example.com") ? d.split("#", 1)[0] + `${t ? `#${t}` : ""}` : "";
}
function I(d, t, e, s = !1) {
  return Object.defineProperty(d, t, {
    value: e,
    enumerable: !s,
    configurable: !0,
    writable: !1
  }), e;
}
const jt = function() {
  function t(e, s) {
    this.message = e, this.name = s;
  }
  return t.prototype = new Error(), t.constructor = t, t;
}();
class Ns extends jt {
  constructor(t, e) {
    super(t, "PasswordException"), this.code = e;
  }
}
class Ze extends jt {
  constructor(t, e) {
    super(t, "UnknownErrorException"), this.details = e;
  }
}
class Re extends jt {
  constructor(t) {
    super(t, "InvalidPDFException");
  }
}
class ge extends jt {
  constructor(t, e, s) {
    super(t, "ResponseException"), this.status = e, this.missing = s;
  }
}
class tn extends jt {
  constructor(t) {
    super(t, "FormatError");
  }
}
class Lt extends jt {
  constructor(t) {
    super(t, "AbortException");
  }
}
function en(d) {
  (typeof d != "object" || d?.length === void 0) && j("Invalid argument for bytesToString");
  const t = d.length, e = 8192;
  if (t < e)
    return String.fromCharCode.apply(null, d);
  const s = [];
  for (let i = 0; i < t; i += e) {
    const n = Math.min(i + e, t), r = d.subarray(i, n);
    s.push(String.fromCharCode.apply(null, r));
  }
  return s.join("");
}
function He(d) {
  typeof d != "string" && j("Invalid argument for stringToBytes");
  const t = d.length, e = new Uint8Array(t);
  for (let s = 0; s < t; ++s)
    e[s] = d.charCodeAt(s) & 255;
  return e;
}
function sn(d) {
  return String.fromCharCode(d >> 24 & 255, d >> 16 & 255, d >> 8 & 255, d & 255);
}
function nn() {
  const d = new Uint8Array(4);
  return d[0] = 1, new Uint32Array(d.buffer, 0, 1)[0] === 1;
}
function rn() {
  try {
    return new Function(""), !0;
  } catch {
    return !1;
  }
}
class nt {
  static get isLittleEndian() {
    return I(this, "isLittleEndian", nn());
  }
  static get isEvalSupported() {
    return I(this, "isEvalSupported", rn());
  }
  static get isOffscreenCanvasSupported() {
    return I(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
  }
  static get isImageDecoderSupported() {
    return I(this, "isImageDecoderSupported", typeof ImageDecoder < "u");
  }
  static get isFloat16ArraySupported() {
    return I(this, "isFloat16ArraySupported", typeof Float16Array < "u");
  }
  static get isSanitizerSupported() {
    return I(this, "isSanitizerSupported", typeof Sanitizer < "u");
  }
  static get platform() {
    const {
      platform: t,
      userAgent: e
    } = navigator;
    return I(this, "platform", {
      isAndroid: e.includes("Android"),
      isLinux: t.includes("Linux"),
      isMac: t.includes("Mac"),
      isWindows: t.includes("Win"),
      isFirefox: e.includes("Firefox")
    });
  }
  static get isCSSRoundSupported() {
    return I(this, "isCSSRoundSupported", globalThis.CSS?.supports?.("width: round(1.5px, 1px)"));
  }
}
const ts = Array.from(Array(256).keys(), (d) => d.toString(16).padStart(2, "0"));
class T {
  static makeHexColor(t, e, s) {
    return `#${ts[t]}${ts[e]}${ts[s]}`;
  }
  static domMatrixToTransform(t) {
    return [t.a, t.b, t.c, t.d, t.e, t.f];
  }
  static scaleMinMax(t, e) {
    let s;
    t[0] ? (t[0] < 0 && (s = e[0], e[0] = e[2], e[2] = s), e[0] *= t[0], e[2] *= t[0], t[3] < 0 && (s = e[1], e[1] = e[3], e[3] = s), e[1] *= t[3], e[3] *= t[3]) : (s = e[0], e[0] = e[1], e[1] = s, s = e[2], e[2] = e[3], e[3] = s, t[1] < 0 && (s = e[1], e[1] = e[3], e[3] = s), e[1] *= t[1], e[3] *= t[1], t[2] < 0 && (s = e[0], e[0] = e[2], e[2] = s), e[0] *= t[2], e[2] *= t[2]), e[0] += t[4], e[1] += t[5], e[2] += t[4], e[3] += t[5];
  }
  static transform(t, e) {
    return [t[0] * e[0] + t[2] * e[1], t[1] * e[0] + t[3] * e[1], t[0] * e[2] + t[2] * e[3], t[1] * e[2] + t[3] * e[3], t[0] * e[4] + t[2] * e[5] + t[4], t[1] * e[4] + t[3] * e[5] + t[5]];
  }
  static multiplyByDOMMatrix(t, e) {
    return [t[0] * e.a + t[2] * e.b, t[1] * e.a + t[3] * e.b, t[0] * e.c + t[2] * e.d, t[1] * e.c + t[3] * e.d, t[0] * e.e + t[2] * e.f + t[4], t[1] * e.e + t[3] * e.f + t[5]];
  }
  static applyTransform(t, e, s = 0) {
    const i = t[s], n = t[s + 1];
    t[s] = i * e[0] + n * e[2] + e[4], t[s + 1] = i * e[1] + n * e[3] + e[5];
  }
  static applyTransformToBezier(t, e, s = 0) {
    const i = e[0], n = e[1], r = e[2], a = e[3], o = e[4], l = e[5];
    for (let h = 0; h < 6; h += 2) {
      const c = t[s + h], u = t[s + h + 1];
      t[s + h] = c * i + u * r + o, t[s + h + 1] = c * n + u * a + l;
    }
  }
  static applyInverseTransform(t, e) {
    const s = t[0], i = t[1], n = e[0] * e[3] - e[1] * e[2];
    t[0] = (s * e[3] - i * e[2] + e[2] * e[5] - e[4] * e[3]) / n, t[1] = (-s * e[1] + i * e[0] + e[4] * e[1] - e[5] * e[0]) / n;
  }
  static axialAlignedBoundingBox(t, e, s) {
    const i = e[0], n = e[1], r = e[2], a = e[3], o = e[4], l = e[5], h = t[0], c = t[1], u = t[2], f = t[3];
    let g = i * h + o, p = g, b = i * u + o, m = b, y = a * c + l, A = y, v = a * f + l, w = v;
    if (n !== 0 || r !== 0) {
      const S = n * h, E = n * u, _ = r * c, C = r * f;
      g += _, m += _, b += C, p += C, y += S, w += S, v += E, A += E;
    }
    s[0] = Math.min(s[0], g, b, p, m), s[1] = Math.min(s[1], y, v, A, w), s[2] = Math.max(s[2], g, b, p, m), s[3] = Math.max(s[3], y, v, A, w);
  }
  static inverseTransform(t) {
    const e = t[0] * t[3] - t[1] * t[2];
    return [t[3] / e, -t[1] / e, -t[2] / e, t[0] / e, (t[2] * t[5] - t[4] * t[3]) / e, (t[4] * t[1] - t[5] * t[0]) / e];
  }
  static singularValueDecompose2dScale(t, e) {
    const s = t[0], i = t[1], n = t[2], r = t[3], a = s ** 2 + i ** 2, o = s * n + i * r, l = n ** 2 + r ** 2, h = (a + l) / 2, c = Math.sqrt(h ** 2 - (a * l - o ** 2));
    e[0] = Math.sqrt(h + c || 1), e[1] = Math.sqrt(h - c || 1);
  }
  static normalizeRect(t) {
    const e = t.slice(0);
    return t[0] > t[2] && (e[0] = t[2], e[2] = t[0]), t[1] > t[3] && (e[1] = t[3], e[3] = t[1]), e;
  }
  static intersect(t, e) {
    const s = Math.max(Math.min(t[0], t[2]), Math.min(e[0], e[2])), i = Math.min(Math.max(t[0], t[2]), Math.max(e[0], e[2]));
    if (s > i)
      return null;
    const n = Math.max(Math.min(t[1], t[3]), Math.min(e[1], e[3])), r = Math.min(Math.max(t[1], t[3]), Math.max(e[1], e[3]));
    return n > r ? null : [s, n, i, r];
  }
  static pointBoundingBox(t, e, s) {
    s[0] = Math.min(s[0], t), s[1] = Math.min(s[1], e), s[2] = Math.max(s[2], t), s[3] = Math.max(s[3], e);
  }
  static rectBoundingBox(t, e, s, i, n) {
    n[0] = Math.min(n[0], t, s), n[1] = Math.min(n[1], e, i), n[2] = Math.max(n[2], t, s), n[3] = Math.max(n[3], e, i);
  }
  static #t(t, e, s, i, n, r, a, o, l, h) {
    if (l <= 0 || l >= 1)
      return;
    const c = 1 - l, u = l * l, f = u * l, g = c * (c * (c * t + 3 * l * e) + 3 * u * s) + f * i, p = c * (c * (c * n + 3 * l * r) + 3 * u * a) + f * o;
    h[0] = Math.min(h[0], g), h[1] = Math.min(h[1], p), h[2] = Math.max(h[2], g), h[3] = Math.max(h[3], p);
  }
  static #e(t, e, s, i, n, r, a, o, l, h, c, u) {
    if (Math.abs(l) < 1e-12) {
      Math.abs(h) >= 1e-12 && this.#t(t, e, s, i, n, r, a, o, -c / h, u);
      return;
    }
    const f = h ** 2 - 4 * c * l;
    if (f < 0)
      return;
    const g = Math.sqrt(f), p = 2 * l;
    this.#t(t, e, s, i, n, r, a, o, (-h + g) / p, u), this.#t(t, e, s, i, n, r, a, o, (-h - g) / p, u);
  }
  static bezierBoundingBox(t, e, s, i, n, r, a, o, l) {
    l[0] = Math.min(l[0], t, a), l[1] = Math.min(l[1], e, o), l[2] = Math.max(l[2], t, a), l[3] = Math.max(l[3], e, o), this.#e(t, s, n, a, e, i, r, o, 3 * (-t + 3 * (s - n) + a), 6 * (t - 2 * s + n), 3 * (s - t), l), this.#e(t, s, n, a, e, i, r, o, 3 * (-e + 3 * (i - r) + o), 6 * (e - 2 * i + r), 3 * (i - e), l);
  }
}
function an(d) {
  return decodeURIComponent(escape(d));
}
let es = null, Os = null;
function ui(d) {
  return es || (es = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc-\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa-\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, Os = /* @__PURE__ */ new Map([["ﬅ", "ſt"]])), d.replaceAll(es, (t, e, s) => e ? e.normalize("NFKC") : Os.get(s));
}
function ys() {
  if (typeof crypto.randomUUID == "function")
    return crypto.randomUUID();
  const d = new Uint8Array(32);
  return crypto.getRandomValues(d), en(d);
}
const Xt = "pdfjs_internal_id_";
function on(d, t, e) {
  if (!Array.isArray(e) || e.length < 2)
    return !1;
  const [s, i, ...n] = e;
  if (!d(s) && !Number.isInteger(s) || !t(i))
    return !1;
  const r = n.length;
  let a = !0;
  switch (i.name) {
    case "XYZ":
      if (r < 2 || r > 3)
        return !1;
      break;
    case "Fit":
    case "FitB":
      return r === 0;
    case "FitH":
    case "FitBH":
    case "FitV":
    case "FitBV":
      if (r > 1)
        return !1;
      break;
    case "FitR":
      if (r !== 4)
        return !1;
      a = !1;
      break;
    default:
      return !1;
  }
  for (const o of n)
    if (!(typeof o == "number" || a && o === null))
      return !1;
  return !0;
}
function ct(d, t, e) {
  return Math.min(Math.max(d, t), e);
}
typeof Math.sumPrecise != "function" && (Math.sumPrecise = function(d) {
  return d.reduce((t, e) => t + e, 0);
});
class me {
  static textContent(t) {
    const e = [], s = {
      items: e,
      styles: /* @__PURE__ */ Object.create(null)
    };
    function i(n) {
      if (!n)
        return;
      let r = null;
      const a = n.name;
      if (a === "#text")
        r = n.value;
      else if (me.shouldBuildText(a))
        n?.attributes?.textContent ? r = n.attributes.textContent : n.value && (r = n.value);
      else return;
      if (r !== null && e.push({
        str: r
      }), !!n.children)
        for (const o of n.children)
          i(o);
    }
    return i(t), s;
  }
  static shouldBuildText(t) {
    return !(t === "textarea" || t === "input" || t === "option" || t === "select");
  }
}
class ws {
  static setupStorage(t, e, s, i, n) {
    const r = i.getValue(e, {
      value: null
    });
    switch (s.name) {
      case "textarea":
        if (r.value !== null && (t.textContent = r.value), n === "print")
          break;
        t.addEventListener("input", (a) => {
          i.setValue(e, {
            value: a.target.value
          });
        });
        break;
      case "input":
        if (s.attributes.type === "radio" || s.attributes.type === "checkbox") {
          if (r.value === s.attributes.xfaOn ? t.setAttribute("checked", !0) : r.value === s.attributes.xfaOff && t.removeAttribute("checked"), n === "print")
            break;
          t.addEventListener("change", (a) => {
            i.setValue(e, {
              value: a.target.checked ? a.target.getAttribute("xfaOn") : a.target.getAttribute("xfaOff")
            });
          });
        } else {
          if (r.value !== null && t.setAttribute("value", r.value), n === "print")
            break;
          t.addEventListener("input", (a) => {
            i.setValue(e, {
              value: a.target.value
            });
          });
        }
        break;
      case "select":
        if (r.value !== null) {
          t.setAttribute("value", r.value);
          for (const a of s.children)
            a.attributes.value === r.value ? a.attributes.selected = !0 : a.attributes.hasOwnProperty("selected") && delete a.attributes.selected;
        }
        t.addEventListener("input", (a) => {
          const o = a.target.options, l = o.selectedIndex === -1 ? "" : o[o.selectedIndex].value;
          i.setValue(e, {
            value: l
          });
        });
        break;
    }
  }
  static setAttributes({
    html: t,
    element: e,
    storage: s = null,
    intent: i,
    linkService: n
  }) {
    const {
      attributes: r
    } = e, a = t instanceof HTMLAnchorElement;
    r.type === "radio" && (r.name = `${r.name}-${i}`);
    for (const [o, l] of Object.entries(r))
      if (l != null)
        switch (o) {
          case "class":
            l.length && t.setAttribute(o, l.join(" "));
            break;
          case "dataId":
            break;
          case "id":
            t.setAttribute("data-element-id", l);
            break;
          case "style":
            Object.assign(t.style, l);
            break;
          case "textContent":
            t.textContent = l;
            break;
          default:
            (!a || o !== "href" && o !== "newWindow") && t.setAttribute(o, l);
        }
    a && n.addLinkAttributes(t, r.href, r.newWindow), s && r.dataId && this.setupStorage(t, r.dataId, e, s);
  }
  static render(t) {
    const e = t.annotationStorage, s = t.linkService, i = t.xfaHtml, n = t.intent || "display", r = document.createElement(i.name);
    i.attributes && this.setAttributes({
      html: r,
      element: i,
      intent: n,
      linkService: s
    });
    const a = n !== "richText", o = t.div;
    if (o.append(r), t.viewport) {
      const c = `matrix(${t.viewport.transform.join(",")})`;
      o.style.transform = c;
    }
    a && o.setAttribute("class", "xfaLayer xfaFont");
    const l = [];
    if (i.children.length === 0) {
      if (i.value) {
        const c = document.createTextNode(i.value);
        r.append(c), a && me.shouldBuildText(i.name) && l.push(c);
      }
      return {
        textDivs: l
      };
    }
    const h = [[i, -1, r]];
    for (; h.length > 0; ) {
      const [c, u, f] = h.at(-1);
      if (u + 1 === c.children.length) {
        h.pop();
        continue;
      }
      const g = c.children[++h.at(-1)[1]];
      if (g === null)
        continue;
      const {
        name: p
      } = g;
      if (p === "#text") {
        const m = document.createTextNode(g.value);
        l.push(m), f.append(m);
        continue;
      }
      const b = g?.attributes?.xmlns ? document.createElementNS(g.attributes.xmlns, p) : document.createElement(p);
      if (f.append(b), g.attributes && this.setAttributes({
        html: b,
        element: g,
        storage: e,
        intent: n,
        linkService: s
      }), g.children?.length > 0)
        h.push([g, -1, b]);
      else if (g.value) {
        const m = document.createTextNode(g.value);
        a && me.shouldBuildText(p) && l.push(m), b.append(m);
      }
    }
    for (const c of o.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
      c.setAttribute("readOnly", !0);
    return {
      textDivs: l
    };
  }
  static update(t) {
    const e = `matrix(${t.viewport.transform.join(",")})`;
    t.div.style.transform = e, t.div.hidden = !1;
  }
}
const Mt = "http://www.w3.org/2000/svg";
class Ht {
  static CSS = 96;
  static PDF = 72;
  static PDF_TO_CSS_UNITS = this.CSS / this.PDF;
}
async function ee(d, t = "text") {
  if (ce(d, document.baseURI)) {
    const e = await fetch(d);
    if (!e.ok)
      throw new Error(e.statusText);
    switch (t) {
      case "arraybuffer":
        return e.arrayBuffer();
      case "blob":
        return e.blob();
      case "json":
        return e.json();
    }
    return e.text();
  }
  return new Promise((e, s) => {
    const i = new XMLHttpRequest();
    i.open("GET", d, !0), i.responseType = t, i.onreadystatechange = () => {
      if (i.readyState === XMLHttpRequest.DONE) {
        if (i.status === 200 || i.status === 0) {
          switch (t) {
            case "arraybuffer":
            case "blob":
            case "json":
              e(i.response);
              return;
          }
          e(i.responseText);
          return;
        }
        s(new Error(i.statusText));
      }
    }, i.send(null);
  });
}
class we {
  constructor({
    viewBox: t,
    userUnit: e,
    scale: s,
    rotation: i,
    offsetX: n = 0,
    offsetY: r = 0,
    dontFlip: a = !1
  }) {
    this.viewBox = t, this.userUnit = e, this.scale = s, this.rotation = i, this.offsetX = n, this.offsetY = r, s *= e;
    const o = (t[2] + t[0]) / 2, l = (t[3] + t[1]) / 2;
    let h, c, u, f;
    switch (i %= 360, i < 0 && (i += 360), i) {
      case 180:
        h = -1, c = 0, u = 0, f = 1;
        break;
      case 90:
        h = 0, c = 1, u = 1, f = 0;
        break;
      case 270:
        h = 0, c = -1, u = -1, f = 0;
        break;
      case 0:
        h = 1, c = 0, u = 0, f = -1;
        break;
      default:
        throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
    }
    a && (u = -u, f = -f);
    let g, p, b, m;
    h === 0 ? (g = Math.abs(l - t[1]) * s + n, p = Math.abs(o - t[0]) * s + r, b = (t[3] - t[1]) * s, m = (t[2] - t[0]) * s) : (g = Math.abs(o - t[0]) * s + n, p = Math.abs(l - t[1]) * s + r, b = (t[2] - t[0]) * s, m = (t[3] - t[1]) * s), this.transform = [h * s, c * s, u * s, f * s, g - h * s * o - u * s * l, p - c * s * o - f * s * l], this.width = b, this.height = m;
  }
  get rawDims() {
    const t = this.viewBox;
    return I(this, "rawDims", {
      pageWidth: t[2] - t[0],
      pageHeight: t[3] - t[1],
      pageX: t[0],
      pageY: t[1]
    });
  }
  clone({
    scale: t = this.scale,
    rotation: e = this.rotation,
    offsetX: s = this.offsetX,
    offsetY: i = this.offsetY,
    dontFlip: n = !1
  } = {}) {
    return new we({
      viewBox: this.viewBox.slice(),
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: i,
      dontFlip: n
    });
  }
  convertToViewportPoint(t, e) {
    const s = [t, e];
    return T.applyTransform(s, this.transform), s;
  }
  convertToViewportRectangle(t) {
    const e = [t[0], t[1]];
    T.applyTransform(e, this.transform);
    const s = [t[2], t[3]];
    return T.applyTransform(s, this.transform), [e[0], e[1], s[0], s[1]];
  }
  convertToPdfPoint(t, e) {
    const s = [t, e];
    return T.applyInverseTransform(s, this.transform), s;
  }
}
class $e extends jt {
  constructor(t, e = 0) {
    super(t, "RenderingCancelledException"), this.extraDelay = e;
  }
}
function ve(d) {
  const t = d.length;
  let e = 0;
  for (; e < t && d[e].trim() === ""; )
    e++;
  return d.substring(e, e + 5).toLowerCase() === "data:";
}
function je(d) {
  return typeof d == "string" && /\.pdf$/i.test(d);
}
function fi(d) {
  return [d] = d.split(/[#?]/, 1), d.substring(d.lastIndexOf("/") + 1);
}
function pi(d, t = "document.pdf") {
  if (typeof d != "string")
    return t;
  if (ve(d))
    return R('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), t;
  const s = ((a) => {
    try {
      return new URL(a);
    } catch {
      try {
        return new URL(decodeURIComponent(a));
      } catch {
        try {
          return new URL(a, "https://foo.bar");
        } catch {
          try {
            return new URL(decodeURIComponent(a), "https://foo.bar");
          } catch {
            return null;
          }
        }
      }
    }
  })(d);
  if (!s)
    return t;
  const i = (a) => {
    try {
      let o = decodeURIComponent(a);
      return o.includes("/") ? (o = o.split("/").at(-1), o.test(/^\.pdf$/i) ? o : a) : o;
    } catch {
      return a;
    }
  }, n = /\.pdf$/i, r = s.pathname.split("/").at(-1);
  if (n.test(r))
    return i(r);
  if (s.searchParams.size > 0) {
    const a = Array.from(s.searchParams.values()).reverse();
    for (const l of a)
      if (n.test(l))
        return i(l);
    const o = Array.from(s.searchParams.keys()).reverse();
    for (const l of o)
      if (n.test(l))
        return i(l);
  }
  if (s.hash) {
    const o = /[^/?#=]+\.pdf\b(?!.*\.pdf\b)/i.exec(s.hash);
    if (o)
      return i(o[0]);
  }
  return t;
}
class Bs {
  started = /* @__PURE__ */ Object.create(null);
  times = [];
  time(t) {
    t in this.started && R(`Timer is already running for ${t}`), this.started[t] = Date.now();
  }
  timeEnd(t) {
    t in this.started || R(`Timer has not been started for ${t}`), this.times.push({
      name: t,
      start: this.started[t],
      end: Date.now()
    }), delete this.started[t];
  }
  toString() {
    const t = [];
    let e = 0;
    for (const {
      name: s
    } of this.times)
      e = Math.max(s.length, e);
    for (const {
      name: s,
      start: i,
      end: n
    } of this.times)
      t.push(`${s.padEnd(e)} ${n - i}ms
`);
    return t.join("");
  }
}
function ce(d, t) {
  const e = t ? URL.parse(d, t) : URL.parse(d);
  return e?.protocol === "http:" || e?.protocol === "https:";
}
function wt(d) {
  d.preventDefault();
}
function K(d) {
  d.preventDefault(), d.stopPropagation();
}
function ln(d) {
  console.log("Deprecated API usage: " + d);
}
class Fe {
  static #t;
  static toDateObject(t) {
    if (t instanceof Date)
      return t;
    if (!t || typeof t != "string")
      return null;
    this.#t ||= new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+|-])?(\\d{2})?'?(\\d{2})?'?");
    const e = this.#t.exec(t);
    if (!e)
      return null;
    const s = parseInt(e[1], 10);
    let i = parseInt(e[2], 10);
    i = i >= 1 && i <= 12 ? i - 1 : 0;
    let n = parseInt(e[3], 10);
    n = n >= 1 && n <= 31 ? n : 1;
    let r = parseInt(e[4], 10);
    r = r >= 0 && r <= 23 ? r : 0;
    let a = parseInt(e[5], 10);
    a = a >= 0 && a <= 59 ? a : 0;
    let o = parseInt(e[6], 10);
    o = o >= 0 && o <= 59 ? o : 0;
    const l = e[7] || "Z";
    let h = parseInt(e[8], 10);
    h = h >= 0 && h <= 23 ? h : 0;
    let c = parseInt(e[9], 10) || 0;
    return c = c >= 0 && c <= 59 ? c : 0, l === "-" ? (r += h, a += c) : l === "+" && (r -= h, a -= c), new Date(Date.UTC(s, i, n, r, a, o));
  }
}
function gi(d, {
  scale: t = 1,
  rotation: e = 0
}) {
  const {
    width: s,
    height: i
  } = d.attributes.style, n = [0, 0, parseInt(s), parseInt(i)];
  return new we({
    viewBox: n,
    userUnit: 1,
    scale: t,
    rotation: e
  });
}
function se(d) {
  if (d.startsWith("#")) {
    const t = parseInt(d.slice(1), 16);
    return [(t & 16711680) >> 16, (t & 65280) >> 8, t & 255];
  }
  return d.startsWith("rgb(") ? d.slice(4, -1).split(",").map((t) => parseInt(t)) : d.startsWith("rgba(") ? d.slice(5, -1).split(",").map((t) => parseInt(t)).slice(0, 3) : (R(`Not a valid color format: "${d}"`), [0, 0, 0]);
}
function hn(d) {
  const t = document.createElement("span");
  t.style.visibility = "hidden", t.style.colorScheme = "only light", document.body.append(t);
  for (const e of d.keys()) {
    t.style.color = e;
    const s = window.getComputedStyle(t).color;
    d.set(e, se(s));
  }
  t.remove();
}
function q(d) {
  const {
    a: t,
    b: e,
    c: s,
    d: i,
    e: n,
    f: r
  } = d.getTransform();
  return [t, e, s, i, n, r];
}
function _t(d) {
  const {
    a: t,
    b: e,
    c: s,
    d: i,
    e: n,
    f: r
  } = d.getTransform().invertSelf();
  return [t, e, s, i, n, r];
}
function Nt(d, t, e = !1, s = !0) {
  if (t instanceof we) {
    const {
      pageWidth: i,
      pageHeight: n
    } = t.rawDims, {
      style: r
    } = d, a = nt.isCSSRoundSupported, o = `var(--total-scale-factor) * ${i}px`, l = `var(--total-scale-factor) * ${n}px`, h = a ? `round(down, ${o}, var(--scale-round-x))` : `calc(${o})`, c = a ? `round(down, ${l}, var(--scale-round-y))` : `calc(${l})`;
    !e || t.rotation % 180 === 0 ? (r.width = h, r.height = c) : (r.width = c, r.height = h);
  }
  s && d.setAttribute("data-main-rotation", t.rotation);
}
class Et {
  constructor() {
    const {
      pixelRatio: t
    } = Et;
    this.sx = t, this.sy = t;
  }
  get scaled() {
    return this.sx !== 1 || this.sy !== 1;
  }
  get symmetric() {
    return this.sx === this.sy;
  }
  limitCanvas(t, e, s, i, n = -1) {
    let r = 1 / 0, a = 1 / 0, o = 1 / 0;
    s = Et.capPixels(s, n), s > 0 && (r = Math.sqrt(s / (t * e))), i !== -1 && (a = i / t, o = i / e);
    const l = Math.min(r, a, o);
    return this.sx > l || this.sy > l ? (this.sx = l, this.sy = l, !0) : !1;
  }
  static get pixelRatio() {
    return globalThis.devicePixelRatio || 1;
  }
  static capPixels(t, e) {
    if (e >= 0) {
      const s = Math.ceil(window.screen.availWidth * window.screen.availHeight * this.pixelRatio ** 2 * (1 + e / 100));
      return t > 0 ? Math.min(t, s) : s;
    }
    return t;
  }
}
const Ne = ["image/apng", "image/avif", "image/bmp", "image/gif", "image/jpeg", "image/png", "image/svg+xml", "image/webp", "image/x-icon"];
class cn {
  static get isDarkMode() {
    return I(this, "isDarkMode", !!window?.matchMedia?.("(prefers-color-scheme: dark)").matches);
  }
}
class mi {
  static get commentForegroundColor() {
    const t = document.createElement("span");
    t.classList.add("comment", "sidebar");
    const {
      style: e
    } = t;
    e.width = e.height = "0", e.display = "none", e.color = "var(--comment-fg-color)", document.body.append(t);
    const {
      color: s
    } = window.getComputedStyle(t);
    return t.remove(), I(this, "commentForegroundColor", se(s));
  }
}
function bi(d, t, e, s) {
  s = Math.min(Math.max(s ?? 1, 0), 1);
  const i = 255 * (1 - s);
  return d = Math.round(d * s + i), t = Math.round(t * s + i), e = Math.round(e * s + i), [d, t, e];
}
function Us(d, t) {
  const e = d[0] / 255, s = d[1] / 255, i = d[2] / 255, n = Math.max(e, s, i), r = Math.min(e, s, i), a = (n + r) / 2;
  if (n === r)
    t[0] = t[1] = 0;
  else {
    const o = n - r;
    switch (t[1] = a < 0.5 ? o / (n + r) : o / (2 - n - r), n) {
      case e:
        t[0] = ((s - i) / o + (s < i ? 6 : 0)) * 60;
        break;
      case s:
        t[0] = ((i - e) / o + 2) * 60;
        break;
      case i:
        t[0] = ((e - s) / o + 4) * 60;
        break;
    }
  }
  t[2] = a;
}
function ls(d, t) {
  const e = d[0], s = d[1], i = d[2], n = (1 - Math.abs(2 * i - 1)) * s, r = n * (1 - Math.abs(e / 60 % 2 - 1)), a = i - n / 2;
  switch (Math.floor(e / 60)) {
    case 0:
      t[0] = n + a, t[1] = r + a, t[2] = a;
      break;
    case 1:
      t[0] = r + a, t[1] = n + a, t[2] = a;
      break;
    case 2:
      t[0] = a, t[1] = n + a, t[2] = r + a;
      break;
    case 3:
      t[0] = a, t[1] = r + a, t[2] = n + a;
      break;
    case 4:
      t[0] = r + a, t[1] = a, t[2] = n + a;
      break;
    case 5:
    case 6:
      t[0] = n + a, t[1] = a, t[2] = r + a;
      break;
  }
}
function Hs(d) {
  return d <= 0.03928 ? d / 12.92 : ((d + 0.055) / 1.055) ** 2.4;
}
function $s(d, t, e) {
  ls(d, e), e.map(Hs);
  const s = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  ls(t, e), e.map(Hs);
  const i = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  return s > i ? (s + 0.05) / (i + 0.05) : (i + 0.05) / (s + 0.05);
}
const js = /* @__PURE__ */ new Map();
function Ai(d, t) {
  const e = d[0] + d[1] * 256 + d[2] * 65536 + t[0] * 16777216 + t[1] * 4294967296 + t[2] * 1099511627776;
  let s = js.get(e);
  if (s)
    return s;
  const i = new Float32Array(9), n = i.subarray(0, 3), r = i.subarray(3, 6);
  Us(d, r);
  const a = i.subarray(6, 9);
  Us(t, a);
  const o = a[2] < 0.5, l = o ? 12 : 4.5;
  if (r[2] = o ? Math.sqrt(r[2]) : 1 - Math.sqrt(1 - r[2]), $s(r, a, n) < l) {
    let h, c;
    o ? (h = r[2], c = 1) : (h = 0, c = r[2]);
    const u = 5e-3;
    for (; c - h > u; ) {
      const f = r[2] = (h + c) / 2;
      o === $s(r, a, n) < l ? h = f : c = f;
    }
    r[2] = o ? c : h;
  }
  return ls(r, n), s = T.makeHexColor(Math.round(n[0] * 255), Math.round(n[1] * 255), Math.round(n[2] * 255)), js.set(e, s), s;
}
function vs({
  html: d,
  dir: t,
  className: e
}, s) {
  const i = document.createDocumentFragment();
  if (typeof d == "string") {
    const n = document.createElement("p");
    n.dir = t || "auto";
    const r = d.split(/(?:\r\n?|\n)/);
    for (let a = 0, o = r.length; a < o; ++a) {
      const l = r[a];
      n.append(document.createTextNode(l)), a < o - 1 && n.append(document.createElement("br"));
    }
    i.append(n);
  } else
    ws.render({
      xfaHtml: d,
      div: i,
      intent: "richText"
    });
  i.firstElementChild.classList.add("richText", e), s.append(i);
}
function yi(d) {
  const t = new Path2D();
  if (!d)
    return t;
  for (let e = 0, s = d.length; e < s; )
    switch (d[e++]) {
      case re.moveTo:
        t.moveTo(d[e++], d[e++]);
        break;
      case re.lineTo:
        t.lineTo(d[e++], d[e++]);
        break;
      case re.curveTo:
        t.bezierCurveTo(d[e++], d[e++], d[e++], d[e++], d[e++], d[e++]);
        break;
      case re.quadraticCurveTo:
        t.quadraticCurveTo(d[e++], d[e++], d[e++], d[e++]);
        break;
      case re.closePath:
        t.closePath();
        break;
      default:
        R(`Unrecognized drawing path operator: ${d[e - 1]}`);
        break;
    }
  return t;
}
class B {
  static #t = null;
  static #e = null;
  static #i = null;
  static #s = 0;
  static #a = [];
  get pagesNumber() {
    return B.#s;
  }
  set pagesNumber(t) {
    B.#s !== t && (B.#s = t, t === 0 && (B.#e = null, B.#t = null));
  }
  addListener(t) {
    B.#a.push(t);
  }
  removeListener(t) {
    const e = B.#a.indexOf(t);
    e >= 0 && B.#a.splice(e, 1);
  }
  #r() {
    for (const t of B.#a)
      t();
  }
  #n(t) {
    if (B.#e)
      return;
    const e = B.#s, s = new Uint32Array(3 * e), i = B.#e = s.subarray(0, e), n = B.#t = s.subarray(e, 2 * e);
    if (t)
      for (let r = 0; r < e; r++)
        i[r] = n[r] = r + 1;
    B.#i = s.subarray(2 * e);
  }
  movePages(t, e, s) {
    this.#n(!0);
    const i = B.#e, n = B.#t;
    B.#i.set(n);
    const r = e.length, a = new Uint32Array(r);
    let o = 0;
    for (let f = 0; f < r; f++) {
      const g = e[f] - 1;
      a[f] = i[g], g < s && (o += 1);
    }
    const l = B.#s;
    let h = s - o;
    const c = l - r;
    h = ct(h, 0, c);
    for (let f = 0, g = 0; f < l; f++)
      t.has(f + 1) || (i[g++] = i[f]);
    i.copyWithin(h + r, h, c), i.set(a, h);
    let u = !1;
    for (let f = 0, g = l; f < g; f++) {
      const p = i[f];
      u ||= p !== f + 1, n[p - 1] = f + 1;
    }
    this.#r(), u || (this.pagesNumber = 0);
  }
  hasBeenAltered() {
    return B.#e !== null;
  }
  getPageMappingForSaving() {
    return {
      pageIndices: B.#t ? B.#t.map((t) => t - 1) : null
    };
  }
  getPrevPageNumber(t) {
    return B.#i[B.#e[t - 1] - 1];
  }
  getPageNumber(t) {
    return B.#t?.[t - 1] ?? t;
  }
  getPageId(t) {
    return B.#e?.[t - 1] ?? t;
  }
  static get instance() {
    return I(this, "instance", new B());
  }
  getMapping() {
    return B.#e.subarray(0, this.pagesNumber);
  }
}
class fe {
  #t = null;
  #e = null;
  #i;
  #s = null;
  #a = null;
  #r = null;
  #n = null;
  #o = null;
  static #h = null;
  constructor(t) {
    this.#i = t, fe.#h ||= Object.freeze({
      freetext: "pdfjs-editor-remove-freetext-button",
      highlight: "pdfjs-editor-remove-highlight-button",
      ink: "pdfjs-editor-remove-ink-button",
      stamp: "pdfjs-editor-remove-stamp-button",
      signature: "pdfjs-editor-remove-signature-button"
    });
  }
  render() {
    const t = this.#t = document.createElement("div");
    t.classList.add("editToolbar", "hidden"), t.setAttribute("role", "toolbar");
    const e = this.#i._uiManager._signal;
    e instanceof AbortSignal && !e.aborted && (t.addEventListener("contextmenu", wt, {
      signal: e
    }), t.addEventListener("pointerdown", fe.#l, {
      signal: e
    }));
    const s = this.#s = document.createElement("div");
    s.className = "buttons", t.append(s);
    const i = this.#i.toolbarPosition;
    if (i) {
      const {
        style: n
      } = t, r = this.#i._uiManager.direction === "ltr" ? 1 - i[0] : i[0];
      n.insetInlineEnd = `${100 * r}%`, n.top = `calc(${100 * i[1]}% + var(--editor-toolbar-vert-offset))`;
    }
    return t;
  }
  get div() {
    return this.#t;
  }
  static #l(t) {
    t.stopPropagation();
  }
  #u(t) {
    this.#i._focusEventsAllowed = !1, K(t);
  }
  #d(t) {
    this.#i._focusEventsAllowed = !0, K(t);
  }
  #f(t) {
    const e = this.#i._uiManager._signal;
    return !(e instanceof AbortSignal) || e.aborted ? !1 : (t.addEventListener("focusin", this.#u.bind(this), {
      capture: !0,
      signal: e
    }), t.addEventListener("focusout", this.#d.bind(this), {
      capture: !0,
      signal: e
    }), t.addEventListener("contextmenu", wt, {
      signal: e
    }), !0);
  }
  hide() {
    this.#t.classList.add("hidden"), this.#e?.hideDropdown();
  }
  show() {
    this.#t.classList.remove("hidden"), this.#a?.shown(), this.#r?.shown();
  }
  addDeleteButton() {
    const {
      editorType: t,
      _uiManager: e
    } = this.#i, s = document.createElement("button");
    s.classList.add("basic", "deleteButton"), s.tabIndex = 0, s.setAttribute("data-l10n-id", fe.#h[t]), this.#f(s) && s.addEventListener("click", (i) => {
      e.delete();
    }, {
      signal: e._signal
    }), this.#s.append(s);
  }
  get #m() {
    const t = document.createElement("div");
    return t.className = "divider", t;
  }
  async addAltText(t) {
    const e = await t.render();
    this.#f(e), this.#s.append(e, this.#m), this.#a = t;
  }
  addComment(t, e = null) {
    if (this.#r)
      return;
    const s = t.renderForToolbar();
    if (!s)
      return;
    this.#f(s);
    const i = this.#n = this.#m;
    e ? (this.#s.insertBefore(s, e), this.#s.insertBefore(i, e)) : this.#s.append(s, i), this.#r = t, t.toolbar = this;
  }
  addColorPicker(t) {
    if (this.#e)
      return;
    this.#e = t;
    const e = t.renderButton();
    this.#f(e), this.#s.append(e, this.#m);
  }
  async addEditSignatureButton(t) {
    const e = this.#o = await t.renderEditButton(this.#i);
    this.#f(e), this.#s.append(e, this.#m);
  }
  removeButton(t) {
    switch (t) {
      case "comment":
        this.#r?.removeToolbarCommentButton(), this.#r = null, this.#n?.remove(), this.#n = null;
        break;
    }
  }
  async addButton(t, e) {
    switch (t) {
      case "colorPicker":
        e && this.addColorPicker(e);
        break;
      case "altText":
        e && await this.addAltText(e);
        break;
      case "editSignature":
        e && await this.addEditSignatureButton(e);
        break;
      case "delete":
        this.addDeleteButton();
        break;
      case "comment":
        e && this.addComment(e);
        break;
    }
  }
  async addButtonBefore(t, e, s) {
    if (!e && t === "comment")
      return;
    const i = this.#s.querySelector(s);
    i && t === "comment" && this.addComment(e, i);
  }
  updateEditSignatureButton(t) {
    this.#o && (this.#o.title = t);
  }
  remove() {
    this.#t.remove(), this.#e?.destroy(), this.#e = null;
  }
}
class dn {
  #t = null;
  #e = null;
  #i;
  constructor(t) {
    this.#i = t;
  }
  #s() {
    const t = this.#e = document.createElement("div");
    t.className = "editToolbar", t.setAttribute("role", "toolbar");
    const e = this.#i._signal;
    e instanceof AbortSignal && !e.aborted && t.addEventListener("contextmenu", wt, {
      signal: e
    });
    const s = this.#t = document.createElement("div");
    return s.className = "buttons", t.append(s), this.#i.hasCommentManager() && this.#r("commentButton", "pdfjs-comment-floating-button", "pdfjs-comment-floating-button-label", () => {
      this.#i.commentSelection("floating_button");
    }), this.#r("highlightButton", "pdfjs-highlight-floating-button1", "pdfjs-highlight-floating-button-label", () => {
      this.#i.highlightSelection("floating_button");
    }), t;
  }
  #a(t, e) {
    let s = 0, i = 0;
    for (const n of t) {
      const r = n.y + n.height;
      if (r < s)
        continue;
      const a = n.x + (e ? n.width : 0);
      if (r > s) {
        i = a, s = r;
        continue;
      }
      e ? a > i && (i = a) : a < i && (i = a);
    }
    return [e ? 1 - i : i, s];
  }
  show(t, e, s) {
    const [i, n] = this.#a(e, s), {
      style: r
    } = this.#e ||= this.#s();
    t.append(this.#e), r.insetInlineEnd = `${100 * i}%`, r.top = `calc(${100 * n}% + var(--editor-toolbar-vert-offset))`;
  }
  hide() {
    this.#e.remove();
  }
  #r(t, e, s, i) {
    const n = document.createElement("button");
    n.classList.add("basic", t), n.tabIndex = 0, n.setAttribute("data-l10n-id", e);
    const r = document.createElement("span");
    n.append(r), r.className = "visuallyHidden", r.setAttribute("data-l10n-id", s);
    const a = this.#i._signal;
    a instanceof AbortSignal && !a.aborted && (n.addEventListener("contextmenu", wt, {
      signal: a
    }), n.addEventListener("click", i, {
      signal: a
    })), this.#t.append(n);
  }
}
function wi(d, t, e) {
  for (const s of e)
    t.addEventListener(s, d[s].bind(d));
}
class H {
  static #t = NaN;
  static #e = null;
  static #i = NaN;
  static #s = null;
  static initializeAndAddPointerId(t) {
    (H.#e ||= /* @__PURE__ */ new Set()).add(t);
  }
  static setPointer(t, e) {
    H.#t ||= e, H.#s ??= t;
  }
  static setTimeStamp(t) {
    H.#i = t;
  }
  static isSamePointerId(t) {
    return H.#t === t;
  }
  static isSamePointerIdOrRemove(t) {
    return H.#t === t ? !0 : (H.#e?.delete(t), !1);
  }
  static isSamePointerType(t) {
    return H.#s === t;
  }
  static isInitializedAndDifferentPointerType(t) {
    return H.#s !== null && !H.isSamePointerType(t);
  }
  static isSameTimeStamp(t) {
    return H.#i === t;
  }
  static isUsingMultiplePointers() {
    return H.#e?.size >= 1;
  }
  static clearPointerType() {
    H.#s = null;
  }
  static clearPointerIds() {
    H.#t = NaN, H.#e = null;
  }
  static clearTimeStamp() {
    H.#i = NaN;
  }
}
class un {
  #t = 0;
  get id() {
    return `${pe}${this.#t++}`;
  }
}
class Ss {
  #t = ys();
  #e = 0;
  #i = null;
  static get _isSVGFittingCanvas() {
    const t = 'data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" style="fill:red;"/></svg>', s = new OffscreenCanvas(1, 3).getContext("2d", {
      willReadFrequently: !0
    }), i = new Image();
    i.src = t;
    const n = i.decode().then(() => (s.drawImage(i, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(s.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
    return I(this, "_isSVGFittingCanvas", n);
  }
  async #s(t, e) {
    this.#i ||= /* @__PURE__ */ new Map();
    let s = this.#i.get(t);
    if (s === null)
      return null;
    if (s?.bitmap)
      return s.refCounter += 1, s;
    try {
      s ||= {
        bitmap: null,
        id: `image_${this.#t}_${this.#e++}`,
        refCounter: 0,
        isSvg: !1
      };
      let i;
      if (typeof e == "string" ? (s.url = e, i = await ee(e, "blob")) : e instanceof File ? i = s.file = e : e instanceof Blob && (i = e), i.type === "image/svg+xml") {
        const n = Ss._isSVGFittingCanvas, r = new FileReader(), a = new Image(), o = new Promise((l, h) => {
          a.onload = () => {
            s.bitmap = a, s.isSvg = !0, l();
          }, r.onload = async () => {
            const c = s.svgUrl = r.result;
            a.src = await n ? `${c}#svgView(preserveAspectRatio(none))` : c;
          }, a.onerror = r.onerror = h;
        });
        r.readAsDataURL(i), await o;
      } else
        s.bitmap = await createImageBitmap(i);
      s.refCounter = 1;
    } catch (i) {
      R(i), s = null;
    }
    return this.#i.set(t, s), s && this.#i.set(s.id, s), s;
  }
  async getFromFile(t) {
    const {
      lastModified: e,
      name: s,
      size: i,
      type: n
    } = t;
    return this.#s(`${e}_${s}_${i}_${n}`, t);
  }
  async getFromUrl(t) {
    return this.#s(t, t);
  }
  async getFromBlob(t, e) {
    const s = await e;
    return this.#s(t, s);
  }
  async getFromId(t) {
    this.#i ||= /* @__PURE__ */ new Map();
    const e = this.#i.get(t);
    if (!e)
      return null;
    if (e.bitmap)
      return e.refCounter += 1, e;
    if (e.file)
      return this.getFromFile(e.file);
    if (e.blobPromise) {
      const {
        blobPromise: s
      } = e;
      return delete e.blobPromise, this.getFromBlob(e.id, s);
    }
    return this.getFromUrl(e.url);
  }
  getFromCanvas(t, e) {
    this.#i ||= /* @__PURE__ */ new Map();
    let s = this.#i.get(t);
    if (s?.bitmap)
      return s.refCounter += 1, s;
    const i = new OffscreenCanvas(e.width, e.height);
    return i.getContext("2d").drawImage(e, 0, 0), s = {
      bitmap: i.transferToImageBitmap(),
      id: `image_${this.#t}_${this.#e++}`,
      refCounter: 1,
      isSvg: !1
    }, this.#i.set(t, s), this.#i.set(s.id, s), s;
  }
  getSvgUrl(t) {
    const e = this.#i.get(t);
    return e?.isSvg ? e.svgUrl : null;
  }
  deleteId(t) {
    this.#i ||= /* @__PURE__ */ new Map();
    const e = this.#i.get(t);
    if (!e || (e.refCounter -= 1, e.refCounter !== 0))
      return;
    const {
      bitmap: s
    } = e;
    if (!e.url && !e.file) {
      const i = new OffscreenCanvas(s.width, s.height);
      i.getContext("bitmaprenderer").transferFromImageBitmap(s), e.blobPromise = i.convertToBlob();
    }
    s.close?.(), e.bitmap = null;
  }
  isValidId(t) {
    return t.startsWith(`image_${this.#t}_`);
  }
}
class fn {
  #t = [];
  #e = !1;
  #i;
  #s = -1;
  constructor(t = 128) {
    this.#i = t;
  }
  add({
    cmd: t,
    undo: e,
    post: s,
    mustExec: i,
    type: n = NaN,
    overwriteIfSameType: r = !1,
    keepUndo: a = !1
  }) {
    if (i && t(), this.#e)
      return;
    const o = {
      cmd: t,
      undo: e,
      post: s,
      type: n
    };
    if (this.#s === -1) {
      this.#t.length > 0 && (this.#t.length = 0), this.#s = 0, this.#t.push(o);
      return;
    }
    if (r && this.#t[this.#s].type === n) {
      a && (o.undo = this.#t[this.#s].undo), this.#t[this.#s] = o;
      return;
    }
    const l = this.#s + 1;
    l === this.#i ? this.#t.splice(0, 1) : (this.#s = l, l < this.#t.length && this.#t.splice(l)), this.#t.push(o);
  }
  undo() {
    if (this.#s === -1)
      return;
    this.#e = !0;
    const {
      undo: t,
      post: e
    } = this.#t[this.#s];
    t(), e?.(), this.#e = !1, this.#s -= 1;
  }
  redo() {
    if (this.#s < this.#t.length - 1) {
      this.#s += 1, this.#e = !0;
      const {
        cmd: t,
        post: e
      } = this.#t[this.#s];
      t(), e?.(), this.#e = !1;
    }
  }
  hasSomethingToUndo() {
    return this.#s !== -1;
  }
  hasSomethingToRedo() {
    return this.#s < this.#t.length - 1;
  }
  cleanType(t) {
    if (this.#s !== -1) {
      for (let e = this.#s; e >= 0; e--)
        if (this.#t[e].type !== t) {
          this.#t.splice(e + 1, this.#s - e), this.#s = e;
          return;
        }
      this.#t.length = 0, this.#s = -1;
    }
  }
  destroy() {
    this.#t = null;
  }
}
class Se {
  constructor(t) {
    this.buffer = [], this.callbacks = /* @__PURE__ */ new Map(), this.allKeys = /* @__PURE__ */ new Set();
    const {
      isMac: e
    } = nt.platform;
    for (const [s, i, n = {}] of t)
      for (const r of s) {
        const a = r.startsWith("mac+");
        e && a ? (this.callbacks.set(r.slice(4), {
          callback: i,
          options: n
        }), this.allKeys.add(r.split("+").at(-1))) : !e && !a && (this.callbacks.set(r, {
          callback: i,
          options: n
        }), this.allKeys.add(r.split("+").at(-1)));
      }
  }
  #t(t) {
    t.altKey && this.buffer.push("alt"), t.ctrlKey && this.buffer.push("ctrl"), t.metaKey && this.buffer.push("meta"), t.shiftKey && this.buffer.push("shift"), this.buffer.push(t.key);
    const e = this.buffer.join("+");
    return this.buffer.length = 0, e;
  }
  exec(t, e) {
    if (!this.allKeys.has(e.key))
      return;
    const s = this.callbacks.get(this.#t(e));
    if (!s)
      return;
    const {
      callback: i,
      options: {
        bubbles: n = !1,
        args: r = [],
        checker: a = null
      }
    } = s;
    a && !a(t, e) || (i.bind(t, ...r, e)(), n || K(e));
  }
}
class Es {
  static _colorsMapping = /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]);
  get _colors() {
    const t = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
    return hn(t), I(this, "_colors", t);
  }
  convert(t) {
    const e = se(t);
    if (!window.matchMedia("(forced-colors: active)").matches)
      return e;
    for (const [s, i] of this._colors)
      if (i.every((n, r) => n === e[r]))
        return Es._colorsMapping.get(s);
    return e;
  }
  getHexCode(t) {
    const e = this._colors.get(t);
    return e ? T.makeHexColor(...e) : t;
  }
}
class It {
  #t = new AbortController();
  #e = null;
  #i = null;
  #s = /* @__PURE__ */ new Map();
  #a = /* @__PURE__ */ new Map();
  #r = null;
  #n = null;
  #o = null;
  #h = new fn();
  #l = null;
  #u = null;
  #d = null;
  #f = 0;
  #m = /* @__PURE__ */ new Set();
  #g = null;
  #c = null;
  #p = /* @__PURE__ */ new Set();
  _editorUndoBar = null;
  #b = !1;
  #y = !1;
  #A = !1;
  #C = null;
  #E = null;
  #v = null;
  #x = null;
  #w = !1;
  #_ = null;
  #M = new un();
  #P = !1;
  #k = !1;
  #O = !1;
  #L = null;
  #R = null;
  #B = null;
  #F = null;
  #G = null;
  #T = F.NONE;
  #S = /* @__PURE__ */ new Set();
  #I = null;
  #U = null;
  #$ = null;
  #X = null;
  #W = null;
  #Y = {
    isEditing: !1,
    isEmpty: !0,
    hasSomethingToUndo: !1,
    hasSomethingToRedo: !1,
    hasSelectedEditor: !1,
    hasSelectedText: !1
  };
  #j = [0, 0];
  #N = null;
  #V = null;
  #J = null;
  #Z = null;
  #H = null;
  static TRANSLATE_SMALL = 1;
  static TRANSLATE_BIG = 10;
  static get _keyboardManager() {
    const t = It.prototype, e = (r) => r.#V.contains(document.activeElement) && document.activeElement.tagName !== "BUTTON" && r.hasSomethingToControl(), s = (r, {
      target: a
    }) => {
      if (a instanceof HTMLInputElement) {
        const {
          type: o
        } = a;
        return o !== "text" && o !== "number";
      }
      return !0;
    }, i = this.TRANSLATE_SMALL, n = this.TRANSLATE_BIG;
    return I(this, "_keyboardManager", new Se([[["ctrl+a", "mac+meta+a"], t.selectAll, {
      checker: s
    }], [["ctrl+z", "mac+meta+z"], t.undo, {
      checker: s
    }], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], t.redo, {
      checker: s
    }], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], t.delete, {
      checker: s
    }], [["Enter", "mac+Enter"], t.addNewEditorFromKeyboard, {
      checker: (r, {
        target: a
      }) => !(a instanceof HTMLButtonElement) && r.#V.contains(a) && !r.isEnterHandled
    }], [[" ", "mac+ "], t.addNewEditorFromKeyboard, {
      checker: (r, {
        target: a
      }) => !(a instanceof HTMLButtonElement) && r.#V.contains(document.activeElement)
    }], [["Escape", "mac+Escape"], t.unselectAll], [["ArrowLeft", "mac+ArrowLeft"], t.translateSelectedEditors, {
      args: [-i, 0],
      checker: e
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t.translateSelectedEditors, {
      args: [-n, 0],
      checker: e
    }], [["ArrowRight", "mac+ArrowRight"], t.translateSelectedEditors, {
      args: [i, 0],
      checker: e
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t.translateSelectedEditors, {
      args: [n, 0],
      checker: e
    }], [["ArrowUp", "mac+ArrowUp"], t.translateSelectedEditors, {
      args: [0, -i],
      checker: e
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t.translateSelectedEditors, {
      args: [0, -n],
      checker: e
    }], [["ArrowDown", "mac+ArrowDown"], t.translateSelectedEditors, {
      args: [0, i],
      checker: e
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t.translateSelectedEditors, {
      args: [0, n],
      checker: e
    }]]));
  }
  constructor(t, e, s, i, n, r, a, o, l, h, c, u, f, g, p, b) {
    const m = this._signal = this.#t.signal;
    this.#V = t, this.#J = e, this.#Z = s, this.#r = i, this.#l = n, this.#U = r, this.#W = o, this._eventBus = a, a._on("editingaction", this.onEditingAction.bind(this), {
      signal: m
    }), a._on("pagechanging", this.onPageChanging.bind(this), {
      signal: m
    }), a._on("scalechanging", this.onScaleChanging.bind(this), {
      signal: m
    }), a._on("rotationchanging", this.onRotationChanging.bind(this), {
      signal: m
    }), a._on("setpreference", this.onSetPreference.bind(this), {
      signal: m
    }), a._on("switchannotationeditorparams", (y) => this.updateParams(y.type, y.value), {
      signal: m
    }), a._on("pagesedited", this.onPagesEdited.bind(this), {
      signal: m
    }), window.addEventListener("pointerdown", () => {
      this.#k = !0;
    }, {
      capture: !0,
      signal: m
    }), window.addEventListener("pointerup", () => {
      this.#k = !1;
    }, {
      capture: !0,
      signal: m
    }), this.#at(), this.#ut(), this.#et(), this.#n = o.annotationStorage, this.#C = o.filterFactory, this.#$ = l, this.#x = h || null, this.#b = c, this.#y = u, this.#A = f, this.#G = g || null, this.viewParameters = {
      realScale: Ht.PDF_TO_CSS_UNITS,
      rotation: 0
    }, this.isShiftKeyDown = !1, this._editorUndoBar = p || null, this._supportsPinchToZoom = b !== !1, n?.setSidebarUiManager(this);
  }
  destroy() {
    this.#H?.resolve(), this.#H = null, this.#t?.abort(), this.#t = null, this._signal = null;
    for (const t of this.#a.values())
      t.destroy();
    this.#a.clear(), this.#s.clear(), this.#p.clear(), this.#F?.clear(), this.#e = null, this.#S.clear(), this.#h.destroy(), this.#r?.destroy(), this.#l?.destroy(), this.#U?.destroy(), this.#_?.hide(), this.#_ = null, this.#B?.destroy(), this.#B = null, this.#i = null, this.#E && (clearTimeout(this.#E), this.#E = null), this.#N && (clearTimeout(this.#N), this.#N = null), this._editorUndoBar?.destroy(), this.#W = null;
  }
  combinedSignal(t) {
    return AbortSignal.any([this._signal, t.signal]);
  }
  get mlManager() {
    return this.#G;
  }
  get useNewAltTextFlow() {
    return this.#y;
  }
  get useNewAltTextWhenAddingImage() {
    return this.#A;
  }
  get hcmFilter() {
    return I(this, "hcmFilter", this.#$ ? this.#C.addHCMFilter(this.#$.foreground, this.#$.background) : "none");
  }
  get direction() {
    return I(this, "direction", getComputedStyle(this.#V).direction);
  }
  get _highlightColors() {
    return I(this, "_highlightColors", this.#x ? new Map(this.#x.split(",").map((t) => (t = t.split("=").map((e) => e.trim()), t[1] = t[1].toUpperCase(), t))) : null);
  }
  get highlightColors() {
    const {
      _highlightColors: t
    } = this;
    if (!t)
      return I(this, "highlightColors", null);
    const e = /* @__PURE__ */ new Map(), s = !!this.#$;
    for (const [i, n] of t) {
      const r = i.endsWith("_HCM");
      if (s && r) {
        e.set(i.replace("_HCM", ""), n);
        continue;
      }
      !s && !r && e.set(i, n);
    }
    return I(this, "highlightColors", e);
  }
  get highlightColorNames() {
    return I(this, "highlightColorNames", this.highlightColors ? new Map(Array.from(this.highlightColors, (t) => t.reverse())) : null);
  }
  getNonHCMColor(t) {
    if (!this._highlightColors)
      return t;
    const e = this.highlightColorNames.get(t);
    return this._highlightColors.get(e) || t;
  }
  getNonHCMColorName(t) {
    return this.highlightColorNames.get(t) || t;
  }
  setCurrentDrawingSession(t) {
    t ? (this.unselectAll(), this.disableUserSelect(!0)) : this.disableUserSelect(!1), this.#d = t;
  }
  setMainHighlightColorPicker(t) {
    this.#B = t;
  }
  editAltText(t, e = !1) {
    this.#r?.editAltText(this, t, e);
  }
  hasCommentManager() {
    return !!this.#l;
  }
  editComment(t, e, s, i) {
    this.#l?.showDialog(this, t, e, s, i);
  }
  selectComment(t, e) {
    this.#a.get(t)?.getEditorByUID(e)?.toggleComment(!0, !0);
  }
  updateComment(t) {
    this.#l?.updateComment(t.getData());
  }
  updatePopupColor(t) {
    this.#l?.updatePopupColor(t);
  }
  removeComment(t) {
    this.#l?.removeComments([t.uid]);
  }
  deleteComment(t, e) {
    const s = () => {
      t.comment = e;
    }, i = () => {
      this._editorUndoBar?.show(s, "comment"), this.toggleComment(null), t.comment = null;
    };
    this.addCommands({
      cmd: i,
      undo: s,
      mustExec: !0
    });
  }
  toggleComment(t, e, s = void 0) {
    this.#l?.toggleCommentPopup(t, e, s);
  }
  makeCommentColor(t, e) {
    return t && this.#l?.makeCommentColor(t, e) || null;
  }
  getCommentDialogElement() {
    return this.#l?.dialogElement || null;
  }
  async waitForEditorsRendered(t) {
    if (this.#a.has(t - 1))
      return;
    const {
      resolve: e,
      promise: s
    } = Promise.withResolvers(), i = (n) => {
      n.pageNumber === t && (this._eventBus._off("editorsrendered", i), e());
    };
    this._eventBus.on("editorsrendered", i), await s;
  }
  getSignature(t) {
    this.#U?.getSignature({
      uiManager: this,
      editor: t
    });
  }
  get signatureManager() {
    return this.#U;
  }
  switchToMode(t, e) {
    this._eventBus.on("annotationeditormodechanged", e, {
      once: !0,
      signal: this._signal
    }), this._eventBus.dispatch("showannotationeditorui", {
      source: this,
      mode: t
    });
  }
  setPreference(t, e) {
    this._eventBus.dispatch("setpreference", {
      source: this,
      name: t,
      value: e
    });
  }
  onSetPreference({
    name: t,
    value: e
  }) {
    switch (t) {
      case "enableNewAltTextWhenAddingImage":
        this.#A = e;
        break;
    }
  }
  onPagesEdited({
    pagesMapper: t
  }) {
    for (const i of this.#s.values())
      i.updatePageIndex(t.getPrevPageNumber(i.pageIndex + 1) - 1);
    const e = this.#a, s = this.#a = /* @__PURE__ */ new Map();
    for (const [i, n] of e) {
      const r = t.getPrevPageNumber(i + 1) - 1;
      if (r === -1) {
        n.destroy();
        continue;
      }
      s.set(r, n), n.updatePageIndex(r);
    }
  }
  onPageChanging({
    pageNumber: t
  }) {
    this.#f = t - 1;
  }
  focusMainContainer() {
    this.#V.focus();
  }
  findParent(t, e) {
    for (const s of this.#a.values()) {
      const {
        x: i,
        y: n,
        width: r,
        height: a
      } = s.div.getBoundingClientRect();
      if (t >= i && t <= i + r && e >= n && e <= n + a)
        return s;
    }
    return null;
  }
  disableUserSelect(t = !1) {
    this.#J.classList.toggle("noUserSelect", t);
  }
  addShouldRescale(t) {
    this.#p.add(t);
  }
  removeShouldRescale(t) {
    this.#p.delete(t);
  }
  onScaleChanging({
    scale: t
  }) {
    this.commitOrRemove(), this.viewParameters.realScale = t * Ht.PDF_TO_CSS_UNITS;
    for (const e of this.#p)
      e.onScaleChanging();
    this.#d?.onScaleChanging();
  }
  onRotationChanging({
    pagesRotation: t
  }) {
    this.commitOrRemove(), this.viewParameters.rotation = t;
  }
  #Q({
    anchorNode: t
  }) {
    return t.nodeType === Node.TEXT_NODE ? t.parentElement : t;
  }
  #tt(t) {
    const {
      currentLayer: e
    } = this;
    if (e.hasTextLayer(t))
      return e;
    for (const s of this.#a.values())
      if (s.hasTextLayer(t))
        return s;
    return null;
  }
  highlightSelection(t = "", e = !1) {
    const s = document.getSelection();
    if (!s || s.isCollapsed)
      return;
    const {
      anchorNode: i,
      anchorOffset: n,
      focusNode: r,
      focusOffset: a
    } = s, o = s.toString(), h = this.#Q(s).closest(".textLayer"), c = this.getSelectionBoxes(h);
    if (!c)
      return;
    s.empty();
    const u = this.#tt(h), f = this.#T === F.NONE, g = () => {
      const p = u?.createAndAddNewEditor({
        x: 0,
        y: 0
      }, !1, {
        methodOfCreation: t,
        boxes: c,
        anchorNode: i,
        anchorOffset: n,
        focusNode: r,
        focusOffset: a,
        text: o
      });
      f && this.showAllEditors("highlight", !0, !0), e && p?.editComment();
    };
    if (f) {
      this.switchToMode(F.HIGHLIGHT, g);
      return;
    }
    g();
  }
  commentSelection(t = "") {
    this.highlightSelection(t, !0);
  }
  #nt() {
    const t = document.getSelection();
    if (!t || t.isCollapsed)
      return;
    const s = this.#Q(t).closest(".textLayer"), i = this.getSelectionBoxes(s);
    i && (this.#_ ||= new dn(this), this.#_.show(s, i, this.direction === "ltr"));
  }
  getAndRemoveDataFromAnnotationStorage(t) {
    if (!this.#n)
      return null;
    const e = `${pe}${t}`, s = this.#n.getRawValue(e);
    return s && this.#n.remove(e), s;
  }
  addToAnnotationStorage(t) {
    !t.isEmpty() && this.#n && !this.#n.has(t.id) && this.#n.setValue(t.id, t);
  }
  a11yAlert(t, e = null) {
    const s = this.#Z;
    s && (s.setAttribute("data-l10n-id", t), e ? s.setAttribute("data-l10n-args", JSON.stringify(e)) : s.removeAttribute("data-l10n-args"));
  }
  #rt() {
    const t = document.getSelection();
    if (!t || t.isCollapsed) {
      this.#I && (this.#_?.hide(), this.#I = null, this.#D({
        hasSelectedText: !1
      }));
      return;
    }
    const {
      anchorNode: e
    } = t;
    if (e === this.#I)
      return;
    const i = this.#Q(t).closest(".textLayer");
    if (!i) {
      this.#I && (this.#_?.hide(), this.#I = null, this.#D({
        hasSelectedText: !1
      }));
      return;
    }
    if (this.#_?.hide(), this.#I = e, this.#D({
      hasSelectedText: !0
    }), !(this.#T !== F.HIGHLIGHT && this.#T !== F.NONE) && (this.#T === F.HIGHLIGHT && this.showAllEditors("highlight", !0, !0), this.#w = this.isShiftKeyDown, !this.isShiftKeyDown)) {
      const n = this.#T === F.HIGHLIGHT ? this.#tt(i) : null;
      if (n?.toggleDrawing(), this.#k) {
        const r = new AbortController(), a = this.combinedSignal(r), o = (l) => {
          l.type === "pointerup" && l.button !== 0 || (r.abort(), n?.toggleDrawing(!0), l.type === "pointerup" && this.#q("main_toolbar"));
        };
        window.addEventListener("pointerup", o, {
          signal: a
        }), window.addEventListener("blur", o, {
          signal: a
        });
      } else
        n?.toggleDrawing(!0), this.#q("main_toolbar");
    }
  }
  #q(t = "") {
    this.#T === F.HIGHLIGHT ? this.highlightSelection(t) : this.#b && this.#nt();
  }
  #at() {
    document.addEventListener("selectionchange", this.#rt.bind(this), {
      signal: this._signal
    });
  }
  #ot() {
    if (this.#v)
      return;
    this.#v = new AbortController();
    const t = this.combinedSignal(this.#v);
    window.addEventListener("focus", this.focus.bind(this), {
      signal: t
    }), window.addEventListener("blur", this.blur.bind(this), {
      signal: t
    });
  }
  #lt() {
    this.#v?.abort(), this.#v = null;
  }
  blur() {
    if (this.isShiftKeyDown = !1, this.#w && (this.#w = !1, this.#q("main_toolbar")), !this.hasSelection)
      return;
    const {
      activeElement: t
    } = document;
    for (const e of this.#S)
      if (e.div.contains(t)) {
        this.#R = [e, t], e._focusEventsAllowed = !1;
        break;
      }
  }
  focus() {
    if (!this.#R)
      return;
    const [t, e] = this.#R;
    this.#R = null, e.addEventListener("focusin", () => {
      t._focusEventsAllowed = !0;
    }, {
      once: !0,
      signal: this._signal
    }), e.focus();
  }
  #et() {
    if (this.#L)
      return;
    this.#L = new AbortController();
    const t = this.combinedSignal(this.#L);
    window.addEventListener("keydown", this.keydown.bind(this), {
      signal: t
    }), window.addEventListener("keyup", this.keyup.bind(this), {
      signal: t
    });
  }
  #ht() {
    this.#L?.abort(), this.#L = null;
  }
  #ct() {
    if (this.#u)
      return;
    this.#u = new AbortController();
    const t = this.combinedSignal(this.#u);
    document.addEventListener("copy", this.copy.bind(this), {
      signal: t
    }), document.addEventListener("cut", this.cut.bind(this), {
      signal: t
    }), document.addEventListener("paste", this.paste.bind(this), {
      signal: t
    });
  }
  #dt() {
    this.#u?.abort(), this.#u = null;
  }
  #ut() {
    const t = this._signal;
    document.addEventListener("dragover", this.dragOver.bind(this), {
      signal: t
    }), document.addEventListener("drop", this.drop.bind(this), {
      signal: t
    });
  }
  addEditListeners() {
    this.#et(), this.setEditingState(!0);
  }
  removeEditListeners() {
    this.#ht(), this.setEditingState(!1);
  }
  dragOver(t) {
    for (const {
      type: e
    } of t.dataTransfer.items)
      for (const s of this.#c)
        if (s.isHandlingMimeForPasting(e)) {
          t.dataTransfer.dropEffect = "copy", t.preventDefault();
          return;
        }
  }
  drop(t) {
    for (const e of t.dataTransfer.items)
      for (const s of this.#c)
        if (s.isHandlingMimeForPasting(e.type)) {
          s.paste(e, this.currentLayer), t.preventDefault();
          return;
        }
  }
  copy(t) {
    if (t.preventDefault(), this.#e?.commitOrRemove(), !this.hasSelection)
      return;
    const e = [];
    for (const s of this.#S) {
      const i = s.serialize(!0);
      i && e.push(i);
    }
    e.length !== 0 && t.clipboardData.setData("application/pdfjs", JSON.stringify(e));
  }
  cut(t) {
    this.copy(t), this.delete();
  }
  async paste(t) {
    t.preventDefault();
    const {
      clipboardData: e
    } = t;
    for (const n of e.items)
      for (const r of this.#c)
        if (r.isHandlingMimeForPasting(n.type)) {
          r.paste(n, this.currentLayer);
          return;
        }
    let s = e.getData("application/pdfjs");
    if (!s)
      return;
    try {
      s = JSON.parse(s);
    } catch (n) {
      R(`paste: "${n.message}".`);
      return;
    }
    if (!Array.isArray(s))
      return;
    this.unselectAll();
    const i = this.currentLayer;
    try {
      const n = [];
      for (const o of s) {
        const l = await i.deserialize(o);
        if (!l)
          return;
        n.push(l);
      }
      const r = () => {
        for (const o of n)
          this.#st(o);
        this.#it(n);
      }, a = () => {
        for (const o of n)
          o.remove();
      };
      this.addCommands({
        cmd: r,
        undo: a,
        mustExec: !0
      });
    } catch (n) {
      R(`paste: "${n.message}".`);
    }
  }
  keydown(t) {
    !this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !0), this.#T !== F.NONE && !this.isEditorHandlingKeyboard && It._keyboardManager.exec(this, t);
  }
  keyup(t) {
    this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !1, this.#w && (this.#w = !1, this.#q("main_toolbar")));
  }
  onEditingAction({
    name: t
  }) {
    switch (t) {
      case "undo":
      case "redo":
      case "delete":
      case "selectAll":
        this[t]();
        break;
      case "highlightSelection":
        this.highlightSelection("context_menu");
        break;
      case "commentSelection":
        this.commentSelection("context_menu");
        break;
    }
  }
  #D(t) {
    Object.entries(t).some(([s, i]) => this.#Y[s] !== i) && (this._eventBus.dispatch("annotationeditorstateschanged", {
      source: this,
      details: Object.assign(this.#Y, t)
    }), this.#T === F.HIGHLIGHT && t.hasSelectedEditor === !1 && this.#z([[N.HIGHLIGHT_FREE, !0]]));
  }
  #z(t) {
    this._eventBus.dispatch("annotationeditorparamschanged", {
      source: this,
      details: t
    });
  }
  setEditingState(t) {
    t ? (this.#ot(), this.#ct(), this.#D({
      isEditing: this.#T !== F.NONE,
      isEmpty: this.#K(),
      hasSomethingToUndo: this.#h.hasSomethingToUndo(),
      hasSomethingToRedo: this.#h.hasSomethingToRedo(),
      hasSelectedEditor: !1
    })) : (this.#lt(), this.#dt(), this.#D({
      isEditing: !1
    }), this.disableUserSelect(!1));
  }
  registerEditorTypes(t) {
    if (!this.#c) {
      this.#c = t;
      for (const e of this.#c)
        this.#z(e.defaultPropertiesToUpdate);
    }
  }
  getId() {
    return this.#M.id;
  }
  get currentLayer() {
    return this.#a.get(this.#f);
  }
  getLayer(t) {
    return this.#a.get(t);
  }
  get currentPageIndex() {
    return this.#f;
  }
  addLayer(t) {
    this.#a.set(t.pageIndex, t), this.#P ? t.enable() : t.disable();
  }
  removeLayer(t) {
    this.#a.delete(t.pageIndex);
  }
  async updateMode(t, e = null, s = !1, i = !1, n = !1, r = !1) {
    if (this.#T !== t && !(this.#H && (await this.#H.promise, !this.#H))) {
      if (this.#H = Promise.withResolvers(), this.#d?.commitOrRemove(), this.#T === F.POPUP && this.#l?.hideSidebar(), this.#l?.destroyPopup(), this.#T = t, t === F.NONE) {
        this.setEditingState(!1), this.#pt();
        for (const a of this.#s.values())
          a.hideStandaloneCommentButton();
        this._editorUndoBar?.hide(), this.toggleComment(null), this.#H.resolve();
        return;
      }
      for (const a of this.#s.values())
        a.addStandaloneCommentButton();
      t === F.SIGNATURE && await this.#U?.loadSignatures(), s && H.clearPointerType(), this.setEditingState(!0), await this.#ft(), this.unselectAll();
      for (const a of this.#a.values())
        a.updateMode(t);
      if (t === F.POPUP) {
        this.#i ||= await this.#W.getAnnotationsByType(new Set(this.#c.map((l) => l._editorType)));
        const a = /* @__PURE__ */ new Set(), o = [];
        for (const l of this.#s.values()) {
          const {
            annotationElementId: h,
            hasComment: c,
            deleted: u
          } = l;
          h && a.add(h), c && !u && o.push(l.getData());
        }
        for (const l of this.#i) {
          const {
            id: h,
            popupRef: c,
            contentsObj: u
          } = l;
          c && u?.str && !a.has(h) && !this.#m.has(h) && o.push(l);
        }
        this.#l?.showSidebar(o);
      }
      if (!e) {
        i && this.addNewEditorFromKeyboard(), this.#H.resolve();
        return;
      }
      for (const a of this.#s.values())
        a.uid === e ? (this.setSelected(a), r ? a.editComment() : n ? a.enterInEditMode() : a.focus()) : a.unselect();
      this.#H.resolve();
    }
  }
  addNewEditorFromKeyboard() {
    this.currentLayer.canCreateNewEmptyEditor() && this.currentLayer.addNewEditor();
  }
  updateToolbar(t) {
    t.mode !== this.#T && this._eventBus.dispatch("switchannotationeditormode", {
      source: this,
      ...t
    });
  }
  updateParams(t, e) {
    if (this.#c) {
      switch (t) {
        case N.CREATE:
          this.currentLayer.addNewEditor(e);
          return;
        case N.HIGHLIGHT_SHOW_ALL:
          this._eventBus.dispatch("reporttelemetry", {
            source: this,
            details: {
              type: "editing",
              data: {
                type: "highlight",
                action: "toggle_visibility"
              }
            }
          }), (this.#X ||= /* @__PURE__ */ new Map()).set(t, e), this.showAllEditors("highlight", e);
          break;
      }
      if (this.hasSelection)
        for (const s of this.#S)
          s.updateParams(t, e);
      else
        for (const s of this.#c)
          s.updateDefaultParams(t, e);
    }
  }
  showAllEditors(t, e, s = !1) {
    for (const n of this.#s.values())
      n.editorType === t && n.show(e);
    (this.#X?.get(N.HIGHLIGHT_SHOW_ALL) ?? !0) !== e && this.#z([[N.HIGHLIGHT_SHOW_ALL, e]]);
  }
  enableWaiting(t = !1) {
    if (this.#O !== t) {
      this.#O = t;
      for (const e of this.#a.values())
        t ? e.disableClick() : e.enableClick(), e.div.classList.toggle("waiting", t);
    }
  }
  async #ft() {
    if (!this.#P) {
      this.#P = !0;
      const t = [];
      for (const e of this.#a.values())
        t.push(e.enable());
      await Promise.all(t);
      for (const e of this.#s.values())
        e.enable();
    }
  }
  #pt() {
    if (this.unselectAll(), this.#P) {
      this.#P = !1;
      for (const t of this.#a.values())
        t.disable();
      for (const t of this.#s.values())
        t.disable();
    }
  }
  *getEditors(t) {
    for (const e of this.#s.values())
      e.pageIndex === t && (yield e);
  }
  getEditor(t) {
    return this.#s.get(t);
  }
  addEditor(t) {
    this.#s.set(t.id, t);
  }
  removeEditor(t) {
    t.div.contains(document.activeElement) && (this.#E && clearTimeout(this.#E), this.#E = setTimeout(() => {
      this.focusMainContainer(), this.#E = null;
    }, 0)), this.#s.delete(t.id), t.annotationElementId && this.#F?.delete(t.annotationElementId), this.unselect(t), (!t.annotationElementId || !this.#m.has(t.annotationElementId)) && this.#n?.remove(t.id);
  }
  addDeletedAnnotationElement(t) {
    this.#m.add(t.annotationElementId), this.addChangedExistingAnnotation(t), t.deleted = !0;
  }
  isDeletedAnnotationElement(t) {
    return this.#m.has(t);
  }
  removeDeletedAnnotationElement(t) {
    this.#m.delete(t.annotationElementId), this.removeChangedExistingAnnotation(t), t.deleted = !1;
  }
  #st(t) {
    const e = this.#a.get(t.pageIndex);
    e ? e.addOrRebuild(t) : (this.addEditor(t), this.addToAnnotationStorage(t));
  }
  setActiveEditor(t) {
    this.#e !== t && (this.#e = t, t && this.#z(t.propertiesToUpdate));
  }
  get #gt() {
    let t = null;
    for (t of this.#S)
      ;
    return t;
  }
  updateUI(t) {
    this.#gt === t && this.#z(t.propertiesToUpdate);
  }
  updateUIForDefaultProperties(t) {
    this.#z(t.defaultPropertiesToUpdate);
  }
  toggleSelected(t) {
    if (this.#S.has(t)) {
      this.#S.delete(t), t.unselect(), this.#D({
        hasSelectedEditor: this.hasSelection
      });
      return;
    }
    this.#S.add(t), t.select(), this.#z(t.propertiesToUpdate), this.#D({
      hasSelectedEditor: !0
    });
  }
  setSelected(t) {
    this.updateToolbar({
      mode: t.mode,
      editId: t.uid
    }), this.#d?.commitOrRemove();
    for (const e of this.#S)
      e !== t && e.unselect();
    this.#S.clear(), this.#S.add(t), t.select(), this.#z(t.propertiesToUpdate), this.#D({
      hasSelectedEditor: !0
    });
  }
  isSelected(t) {
    return this.#S.has(t);
  }
  get firstSelectedEditor() {
    return this.#S.values().next().value;
  }
  unselect(t) {
    t.unselect(), this.#S.delete(t), this.#D({
      hasSelectedEditor: this.hasSelection
    });
  }
  get hasSelection() {
    return this.#S.size !== 0;
  }
  get isEnterHandled() {
    return this.#S.size === 1 && this.firstSelectedEditor.isEnterHandled;
  }
  undo() {
    this.#h.undo(), this.#D({
      hasSomethingToUndo: this.#h.hasSomethingToUndo(),
      hasSomethingToRedo: !0,
      isEmpty: this.#K()
    }), this._editorUndoBar?.hide();
  }
  redo() {
    this.#h.redo(), this.#D({
      hasSomethingToUndo: !0,
      hasSomethingToRedo: this.#h.hasSomethingToRedo(),
      isEmpty: this.#K()
    });
  }
  addCommands(t) {
    this.#h.add(t), this.#D({
      hasSomethingToUndo: !0,
      hasSomethingToRedo: !1,
      isEmpty: this.#K()
    });
  }
  cleanUndoStack(t) {
    this.#h.cleanType(t);
  }
  #K() {
    if (this.#s.size === 0)
      return !0;
    if (this.#s.size === 1)
      for (const t of this.#s.values())
        return t.isEmpty();
    return !1;
  }
  delete() {
    this.commitOrRemove();
    const t = this.currentLayer?.endDrawingSession(!0);
    if (!this.hasSelection && !t)
      return;
    const e = t ? [t] : [...this.#S], s = () => {
      this._editorUndoBar?.show(i, e.length === 1 ? e[0].editorType : e.length);
      for (const n of e)
        n.remove();
    }, i = () => {
      for (const n of e)
        this.#st(n);
    };
    this.addCommands({
      cmd: s,
      undo: i,
      mustExec: !0
    });
  }
  commitOrRemove() {
    this.#e?.commitOrRemove();
  }
  hasSomethingToControl() {
    return this.#e || this.hasSelection;
  }
  #it(t) {
    for (const e of this.#S)
      e.unselect();
    this.#S.clear();
    for (const e of t)
      e.isEmpty() || (this.#S.add(e), e.select());
    this.#D({
      hasSelectedEditor: this.hasSelection
    });
  }
  selectAll() {
    for (const t of this.#S)
      t.commit();
    this.#it(this.#s.values());
  }
  unselectAll() {
    if (!(this.#e && (this.#e.commitOrRemove(), this.#T !== F.NONE)) && !this.#d?.commitOrRemove() && this.hasSelection) {
      for (const t of this.#S)
        t.unselect();
      this.#S.clear(), this.#D({
        hasSelectedEditor: !1
      });
    }
  }
  translateSelectedEditors(t, e, s = !1) {
    if (s || this.commitOrRemove(), !this.hasSelection)
      return;
    this.#j[0] += t, this.#j[1] += e;
    const [i, n] = this.#j, r = [...this.#S], a = 1e3;
    this.#N && clearTimeout(this.#N), this.#N = setTimeout(() => {
      this.#N = null, this.#j[0] = this.#j[1] = 0, this.addCommands({
        cmd: () => {
          for (const o of r)
            this.#s.has(o.id) && (o.translateInPage(i, n), o.translationDone());
        },
        undo: () => {
          for (const o of r)
            this.#s.has(o.id) && (o.translateInPage(-i, -n), o.translationDone());
        },
        mustExec: !1
      });
    }, a);
    for (const o of r)
      o.translateInPage(t, e), o.translationDone();
  }
  setUpDragSession() {
    if (this.hasSelection) {
      this.disableUserSelect(!0), this.#g = /* @__PURE__ */ new Map();
      for (const t of this.#S)
        this.#g.set(t, {
          savedX: t.x,
          savedY: t.y,
          savedPageIndex: t.pageIndex,
          newX: 0,
          newY: 0,
          newPageIndex: -1
        });
    }
  }
  endDragSession() {
    if (!this.#g)
      return !1;
    this.disableUserSelect(!1);
    const t = this.#g;
    this.#g = null;
    let e = !1;
    for (const [{
      x: i,
      y: n,
      pageIndex: r
    }, a] of t)
      a.newX = i, a.newY = n, a.newPageIndex = r, e ||= i !== a.savedX || n !== a.savedY || r !== a.savedPageIndex;
    if (!e)
      return !1;
    const s = (i, n, r, a) => {
      if (this.#s.has(i.id)) {
        const o = this.#a.get(a);
        o ? i._setParentAndPosition(o, n, r) : (i.pageIndex = a, i.x = n, i.y = r);
      }
    };
    return this.addCommands({
      cmd: () => {
        for (const [i, {
          newX: n,
          newY: r,
          newPageIndex: a
        }] of t)
          s(i, n, r, a);
      },
      undo: () => {
        for (const [i, {
          savedX: n,
          savedY: r,
          savedPageIndex: a
        }] of t)
          s(i, n, r, a);
      },
      mustExec: !0
    }), !0;
  }
  dragSelectedEditors(t, e) {
    if (this.#g)
      for (const s of this.#g.keys())
        s.drag(t, e);
  }
  rebuild(t) {
    if (t.parent === null) {
      const e = this.getLayer(t.pageIndex);
      e ? (e.changeParent(t), e.addOrRebuild(t)) : (this.addEditor(t), this.addToAnnotationStorage(t), t.rebuild());
    } else
      t.parent.addOrRebuild(t);
  }
  get isEditorHandlingKeyboard() {
    return this.getActive()?.shouldGetKeyboardEvents() || this.#S.size === 1 && this.firstSelectedEditor.shouldGetKeyboardEvents();
  }
  isActive(t) {
    return this.#e === t;
  }
  getActive() {
    return this.#e;
  }
  getMode() {
    return this.#T;
  }
  isEditingMode() {
    return this.#T !== F.NONE;
  }
  get imageManager() {
    return I(this, "imageManager", new Ss());
  }
  getSelectionBoxes(t) {
    if (!t)
      return null;
    const e = document.getSelection();
    for (let l = 0, h = e.rangeCount; l < h; l++)
      if (!t.contains(e.getRangeAt(l).commonAncestorContainer))
        return null;
    const {
      x: s,
      y: i,
      width: n,
      height: r
    } = t.getBoundingClientRect();
    let a;
    switch (t.getAttribute("data-main-rotation")) {
      case "90":
        a = (l, h, c, u) => ({
          x: (h - i) / r,
          y: 1 - (l + c - s) / n,
          width: u / r,
          height: c / n
        });
        break;
      case "180":
        a = (l, h, c, u) => ({
          x: 1 - (l + c - s) / n,
          y: 1 - (h + u - i) / r,
          width: c / n,
          height: u / r
        });
        break;
      case "270":
        a = (l, h, c, u) => ({
          x: 1 - (h + u - i) / r,
          y: (l - s) / n,
          width: u / r,
          height: c / n
        });
        break;
      default:
        a = (l, h, c, u) => ({
          x: (l - s) / n,
          y: (h - i) / r,
          width: c / n,
          height: u / r
        });
        break;
    }
    const o = [];
    for (let l = 0, h = e.rangeCount; l < h; l++) {
      const c = e.getRangeAt(l);
      if (!c.collapsed)
        for (const {
          x: u,
          y: f,
          width: g,
          height: p
        } of c.getClientRects())
          g === 0 || p === 0 || o.push(a(u, f, g, p));
    }
    return o.length === 0 ? null : o;
  }
  addChangedExistingAnnotation({
    annotationElementId: t,
    id: e
  }) {
    (this.#o ||= /* @__PURE__ */ new Map()).set(t, e);
  }
  removeChangedExistingAnnotation({
    annotationElementId: t
  }) {
    this.#o?.delete(t);
  }
  renderAnnotationElement(t) {
    const e = this.#o?.get(t.data.id);
    if (!e)
      return;
    const s = this.#n.getRawValue(e);
    s && (this.#T === F.NONE && !s.hasBeenModified || s.renderAnnotationElement(t));
  }
  setMissingCanvas(t, e, s) {
    const i = this.#F?.get(t);
    i && (i.setCanvas(e, s), this.#F.delete(t));
  }
  addMissingCanvas(t, e) {
    (this.#F ||= /* @__PURE__ */ new Map()).set(t, e);
  }
}
class xt {
  #t = null;
  #e = !1;
  #i = null;
  #s = null;
  #a = null;
  #r = null;
  #n = !1;
  #o = null;
  #h = null;
  #l = null;
  #u = null;
  #d = !1;
  static #f = null;
  static _l10n = null;
  constructor(t) {
    this.#h = t, this.#d = t._uiManager.useNewAltTextFlow, xt.#f ||= Object.freeze({
      added: "pdfjs-editor-new-alt-text-added-button",
      "added-label": "pdfjs-editor-new-alt-text-added-button-label",
      missing: "pdfjs-editor-new-alt-text-missing-button",
      "missing-label": "pdfjs-editor-new-alt-text-missing-button-label",
      review: "pdfjs-editor-new-alt-text-to-review-button",
      "review-label": "pdfjs-editor-new-alt-text-to-review-button-label"
    });
  }
  static initialize(t) {
    xt._l10n ??= t;
  }
  async render() {
    const t = this.#i = document.createElement("button");
    t.className = "altText", t.tabIndex = "0";
    const e = this.#s = document.createElement("span");
    t.append(e), this.#d ? (t.classList.add("new"), t.setAttribute("data-l10n-id", xt.#f.missing), e.setAttribute("data-l10n-id", xt.#f["missing-label"])) : (t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button"), e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button-label"));
    const s = this.#h._uiManager._signal;
    t.addEventListener("contextmenu", wt, {
      signal: s
    }), t.addEventListener("pointerdown", (n) => n.stopPropagation(), {
      signal: s
    });
    const i = (n) => {
      n.preventDefault(), this.#h._uiManager.editAltText(this.#h), this.#d && this.#h._reportTelemetry({
        action: "pdfjs.image.alt_text.image_status_label_clicked",
        data: {
          label: this.#m
        }
      });
    };
    return t.addEventListener("click", i, {
      capture: !0,
      signal: s
    }), t.addEventListener("keydown", (n) => {
      n.target === t && n.key === "Enter" && (this.#n = !0, i(n));
    }, {
      signal: s
    }), await this.#g(), t;
  }
  get #m() {
    return this.#t && "added" || this.#t === null && this.guessedText && "review" || "missing";
  }
  finish() {
    this.#i && (this.#i.focus({
      focusVisible: this.#n
    }), this.#n = !1);
  }
  isEmpty() {
    return this.#d ? this.#t === null : !this.#t && !this.#e;
  }
  hasData() {
    return this.#d ? this.#t !== null || !!this.#l : this.isEmpty();
  }
  get guessedText() {
    return this.#l;
  }
  async setGuessedText(t) {
    this.#t === null && (this.#l = t, this.#u = await xt._l10n.get("pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer", {
      generatedAltText: t
    }), this.#g());
  }
  toggleAltTextBadge(t = !1) {
    if (!this.#d || this.#t) {
      this.#o?.remove(), this.#o = null;
      return;
    }
    if (!this.#o) {
      const e = this.#o = document.createElement("div");
      e.className = "noAltTextBadge", this.#h.div.append(e);
    }
    this.#o.classList.toggle("hidden", !t);
  }
  serialize(t) {
    let e = this.#t;
    return !t && this.#l === e && (e = this.#u), {
      altText: e,
      decorative: this.#e,
      guessedText: this.#l,
      textWithDisclaimer: this.#u
    };
  }
  get data() {
    return {
      altText: this.#t,
      decorative: this.#e
    };
  }
  set data({
    altText: t,
    decorative: e,
    guessedText: s,
    textWithDisclaimer: i,
    cancel: n = !1
  }) {
    s && (this.#l = s, this.#u = i), !(this.#t === t && this.#e === e) && (n || (this.#t = t, this.#e = e), this.#g());
  }
  toggle(t = !1) {
    this.#i && (!t && this.#r && (clearTimeout(this.#r), this.#r = null), this.#i.disabled = !t);
  }
  shown() {
    this.#h._reportTelemetry({
      action: "pdfjs.image.alt_text.image_status_label_displayed",
      data: {
        label: this.#m
      }
    });
  }
  destroy() {
    this.#i?.remove(), this.#i = null, this.#s = null, this.#a = null, this.#o?.remove(), this.#o = null;
  }
  async #g() {
    const t = this.#i;
    if (!t)
      return;
    if (this.#d) {
      if (t.classList.toggle("done", !!this.#t), t.setAttribute("data-l10n-id", xt.#f[this.#m]), this.#s?.setAttribute("data-l10n-id", xt.#f[`${this.#m}-label`]), !this.#t) {
        this.#a?.remove();
        return;
      }
    } else {
      if (!this.#t && !this.#e) {
        t.classList.remove("done"), this.#a?.remove();
        return;
      }
      t.classList.add("done"), t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-edit-button");
    }
    let e = this.#a;
    if (!e) {
      this.#a = e = document.createElement("span"), e.className = "tooltip", e.setAttribute("role", "tooltip"), e.id = `alt-text-tooltip-${this.#h.id}`;
      const i = 100, n = this.#h._uiManager._signal;
      n.addEventListener("abort", () => {
        clearTimeout(this.#r), this.#r = null;
      }, {
        once: !0
      }), t.addEventListener("mouseenter", () => {
        this.#r = setTimeout(() => {
          this.#r = null, this.#a.classList.add("show"), this.#h._reportTelemetry({
            action: "alt_text_tooltip"
          });
        }, i);
      }, {
        signal: n
      }), t.addEventListener("mouseleave", () => {
        this.#r && (clearTimeout(this.#r), this.#r = null), this.#a?.classList.remove("show");
      }, {
        signal: n
      });
    }
    this.#e ? e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-decorative-tooltip") : (e.removeAttribute("data-l10n-id"), e.textContent = this.#t), e.parentNode || t.append(e), this.#h.getElementForAltText()?.setAttribute("aria-describedby", e.id);
  }
}
class Ce {
  #t = null;
  #e = null;
  #i = !1;
  #s = null;
  #a = null;
  #r = null;
  #n = null;
  #o = null;
  #h = !1;
  #l = null;
  constructor(t) {
    this.#s = t;
  }
  renderForToolbar() {
    const t = this.#e = document.createElement("button");
    return t.className = "comment", this.#u(t, !1);
  }
  renderForStandalone() {
    const t = this.#t = document.createElement("button");
    t.className = "annotationCommentButton";
    const e = this.#s.commentButtonPosition;
    if (e) {
      const {
        style: s
      } = t;
      s.insetInlineEnd = `calc(${100 * (this.#s._uiManager.direction === "ltr" ? 1 - e[0] : e[0])}% - var(--comment-button-dim))`, s.top = `calc(${100 * e[1]}% - var(--comment-button-dim))`;
      const i = this.#s.commentButtonColor;
      i && (s.backgroundColor = i);
    }
    return this.#u(t, !0);
  }
  focusButton() {
    setTimeout(() => {
      (this.#t ?? this.#e)?.focus();
    }, 0);
  }
  onUpdatedColor() {
    if (!this.#t)
      return;
    const t = this.#s.commentButtonColor;
    t && (this.#t.style.backgroundColor = t), this.#s._uiManager.updatePopupColor(this.#s);
  }
  get commentButtonWidth() {
    return (this.#t?.getBoundingClientRect().width ?? 0) / this.#s.parent.boundingClientRect.width;
  }
  get commentPopupPositionInLayer() {
    if (this.#l)
      return this.#l;
    if (!this.#t)
      return null;
    const {
      x: t,
      y: e,
      height: s
    } = this.#t.getBoundingClientRect(), {
      x: i,
      y: n,
      width: r,
      height: a
    } = this.#s.parent.boundingClientRect;
    return [(t - i) / r, (e + s - n) / a];
  }
  set commentPopupPositionInLayer(t) {
    this.#l = t;
  }
  hasDefaultPopupPosition() {
    return this.#l === null;
  }
  removeStandaloneCommentButton() {
    this.#t?.remove(), this.#t = null;
  }
  removeToolbarCommentButton() {
    this.#e?.remove(), this.#e = null;
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    this.#t && (this.#t.classList.toggle("selected", t), this.#t.ariaExpanded = e);
  }
  #u(t, e) {
    if (!this.#s._uiManager.hasCommentManager())
      return null;
    t.tabIndex = "0", t.ariaHasPopup = "dialog", e ? (t.ariaControls = "commentPopup", t.setAttribute("data-l10n-id", "pdfjs-show-comment-button")) : (t.ariaControlsElements = [this.#s._uiManager.getCommentDialogElement()], t.setAttribute("data-l10n-id", "pdfjs-editor-add-comment-button"));
    const s = this.#s._uiManager._signal;
    if (!(s instanceof AbortSignal) || s.aborted)
      return t;
    t.addEventListener("contextmenu", wt, {
      signal: s
    }), e && (t.addEventListener("focusin", (n) => {
      this.#s._focusEventsAllowed = !1, K(n);
    }, {
      capture: !0,
      signal: s
    }), t.addEventListener("focusout", (n) => {
      this.#s._focusEventsAllowed = !0, K(n);
    }, {
      capture: !0,
      signal: s
    })), t.addEventListener("pointerdown", (n) => n.stopPropagation(), {
      signal: s
    });
    const i = (n) => {
      n.preventDefault(), t === this.#e ? this.edit() : this.#s.toggleComment(!0);
    };
    return t.addEventListener("click", i, {
      capture: !0,
      signal: s
    }), t.addEventListener("keydown", (n) => {
      n.target === t && n.key === "Enter" && (this.#i = !0, i(n));
    }, {
      signal: s
    }), t.addEventListener("pointerenter", () => {
      this.#s.toggleComment(!1, !0);
    }, {
      signal: s
    }), t.addEventListener("pointerleave", () => {
      this.#s.toggleComment(!1, !1);
    }, {
      signal: s
    }), t;
  }
  edit(t) {
    const e = this.commentPopupPositionInLayer;
    let s, i;
    if (e)
      [s, i] = e;
    else {
      [s, i] = this.#s.commentButtonPosition;
      const {
        width: h,
        height: c,
        x: u,
        y: f
      } = this.#s;
      s = u + s * h, i = f + i * c;
    }
    const n = this.#s.parent.boundingClientRect, {
      x: r,
      y: a,
      width: o,
      height: l
    } = n;
    this.#s._uiManager.editComment(this.#s, r + s * o, a + i * l, {
      ...t,
      parentDimensions: n
    });
  }
  finish() {
    this.#e && (this.#e.focus({
      focusVisible: this.#i
    }), this.#i = !1);
  }
  isDeleted() {
    return this.#h || this.#n === "";
  }
  isEmpty() {
    return this.#n === null;
  }
  hasBeenEdited() {
    return this.isDeleted() || this.#n !== this.#a;
  }
  serialize() {
    return this.data;
  }
  get data() {
    return {
      text: this.#n,
      richText: this.#r,
      date: this.#o,
      deleted: this.isDeleted()
    };
  }
  set data(t) {
    if (t !== this.#n && (this.#r = null), t === null) {
      this.#n = "", this.#h = !0;
      return;
    }
    this.#n = t, this.#o = /* @__PURE__ */ new Date(), this.#h = !1;
  }
  restoreData({
    text: t,
    richText: e,
    date: s
  }) {
    this.#n = t, this.#r = e, this.#o = s, this.#h = !1;
  }
  setInitialText(t, e = null) {
    this.#a = t, this.data = t, this.#o = null, this.#r = e;
  }
  shown() {
  }
  destroy() {
    this.#e?.remove(), this.#e = null, this.#t?.remove(), this.#t = null, this.#n = "", this.#r = null, this.#o = null, this.#s = null, this.#i = !1, this.#h = !1;
  }
}
class Ee {
  #t;
  #e = !1;
  #i = null;
  #s;
  #a;
  #r;
  #n;
  #o = null;
  #h;
  #l = null;
  #u;
  #d = null;
  constructor({
    container: t,
    isPinchingDisabled: e = null,
    isPinchingStopped: s = null,
    onPinchStart: i = null,
    onPinching: n = null,
    onPinchEnd: r = null,
    signal: a
  }) {
    this.#t = t, this.#i = s, this.#s = e, this.#a = i, this.#r = n, this.#n = r, this.#u = new AbortController(), this.#h = AbortSignal.any([a, this.#u.signal]), t.addEventListener("touchstart", this.#f.bind(this), {
      passive: !1,
      signal: this.#h
    });
  }
  get MIN_TOUCH_DISTANCE_TO_PINCH() {
    return 35 / Et.pixelRatio;
  }
  #f(t) {
    if (this.#s?.())
      return;
    if (t.touches.length === 1) {
      if (this.#o)
        return;
      const i = this.#o = new AbortController(), n = AbortSignal.any([this.#h, i.signal]), r = this.#t, a = {
        capture: !0,
        signal: n,
        passive: !1
      }, o = (l) => {
        l.pointerType === "touch" && (this.#o?.abort(), this.#o = null);
      };
      r.addEventListener("pointerdown", (l) => {
        l.pointerType === "touch" && (K(l), o(l));
      }, a), r.addEventListener("pointerup", o, a), r.addEventListener("pointercancel", o, a);
      return;
    }
    if (!this.#d) {
      this.#d = new AbortController();
      const i = AbortSignal.any([this.#h, this.#d.signal]), n = this.#t, r = {
        signal: i,
        capture: !1,
        passive: !1
      };
      n.addEventListener("touchmove", this.#m.bind(this), r);
      const a = this.#g.bind(this);
      n.addEventListener("touchend", a, r), n.addEventListener("touchcancel", a, r), r.capture = !0, n.addEventListener("pointerdown", K, r), n.addEventListener("pointermove", K, r), n.addEventListener("pointercancel", K, r), n.addEventListener("pointerup", K, r), this.#a?.();
    }
    if (K(t), t.touches.length !== 2 || this.#i?.()) {
      this.#l = null;
      return;
    }
    let [e, s] = t.touches;
    e.identifier > s.identifier && ([e, s] = [s, e]), this.#l = {
      touch0X: e.screenX,
      touch0Y: e.screenY,
      touch1X: s.screenX,
      touch1Y: s.screenY
    };
  }
  #m(t) {
    if (!this.#l || t.touches.length !== 2)
      return;
    K(t);
    let [e, s] = t.touches;
    e.identifier > s.identifier && ([e, s] = [s, e]);
    const {
      screenX: i,
      screenY: n
    } = e, {
      screenX: r,
      screenY: a
    } = s, o = this.#l, {
      touch0X: l,
      touch0Y: h,
      touch1X: c,
      touch1Y: u
    } = o, f = c - l, g = u - h, p = r - i, b = a - n, m = Math.hypot(p, b) || 1, y = Math.hypot(f, g) || 1;
    if (!this.#e && Math.abs(y - m) <= Ee.MIN_TOUCH_DISTANCE_TO_PINCH)
      return;
    if (o.touch0X = i, o.touch0Y = n, o.touch1X = r, o.touch1Y = a, !this.#e) {
      this.#e = !0;
      return;
    }
    const A = [(i + r) / 2, (n + a) / 2];
    this.#r?.(A, y, m);
  }
  #g(t) {
    t.touches.length >= 2 || (this.#d && (this.#d.abort(), this.#d = null, this.#n?.()), this.#l && (K(t), this.#l = null, this.#e = !1));
  }
  destroy() {
    this.#u?.abort(), this.#u = null, this.#o?.abort(), this.#o = null;
  }
}
class D {
  #t = null;
  #e = null;
  #i = null;
  #s = null;
  #a = null;
  #r = !1;
  #n = null;
  #o = "";
  #h = null;
  #l = null;
  #u = null;
  #d = null;
  #f = null;
  #m = "";
  #g = !1;
  #c = null;
  #p = !1;
  #b = !1;
  #y = !1;
  #A = null;
  #C = 0;
  #E = 0;
  #v = null;
  #x = null;
  isSelected = !1;
  _isCopy = !1;
  _editToolbar = null;
  _initialOptions = /* @__PURE__ */ Object.create(null);
  _initialData = null;
  _isVisible = !0;
  _uiManager = null;
  _focusEventsAllowed = !0;
  static _l10n = null;
  static _l10nResizer = null;
  #w = !1;
  #_ = D._zIndex++;
  static _borderLineWidth = -1;
  static _colorManager = new Es();
  static _zIndex = 1;
  static _telemetryTimeout = 1e3;
  static get _resizerKeyboardManager() {
    const t = D.prototype._resizeWithKeyboard, e = It.TRANSLATE_SMALL, s = It.TRANSLATE_BIG;
    return I(this, "_resizerKeyboardManager", new Se([[["ArrowLeft", "mac+ArrowLeft"], t, {
      args: [-e, 0]
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t, {
      args: [-s, 0]
    }], [["ArrowRight", "mac+ArrowRight"], t, {
      args: [e, 0]
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t, {
      args: [s, 0]
    }], [["ArrowUp", "mac+ArrowUp"], t, {
      args: [0, -e]
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t, {
      args: [0, -s]
    }], [["ArrowDown", "mac+ArrowDown"], t, {
      args: [0, e]
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t, {
      args: [0, s]
    }], [["Escape", "mac+Escape"], D.prototype._stopResizingWithKeyboard]]));
  }
  constructor(t) {
    this.parent = t.parent, this.id = t.id, this.width = this.height = null, this.pageIndex = t.parent.pageIndex, this.name = t.name, this.div = null, this._uiManager = t.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = t.isCentered, this._structTreeParentId = null, this.annotationElementId = t.annotationElementId || null, this.creationDate = t.creationDate || /* @__PURE__ */ new Date(), this.modificationDate = t.modificationDate || null, this.canAddComment = !0;
    const {
      rotation: e,
      rawDims: {
        pageWidth: s,
        pageHeight: i,
        pageX: n,
        pageY: r
      }
    } = this.parent.viewport;
    this.rotation = e, this.pageRotation = (360 + e - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [s, i], this.pageTranslation = [n, r];
    const [a, o] = this.parentDimensions;
    this.x = t.x / a, this.y = t.y / o, this.isAttachedToDOM = !1, this.deleted = !1;
  }
  updatePageIndex(t) {
    this.pageIndex = t;
  }
  get editorType() {
    return Object.getPrototypeOf(this).constructor._type;
  }
  get mode() {
    return Object.getPrototypeOf(this).constructor._editorType;
  }
  static get isDrawer() {
    return !1;
  }
  static get _defaultLineColor() {
    return I(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
  }
  static deleteAnnotationElement(t) {
    const e = new pn({
      id: t.parent.getNextId(),
      parent: t.parent,
      uiManager: t._uiManager
    });
    e.annotationElementId = t.annotationElementId, e.deleted = !0, e._uiManager.addToAnnotationStorage(e);
  }
  static initialize(t, e) {
    if (D._l10n ??= t, D._l10nResizer ||= Object.freeze({
      topLeft: "pdfjs-editor-resizer-top-left",
      topMiddle: "pdfjs-editor-resizer-top-middle",
      topRight: "pdfjs-editor-resizer-top-right",
      middleRight: "pdfjs-editor-resizer-middle-right",
      bottomRight: "pdfjs-editor-resizer-bottom-right",
      bottomMiddle: "pdfjs-editor-resizer-bottom-middle",
      bottomLeft: "pdfjs-editor-resizer-bottom-left",
      middleLeft: "pdfjs-editor-resizer-middle-left"
    }), D._borderLineWidth !== -1)
      return;
    const s = getComputedStyle(document.documentElement);
    D._borderLineWidth = parseFloat(s.getPropertyValue("--outline-width")) || 0;
  }
  static updateDefaultParams(t, e) {
  }
  static get defaultPropertiesToUpdate() {
    return [];
  }
  static isHandlingMimeForPasting(t) {
    return !1;
  }
  static paste(t, e) {
    j("Not implemented");
  }
  get propertiesToUpdate() {
    return [];
  }
  get _isDraggable() {
    return this.#w;
  }
  set _isDraggable(t) {
    this.#w = t, this.div?.classList.toggle("draggable", t);
  }
  get uid() {
    return this.annotationElementId || this.id;
  }
  get isEnterHandled() {
    return !0;
  }
  center() {
    const [t, e] = this.pageDimensions;
    switch (this.parentRotation) {
      case 90:
        this.x -= this.height * e / (t * 2), this.y += this.width * t / (e * 2);
        break;
      case 180:
        this.x += this.width / 2, this.y += this.height / 2;
        break;
      case 270:
        this.x += this.height * e / (t * 2), this.y -= this.width * t / (e * 2);
        break;
      default:
        this.x -= this.width / 2, this.y -= this.height / 2;
        break;
    }
    this.fixAndSetPosition();
  }
  addCommands(t) {
    this._uiManager.addCommands(t);
  }
  get currentLayer() {
    return this._uiManager.currentLayer;
  }
  setInBackground() {
    this.div.style.zIndex = 0;
  }
  setInForeground() {
    this.div.style.zIndex = this.#_;
  }
  setParent(t) {
    t !== null ? (this.pageIndex = t.pageIndex, this.pageDimensions = t.pageDimensions) : (this.#N(), this.#d?.remove(), this.#d = null), this.parent = t;
  }
  focusin(t) {
    this._focusEventsAllowed && (this.#g ? this.#g = !1 : this.parent.setSelected(this));
  }
  focusout(t) {
    !this._focusEventsAllowed || !this.isAttachedToDOM || t.relatedTarget?.closest(`#${this.id}`) || (t.preventDefault(), this.parent?.isMultipleSelection || this.commitOrRemove());
  }
  commitOrRemove() {
    this.isEmpty() ? this.remove() : this.commit();
  }
  commit() {
    this.isInEditMode() && this.addToAnnotationStorage();
  }
  addToAnnotationStorage() {
    this._uiManager.addToAnnotationStorage(this);
  }
  setAt(t, e, s, i) {
    const [n, r] = this.parentDimensions;
    [s, i] = this.screenToPageTranslation(s, i), this.x = (t + s) / n, this.y = (e + i) / r, this.fixAndSetPosition();
  }
  _moveAfterPaste(t, e) {
    const [s, i] = this.parentDimensions;
    this.setAt(t * s, e * i, this.width * s, this.height * i), this._onTranslated();
  }
  #M([t, e], s, i) {
    [s, i] = this.screenToPageTranslation(s, i), this.x += s / t, this.y += i / e, this._onTranslating(this.x, this.y), this.fixAndSetPosition();
  }
  translate(t, e) {
    this.#M(this.parentDimensions, t, e);
  }
  translateInPage(t, e) {
    this.#c ||= [this.x, this.y, this.width, this.height], this.#M(this.pageDimensions, t, e), this.div.scrollIntoView({
      block: "nearest"
    });
  }
  translationDone() {
    this._onTranslated(this.x, this.y);
  }
  drag(t, e) {
    this.#c ||= [this.x, this.y, this.width, this.height];
    const {
      div: s,
      parentDimensions: [i, n]
    } = this;
    if (this.x += t / i, this.y += e / n, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
      const {
        x: c,
        y: u
      } = this.div.getBoundingClientRect();
      this.parent.findNewParent(this, c, u) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
    }
    let {
      x: r,
      y: a
    } = this;
    const [o, l] = this.getBaseTranslation();
    r += o, a += l;
    const {
      style: h
    } = s;
    h.left = `${(100 * r).toFixed(2)}%`, h.top = `${(100 * a).toFixed(2)}%`, this._onTranslating(r, a), s.scrollIntoView({
      block: "nearest"
    });
  }
  _onTranslating(t, e) {
  }
  _onTranslated(t, e) {
  }
  get _hasBeenMoved() {
    return !!this.#c && (this.#c[0] !== this.x || this.#c[1] !== this.y);
  }
  get _hasBeenResized() {
    return !!this.#c && (this.#c[2] !== this.width || this.#c[3] !== this.height);
  }
  getBaseTranslation() {
    const [t, e] = this.parentDimensions, {
      _borderLineWidth: s
    } = D, i = s / t, n = s / e;
    switch (this.rotation) {
      case 90:
        return [-i, n];
      case 180:
        return [i, n];
      case 270:
        return [i, -n];
      default:
        return [-i, -n];
    }
  }
  get _mustFixPosition() {
    return !0;
  }
  fixAndSetPosition(t = this.rotation) {
    const {
      div: {
        style: e
      },
      pageDimensions: [s, i]
    } = this;
    let {
      x: n,
      y: r,
      width: a,
      height: o
    } = this;
    if (a *= s, o *= i, n *= s, r *= i, this._mustFixPosition)
      switch (t) {
        case 0:
          n = ct(n, 0, s - a), r = ct(r, 0, i - o);
          break;
        case 90:
          n = ct(n, 0, s - o), r = ct(r, a, i);
          break;
        case 180:
          n = ct(n, a, s), r = ct(r, o, i);
          break;
        case 270:
          n = ct(n, o, s), r = ct(r, 0, i - a);
          break;
      }
    this.x = n /= s, this.y = r /= i;
    const [l, h] = this.getBaseTranslation();
    n += l, r += h, e.left = `${(100 * n).toFixed(2)}%`, e.top = `${(100 * r).toFixed(2)}%`, this.moveInDOM();
  }
  static #P(t, e, s) {
    switch (s) {
      case 90:
        return [e, -t];
      case 180:
        return [-t, -e];
      case 270:
        return [-e, t];
      default:
        return [t, e];
    }
  }
  screenToPageTranslation(t, e) {
    return D.#P(t, e, this.parentRotation);
  }
  pageTranslationToScreen(t, e) {
    return D.#P(t, e, 360 - this.parentRotation);
  }
  #k(t) {
    switch (t) {
      case 90: {
        const [e, s] = this.pageDimensions;
        return [0, -e / s, s / e, 0];
      }
      case 180:
        return [-1, 0, 0, -1];
      case 270: {
        const [e, s] = this.pageDimensions;
        return [0, e / s, -s / e, 0];
      }
      default:
        return [1, 0, 0, 1];
    }
  }
  get parentScale() {
    return this._uiManager.viewParameters.realScale;
  }
  get parentRotation() {
    return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
  }
  get parentDimensions() {
    const {
      parentScale: t,
      pageDimensions: [e, s]
    } = this;
    return [e * t, s * t];
  }
  setDims() {
    const {
      div: {
        style: t
      },
      width: e,
      height: s
    } = this;
    t.width = `${(100 * e).toFixed(2)}%`, t.height = `${(100 * s).toFixed(2)}%`;
  }
  getInitialTranslation() {
    return [0, 0];
  }
  #O() {
    if (this.#h)
      return;
    this.#h = document.createElement("div"), this.#h.classList.add("resizers");
    const t = this._willKeepAspectRatio ? ["topLeft", "topRight", "bottomRight", "bottomLeft"] : ["topLeft", "topMiddle", "topRight", "middleRight", "bottomRight", "bottomMiddle", "bottomLeft", "middleLeft"], e = this._uiManager._signal;
    for (const s of t) {
      const i = document.createElement("div");
      this.#h.append(i), i.classList.add("resizer", s), i.setAttribute("data-resizer-name", s), i.addEventListener("pointerdown", this.#L.bind(this, s), {
        signal: e
      }), i.addEventListener("contextmenu", wt, {
        signal: e
      }), i.tabIndex = -1;
    }
    this.div.prepend(this.#h);
  }
  #L(t, e) {
    e.preventDefault();
    const {
      isMac: s
    } = nt.platform;
    if (e.button !== 0 || e.ctrlKey && s)
      return;
    this.#i?.toggle(!1);
    const i = this._isDraggable;
    this._isDraggable = !1, this.#l = [e.screenX, e.screenY];
    const n = new AbortController(), r = this._uiManager.combinedSignal(n);
    this.parent.togglePointerEvents(!1), window.addEventListener("pointermove", this.#F.bind(this, t), {
      passive: !0,
      capture: !0,
      signal: r
    }), window.addEventListener("touchmove", K, {
      passive: !1,
      signal: r
    }), window.addEventListener("contextmenu", wt, {
      signal: r
    }), this.#u = {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    };
    const a = this.parent.div.style.cursor, o = this.div.style.cursor;
    this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(e.target).cursor;
    const l = () => {
      n.abort(), this.parent.togglePointerEvents(!0), this.#i?.toggle(!0), this._isDraggable = i, this.parent.div.style.cursor = a, this.div.style.cursor = o, this.#B();
    };
    window.addEventListener("pointerup", l, {
      signal: r
    }), window.addEventListener("blur", l, {
      signal: r
    });
  }
  #R(t, e, s, i) {
    this.width = s, this.height = i, this.x = t, this.y = e, this.setDims(), this.fixAndSetPosition(), this._onResized();
  }
  _onResized() {
  }
  #B() {
    if (!this.#u)
      return;
    const {
      savedX: t,
      savedY: e,
      savedWidth: s,
      savedHeight: i
    } = this.#u;
    this.#u = null;
    const n = this.x, r = this.y, a = this.width, o = this.height;
    n === t && r === e && a === s && o === i || this.addCommands({
      cmd: this.#R.bind(this, n, r, a, o),
      undo: this.#R.bind(this, t, e, s, i),
      mustExec: !0
    });
  }
  static _round(t) {
    return Math.round(t * 1e4) / 1e4;
  }
  #F(t, e) {
    const [s, i] = this.parentDimensions, n = this.x, r = this.y, a = this.width, o = this.height, l = D.MIN_SIZE / s, h = D.MIN_SIZE / i, c = this.#k(this.rotation), u = (M, L) => [c[0] * M + c[2] * L, c[1] * M + c[3] * L], f = this.#k(360 - this.rotation), g = (M, L) => [f[0] * M + f[2] * L, f[1] * M + f[3] * L];
    let p, b, m = !1, y = !1;
    switch (t) {
      case "topLeft":
        m = !0, p = (M, L) => [0, 0], b = (M, L) => [M, L];
        break;
      case "topMiddle":
        p = (M, L) => [M / 2, 0], b = (M, L) => [M / 2, L];
        break;
      case "topRight":
        m = !0, p = (M, L) => [M, 0], b = (M, L) => [0, L];
        break;
      case "middleRight":
        y = !0, p = (M, L) => [M, L / 2], b = (M, L) => [0, L / 2];
        break;
      case "bottomRight":
        m = !0, p = (M, L) => [M, L], b = (M, L) => [0, 0];
        break;
      case "bottomMiddle":
        p = (M, L) => [M / 2, L], b = (M, L) => [M / 2, 0];
        break;
      case "bottomLeft":
        m = !0, p = (M, L) => [0, L], b = (M, L) => [M, 0];
        break;
      case "middleLeft":
        y = !0, p = (M, L) => [0, L / 2], b = (M, L) => [M, L / 2];
        break;
    }
    const A = p(a, o), v = b(a, o);
    let w = u(...v);
    const S = D._round(n + w[0]), E = D._round(r + w[1]);
    let _ = 1, C = 1, k, x;
    if (e.fromKeyboard)
      ({
        deltaX: k,
        deltaY: x
      } = e);
    else {
      const {
        screenX: M,
        screenY: L
      } = e, [G, mt] = this.#l;
      [k, x] = this.screenToPageTranslation(M - G, L - mt), this.#l[0] = M, this.#l[1] = L;
    }
    if ([k, x] = g(k / s, x / i), m) {
      const M = Math.hypot(a, o);
      _ = C = Math.max(Math.min(Math.hypot(v[0] - A[0] - k, v[1] - A[1] - x) / M, 1 / a, 1 / o), l / a, h / o);
    } else y ? _ = ct(Math.abs(v[0] - A[0] - k), l, 1) / a : C = ct(Math.abs(v[1] - A[1] - x), h, 1) / o;
    const z = D._round(a * _), W = D._round(o * C);
    w = u(...b(z, W));
    const O = S - w[0], tt = E - w[1];
    this.#c ||= [this.x, this.y, this.width, this.height], this.width = z, this.height = W, this.x = O, this.y = tt, this.setDims(), this.fixAndSetPosition(), this._onResizing();
  }
  _onResizing() {
  }
  altTextFinish() {
    this.#i?.finish();
  }
  get toolbarButtons() {
    return null;
  }
  async addEditToolbar() {
    if (this._editToolbar || this.#b)
      return this._editToolbar;
    this._editToolbar = new fe(this), this.div.append(this._editToolbar.render());
    const {
      toolbarButtons: t
    } = this;
    if (t)
      for (const [e, s] of t)
        await this._editToolbar.addButton(e, s);
    return this.hasComment || this._editToolbar.addButton("comment", this.addCommentButton()), this._editToolbar.addButton("delete"), this._editToolbar;
  }
  addCommentButtonInToolbar() {
    this._editToolbar?.addButtonBefore("comment", this.addCommentButton(), ".deleteButton");
  }
  removeCommentButtonFromToolbar() {
    this._editToolbar?.removeButton("comment");
  }
  removeEditToolbar() {
    this._editToolbar?.remove(), this._editToolbar = null, this.#i?.destroy();
  }
  addContainer(t) {
    const e = this._editToolbar?.div;
    e ? e.before(t) : this.div.append(t);
  }
  getClientDimensions() {
    return this.div.getBoundingClientRect();
  }
  createAltText() {
    return this.#i || (xt.initialize(D._l10n), this.#i = new xt(this), this.#t && (this.#i.data = this.#t, this.#t = null)), this.#i;
  }
  get altTextData() {
    return this.#i?.data;
  }
  set altTextData(t) {
    this.#i && (this.#i.data = t);
  }
  get guessedAltText() {
    return this.#i?.guessedText;
  }
  async setGuessedAltText(t) {
    await this.#i?.setGuessedText(t);
  }
  serializeAltText(t) {
    return this.#i?.serialize(t);
  }
  hasAltText() {
    return !!this.#i && !this.#i.isEmpty();
  }
  hasAltTextData() {
    return this.#i?.hasData() ?? !1;
  }
  focusCommentButton() {
    this.#s?.focusButton();
  }
  addCommentButton() {
    return this.canAddComment ? this.#s ||= new Ce(this) : null;
  }
  addStandaloneCommentButton() {
    if (this._uiManager.hasCommentManager()) {
      if (this.#a) {
        this._uiManager.isEditingMode() && this.#a.classList.remove("hidden");
        return;
      }
      this.hasComment && (this.#a = this.#s.renderForStandalone(), this.div.append(this.#a));
    }
  }
  removeStandaloneCommentButton() {
    this.#s.removeStandaloneCommentButton(), this.#a = null;
  }
  hideStandaloneCommentButton() {
    this.#a?.classList.add("hidden");
  }
  get comment() {
    if (!this.#s)
      return null;
    const {
      data: {
        richText: t,
        text: e,
        date: s,
        deleted: i
      }
    } = this.#s;
    return {
      text: e,
      richText: t,
      date: s,
      deleted: i,
      color: this.getNonHCMColor(),
      opacity: this.opacity ?? 1
    };
  }
  set comment(t) {
    this.#s ||= new Ce(this), typeof t == "object" && t !== null ? this.#s.restoreData(t) : this.#s.data = t, this.hasComment ? (this.removeCommentButtonFromToolbar(), this.addStandaloneCommentButton(), this._uiManager.updateComment(this)) : (this.addCommentButtonInToolbar(), this.removeStandaloneCommentButton(), this._uiManager.removeComment(this));
  }
  setCommentData({
    comment: t,
    popupRef: e,
    richText: s
  }) {
    if (!e || (this.#s ||= new Ce(this), this.#s.setInitialText(t, s), !this.annotationElementId))
      return;
    const i = this._uiManager.getAndRemoveDataFromAnnotationStorage(this.annotationElementId);
    i && this.updateFromAnnotationLayer(i);
  }
  get hasEditedComment() {
    return this.#s?.hasBeenEdited();
  }
  get hasDeletedComment() {
    return this.#s?.isDeleted();
  }
  get hasComment() {
    return !!this.#s && !this.#s.isEmpty() && !this.#s.isDeleted();
  }
  async editComment(t) {
    this.#s ||= new Ce(this), this.#s.edit(t);
  }
  toggleComment(t, e = void 0) {
    this.hasComment && this._uiManager.toggleComment(this, t, e);
  }
  setSelectedCommentButton(t) {
    this.#s.setSelectedButton(t);
  }
  addComment(t) {
    if (this.hasEditedComment) {
      const [, , , i] = t.rect, [n] = this.pageDimensions, [r] = this.pageTranslation, a = r + n + 1, o = i - 100, l = a + 180;
      t.popup = {
        contents: this.comment.text,
        deleted: this.comment.deleted,
        rect: [a, o, l, i]
      };
    }
  }
  updateFromAnnotationLayer({
    popup: {
      contents: t,
      deleted: e
    }
  }) {
    this.#s.data = e ? null : t;
  }
  get parentBoundingClientRect() {
    return this.parent.boundingClientRect;
  }
  render() {
    const t = this.div = document.createElement("div");
    t.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), t.className = this.name, t.setAttribute("id", this.id), t.tabIndex = this.#r ? -1 : 0, t.setAttribute("role", "application"), this.defaultL10nId && t.setAttribute("data-l10n-id", this.defaultL10nId), this._isVisible || t.classList.add("hidden"), this.setInForeground(), this.#$();
    const [e, s] = this.parentDimensions;
    this.parentRotation % 180 !== 0 && (t.style.maxWidth = `${(100 * s / e).toFixed(2)}%`, t.style.maxHeight = `${(100 * e / s).toFixed(2)}%`);
    const [i, n] = this.getInitialTranslation();
    return this.translate(i, n), wi(this, t, ["keydown", "pointerdown", "dblclick"]), this.isResizable && this._uiManager._supportsPinchToZoom && (this.#x ||= new Ee({
      container: t,
      isPinchingDisabled: () => !this.isSelected,
      onPinchStart: this.#G.bind(this),
      onPinching: this.#T.bind(this),
      onPinchEnd: this.#S.bind(this),
      signal: this._uiManager._signal
    })), this.addStandaloneCommentButton(), this._uiManager._editorUndoBar?.hide(), t;
  }
  #G() {
    this.#u = {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    }, this.#i?.toggle(!1), this.parent.togglePointerEvents(!1);
  }
  #T(t, e, s) {
    let n = 0.7 * (s / e) + 1 - 0.7;
    if (n === 1)
      return;
    const r = this.#k(this.rotation), a = (S, E) => [r[0] * S + r[2] * E, r[1] * S + r[3] * E], [o, l] = this.parentDimensions, h = this.x, c = this.y, u = this.width, f = this.height, g = D.MIN_SIZE / o, p = D.MIN_SIZE / l;
    n = Math.max(Math.min(n, 1 / u, 1 / f), g / u, p / f);
    const b = D._round(u * n), m = D._round(f * n);
    if (b === u && m === f)
      return;
    this.#c ||= [h, c, u, f];
    const y = a(u / 2, f / 2), A = D._round(h + y[0]), v = D._round(c + y[1]), w = a(b / 2, m / 2);
    this.x = A - w[0], this.y = v - w[1], this.width = b, this.height = m, this.setDims(), this.fixAndSetPosition(), this._onResizing();
  }
  #S() {
    this.#i?.toggle(!0), this.parent.togglePointerEvents(!0), this.#B();
  }
  pointerdown(t) {
    const {
      isMac: e
    } = nt.platform;
    if (t.button !== 0 || t.ctrlKey && e) {
      t.preventDefault();
      return;
    }
    if (this.#g = !0, this._isDraggable) {
      this.#U(t);
      return;
    }
    this.#I(t);
  }
  #I(t) {
    const {
      isMac: e
    } = nt.platform;
    t.ctrlKey && !e || t.shiftKey || t.metaKey && e ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
  }
  #U(t) {
    const {
      isSelected: e
    } = this;
    this._uiManager.setUpDragSession();
    let s = !1;
    const i = new AbortController(), n = this._uiManager.combinedSignal(i), r = {
      capture: !0,
      passive: !1,
      signal: n
    }, a = (l) => {
      i.abort(), this.#n = null, this.#g = !1, this._uiManager.endDragSession() || this.#I(l), s && this._onStopDragging();
    };
    e && (this.#C = t.clientX, this.#E = t.clientY, this.#n = t.pointerId, this.#o = t.pointerType, window.addEventListener("pointermove", (l) => {
      s || (s = !0, this._uiManager.toggleComment(this, !0, !1), this._onStartDragging());
      const {
        clientX: h,
        clientY: c,
        pointerId: u
      } = l;
      if (u !== this.#n) {
        K(l);
        return;
      }
      const [f, g] = this.screenToPageTranslation(h - this.#C, c - this.#E);
      this.#C = h, this.#E = c, this._uiManager.dragSelectedEditors(f, g);
    }, r), window.addEventListener("touchmove", K, r), window.addEventListener("pointerdown", (l) => {
      l.pointerType === this.#o && (this.#x || l.isPrimary) && a(l), K(l);
    }, r));
    const o = (l) => {
      if (!this.#n || this.#n === l.pointerId) {
        a(l);
        return;
      }
      K(l);
    };
    window.addEventListener("pointerup", o, {
      signal: n
    }), window.addEventListener("blur", o, {
      signal: n
    });
  }
  _onStartDragging() {
  }
  _onStopDragging() {
  }
  moveInDOM() {
    this.#A && clearTimeout(this.#A), this.#A = setTimeout(() => {
      this.#A = null, this.parent?.moveEditorInDOM(this);
    }, 0);
  }
  _setParentAndPosition(t, e, s) {
    t.changeParent(this), this.x = e, this.y = s, this.fixAndSetPosition(), this._onTranslated();
  }
  getRect(t, e, s = this.rotation) {
    const i = this.parentScale, [n, r] = this.pageDimensions, [a, o] = this.pageTranslation, l = t / i, h = e / i, c = this.x * n, u = this.y * r, f = this.width * n, g = this.height * r;
    switch (s) {
      case 0:
        return [c + l + a, r - u - h - g + o, c + l + f + a, r - u - h + o];
      case 90:
        return [c + h + a, r - u + l + o, c + h + g + a, r - u + l + f + o];
      case 180:
        return [c - l - f + a, r - u + h + o, c - l + a, r - u + h + g + o];
      case 270:
        return [c - h - g + a, r - u - l - f + o, c - h + a, r - u - l + o];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getRectInCurrentCoords(t, e) {
    const [s, i, n, r] = t, a = n - s, o = r - i;
    switch (this.rotation) {
      case 0:
        return [s, e - r, a, o];
      case 90:
        return [s, e - i, o, a];
      case 180:
        return [n, e - i, a, o];
      case 270:
        return [n, e - r, o, a];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getPDFRect() {
    return this.getRect(0, 0);
  }
  getNonHCMColor() {
    return this.color && D._colorManager.convert(this._uiManager.getNonHCMColor(this.color));
  }
  onUpdatedColor() {
    this.#s?.onUpdatedColor();
  }
  getData() {
    const {
      comment: {
        text: t,
        color: e,
        date: s,
        opacity: i,
        deleted: n,
        richText: r
      },
      uid: a,
      pageIndex: o,
      creationDate: l,
      modificationDate: h
    } = this;
    return {
      id: a,
      pageIndex: o,
      rect: this.getPDFRect(),
      richText: r,
      contentsObj: {
        str: t
      },
      creationDate: l,
      modificationDate: s || h,
      popupRef: !n,
      color: e,
      opacity: i
    };
  }
  onceAdded(t) {
  }
  isEmpty() {
    return !1;
  }
  enableEditMode() {
    return this.isInEditMode() ? !1 : (this.parent.setEditingState(!1), this.#b = !0, !0);
  }
  disableEditMode() {
    return this.isInEditMode() ? (this.parent.setEditingState(!0), this.#b = !1, !0) : !1;
  }
  isInEditMode() {
    return this.#b;
  }
  shouldGetKeyboardEvents() {
    return this.#y;
  }
  needsToBeRebuilt() {
    return this.div && !this.isAttachedToDOM;
  }
  get isOnScreen() {
    const {
      top: t,
      left: e,
      bottom: s,
      right: i
    } = this.getClientDimensions(), {
      innerHeight: n,
      innerWidth: r
    } = window;
    return e < r && i > 0 && t < n && s > 0;
  }
  #$() {
    if (this.#f || !this.div)
      return;
    this.#f = new AbortController();
    const t = this._uiManager.combinedSignal(this.#f);
    this.div.addEventListener("focusin", this.focusin.bind(this), {
      signal: t
    }), this.div.addEventListener("focusout", this.focusout.bind(this), {
      signal: t
    });
  }
  rebuild() {
    this.#$();
  }
  rotate(t) {
  }
  resize() {
  }
  serializeDeleted() {
    return {
      id: this.annotationElementId,
      deleted: !0,
      pageIndex: this.pageIndex,
      popupRef: this._initialData?.popupRef || ""
    };
  }
  serialize(t = !1, e = null) {
    return {
      annotationType: this.mode,
      pageIndex: this.pageIndex,
      rect: this.getPDFRect(),
      rotation: this.rotation,
      structTreeParentId: this._structTreeParentId,
      popupRef: this._initialData?.popupRef || ""
    };
  }
  static async deserialize(t, e, s) {
    const i = new this.prototype.constructor({
      parent: e,
      id: e.getNextId(),
      uiManager: s,
      annotationElementId: t.annotationElementId,
      creationDate: t.creationDate,
      modificationDate: t.modificationDate
    });
    i.rotation = t.rotation, i.#t = t.accessibilityData, i._isCopy = t.isCopy || !1;
    const [n, r] = i.pageDimensions, [a, o, l, h] = i.getRectInCurrentCoords(t.rect, r);
    return i.x = a / n, i.y = o / r, i.width = l / n, i.height = h / r, i;
  }
  get hasBeenModified() {
    return !!this.annotationElementId && (this.deleted || this.serialize() !== null);
  }
  remove() {
    if (this.#f?.abort(), this.#f = null, this.isEmpty() || this.commit(), this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), this.hideCommentPopup(), this.#A && (clearTimeout(this.#A), this.#A = null), this.#N(), this.removeEditToolbar(), this.#v) {
      for (const t of this.#v.values())
        clearTimeout(t);
      this.#v = null;
    }
    this.parent = null, this.#x?.destroy(), this.#x = null, this.#d?.remove(), this.#d = null;
  }
  get isResizable() {
    return !1;
  }
  makeResizable() {
    this.isResizable && (this.#O(), this.#h.classList.remove("hidden"));
  }
  get toolbarPosition() {
    return null;
  }
  get commentButtonPosition() {
    return this._uiManager.direction === "ltr" ? [1, 0] : [0, 0];
  }
  get commentButtonPositionInPage() {
    const {
      commentButtonPosition: [t, e]
    } = this, [s, i, n, r] = this.getPDFRect();
    return [D._round(s + (n - s) * t), D._round(i + (r - i) * (1 - e))];
  }
  get commentButtonColor() {
    return this._uiManager.makeCommentColor(this.getNonHCMColor(), this.opacity);
  }
  get commentPopupPosition() {
    return this.#s.commentPopupPositionInLayer;
  }
  set commentPopupPosition(t) {
    this.#s.commentPopupPositionInLayer = t;
  }
  hasDefaultPopupPosition() {
    return this.#s.hasDefaultPopupPosition();
  }
  get commentButtonWidth() {
    return this.#s.commentButtonWidth;
  }
  get elementBeforePopup() {
    return this.div;
  }
  setCommentButtonStates(t) {
    this.#s?.setCommentButtonStates(t);
  }
  keydown(t) {
    if (!this.isResizable || t.target !== this.div || t.key !== "Enter")
      return;
    this._uiManager.setSelected(this), this.#u = {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    };
    const e = this.#h.children;
    if (!this.#e) {
      this.#e = Array.from(e);
      const r = this.#X.bind(this), a = this.#W.bind(this), o = this._uiManager._signal;
      for (const l of this.#e) {
        const h = l.getAttribute("data-resizer-name");
        l.setAttribute("role", "spinbutton"), l.addEventListener("keydown", r, {
          signal: o
        }), l.addEventListener("blur", a, {
          signal: o
        }), l.addEventListener("focus", this.#Y.bind(this, h), {
          signal: o
        }), l.setAttribute("data-l10n-id", D._l10nResizer[h]);
      }
    }
    const s = this.#e[0];
    let i = 0;
    for (const r of e) {
      if (r === s)
        break;
      i++;
    }
    const n = (360 - this.rotation + this.parentRotation) % 360 / 90 * (this.#e.length / 4);
    if (n !== i) {
      if (n < i)
        for (let a = 0; a < i - n; a++)
          this.#h.append(this.#h.firstElementChild);
      else if (n > i)
        for (let a = 0; a < n - i; a++)
          this.#h.firstElementChild.before(this.#h.lastElementChild);
      let r = 0;
      for (const a of e) {
        const l = this.#e[r++].getAttribute("data-resizer-name");
        a.setAttribute("data-l10n-id", D._l10nResizer[l]);
      }
    }
    this.#j(0), this.#y = !0, this.#h.firstElementChild.focus({
      focusVisible: !0
    }), t.preventDefault(), t.stopImmediatePropagation();
  }
  #X(t) {
    D._resizerKeyboardManager.exec(this, t);
  }
  #W(t) {
    this.#y && t.relatedTarget?.parentNode !== this.#h && this.#N();
  }
  #Y(t) {
    this.#m = this.#y ? t : "";
  }
  #j(t) {
    if (this.#e)
      for (const e of this.#e)
        e.tabIndex = t;
  }
  _resizeWithKeyboard(t, e) {
    this.#y && this.#F(this.#m, {
      deltaX: t,
      deltaY: e,
      fromKeyboard: !0
    });
  }
  #N() {
    this.#y = !1, this.#j(-1), this.#B();
  }
  _stopResizingWithKeyboard() {
    this.#N(), this.div.focus();
  }
  select() {
    if (this.isSelected && this._editToolbar) {
      this._editToolbar.show();
      return;
    }
    if (this.isSelected = !0, this.makeResizable(), this.div?.classList.add("selectedEditor"), !this._editToolbar) {
      this.addEditToolbar().then(() => {
        this.div?.classList.contains("selectedEditor") && this._editToolbar?.show();
      });
      return;
    }
    this._editToolbar?.show(), this.#i?.toggleAltTextBadge(!1);
  }
  focus() {
    this.div && !this.div.contains(document.activeElement) && setTimeout(() => this.div?.focus({
      preventScroll: !0
    }), 0);
  }
  unselect() {
    this.isSelected && (this.isSelected = !1, this.#h?.classList.add("hidden"), this.div?.classList.remove("selectedEditor"), this.div?.contains(document.activeElement) && this._uiManager.currentLayer.div.focus({
      preventScroll: !0
    }), this._editToolbar?.hide(), this.#i?.toggleAltTextBadge(!0), this.hideCommentPopup());
  }
  hideCommentPopup() {
    this.hasComment && this._uiManager.toggleComment(null);
  }
  updateParams(t, e) {
  }
  disableEditing() {
  }
  enableEditing() {
  }
  get canChangeContent() {
    return !1;
  }
  enterInEditMode() {
    this.canChangeContent && (this.enableEditMode(), this.div.focus());
  }
  dblclick(t) {
    t.target.nodeName !== "BUTTON" && (this.enterInEditMode(), this.parent.updateToolbar({
      mode: this.constructor._editorType,
      editId: this.uid
    }));
  }
  getElementForAltText() {
    return this.div;
  }
  get contentDiv() {
    return this.div;
  }
  get isEditing() {
    return this.#p;
  }
  set isEditing(t) {
    this.#p = t, this.parent && (t ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
  }
  static get MIN_SIZE() {
    return 16;
  }
  static canCreateNewEmptyEditor() {
    return !0;
  }
  get telemetryInitialData() {
    return {
      action: "added"
    };
  }
  get telemetryFinalData() {
    return null;
  }
  _reportTelemetry(t, e = !1) {
    if (e) {
      this.#v ||= /* @__PURE__ */ new Map();
      const {
        action: s
      } = t;
      let i = this.#v.get(s);
      i && clearTimeout(i), i = setTimeout(() => {
        this._reportTelemetry(t), this.#v.delete(s), this.#v.size === 0 && (this.#v = null);
      }, D._telemetryTimeout), this.#v.set(s, i);
      return;
    }
    t.type ||= this.editorType, this._uiManager._eventBus.dispatch("reporttelemetry", {
      source: this,
      details: {
        type: "editing",
        data: t
      }
    });
  }
  show(t = this._isVisible) {
    this.div.classList.toggle("hidden", !t), this._isVisible = t;
  }
  enable() {
    this.div && (this.div.tabIndex = 0), this.#r = !1;
  }
  disable() {
    this.div && (this.div.tabIndex = -1), this.#r = !0;
  }
  updateFakeAnnotationElement(t) {
    if (!this.#d && !this.deleted) {
      this.#d = t.addFakeAnnotation(this);
      return;
    }
    if (this.deleted) {
      this.#d.remove(), this.#d = null;
      return;
    }
    (this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized) && this.#d.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    });
  }
  renderAnnotationElement(t) {
    if (this.deleted)
      return t.hide(), null;
    let e = t.container.querySelector(".annotationContent");
    if (!e)
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), t.container.prepend(e);
    else if (e.nodeName === "CANVAS") {
      const s = e;
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), s.before(e);
    }
    return e;
  }
  resetAnnotationElement(t) {
    const {
      firstElementChild: e
    } = t.container;
    e?.nodeName === "DIV" && e.classList.contains("annotationContent") && e.remove();
  }
}
class pn extends D {
  constructor(t) {
    super(t), this.annotationElementId = t.annotationElementId, this.deleted = !0;
  }
  serialize() {
    return this.serializeDeleted();
  }
}
const zs = 3285377520, vt = 4294901760, Ct = 65535;
class vi {
  constructor(t) {
    this.h1 = t ? t & 4294967295 : zs, this.h2 = t ? t & 4294967295 : zs;
  }
  update(t) {
    let e, s;
    if (typeof t == "string") {
      e = new Uint8Array(t.length * 2), s = 0;
      for (let p = 0, b = t.length; p < b; p++) {
        const m = t.charCodeAt(p);
        m <= 255 ? e[s++] = m : (e[s++] = m >>> 8, e[s++] = m & 255);
      }
    } else if (ArrayBuffer.isView(t))
      e = t.slice(), s = e.byteLength;
    else
      throw new Error("Invalid data format, must be a string or TypedArray.");
    const i = s >> 2, n = s - i * 4, r = new Uint32Array(e.buffer, 0, i);
    let a = 0, o = 0, l = this.h1, h = this.h2;
    const c = 3432918353, u = 461845907, f = c & Ct, g = u & Ct;
    for (let p = 0; p < i; p++)
      p & 1 ? (a = r[p], a = a * c & vt | a * f & Ct, a = a << 15 | a >>> 17, a = a * u & vt | a * g & Ct, l ^= a, l = l << 13 | l >>> 19, l = l * 5 + 3864292196) : (o = r[p], o = o * c & vt | o * f & Ct, o = o << 15 | o >>> 17, o = o * u & vt | o * g & Ct, h ^= o, h = h << 13 | h >>> 19, h = h * 5 + 3864292196);
    switch (a = 0, n) {
      case 3:
        a ^= e[i * 4 + 2] << 16;
      case 2:
        a ^= e[i * 4 + 1] << 8;
      case 1:
        a ^= e[i * 4], a = a * c & vt | a * f & Ct, a = a << 15 | a >>> 17, a = a * u & vt | a * g & Ct, i & 1 ? l ^= a : h ^= a;
    }
    this.h1 = l, this.h2 = h;
  }
  hexdigest() {
    let t = this.h1, e = this.h2;
    return t ^= e >>> 1, t = t * 3981806797 & vt | t * 36045 & Ct, e = e * 4283543511 & vt | ((e << 16 | t >>> 16) * 2950163797 & vt) >>> 16, t ^= e >>> 1, t = t * 444984403 & vt | t * 60499 & Ct, e = e * 3301882366 & vt | ((e << 16 | t >>> 16) * 3120437893 & vt) >>> 16, t ^= e >>> 1, (t >>> 0).toString(16).padStart(8, "0") + (e >>> 0).toString(16).padStart(8, "0");
  }
}
const hs = Object.freeze({
  map: null,
  hash: "",
  transfer: void 0
});
class _s {
  #t = !1;
  #e = null;
  #i = null;
  #s = /* @__PURE__ */ new Map();
  constructor() {
    this.onSetModified = null, this.onResetModified = null, this.onAnnotationEditor = null;
  }
  getValue(t, e) {
    const s = this.#s.get(t);
    return s === void 0 ? e : Object.assign(e, s);
  }
  getRawValue(t) {
    return this.#s.get(t);
  }
  remove(t) {
    const e = this.#s.get(t);
    if (e !== void 0 && (e instanceof D && this.#i.delete(e.annotationElementId), this.#s.delete(t), this.#s.size === 0 && this.resetModified(), typeof this.onAnnotationEditor == "function")) {
      for (const s of this.#s.values())
        if (s instanceof D)
          return;
      this.onAnnotationEditor(null);
    }
  }
  setValue(t, e) {
    const s = this.#s.get(t);
    let i = !1;
    if (s !== void 0)
      for (const [n, r] of Object.entries(e))
        s[n] !== r && (i = !0, s[n] = r);
    else
      i = !0, this.#s.set(t, e);
    i && this.#a(), e instanceof D && ((this.#i ||= /* @__PURE__ */ new Map()).set(e.annotationElementId, e), typeof this.onAnnotationEditor == "function" && this.onAnnotationEditor(e.constructor._type));
  }
  has(t) {
    return this.#s.has(t);
  }
  get size() {
    return this.#s.size;
  }
  #a() {
    this.#t || (this.#t = !0, typeof this.onSetModified == "function" && this.onSetModified());
  }
  resetModified() {
    this.#t && (this.#t = !1, typeof this.onResetModified == "function" && this.onResetModified());
  }
  get print() {
    return new Si(this);
  }
  get serializable() {
    if (this.#s.size === 0)
      return hs;
    const t = /* @__PURE__ */ new Map(), e = new vi(), s = [], i = /* @__PURE__ */ Object.create(null);
    let n = !1;
    for (const [r, a] of this.#s) {
      const o = a instanceof D ? a.serialize(!1, i) : a;
      a.page && (a.pageIndex = a.page._pageIndex, delete a.page), o && (t.set(r, o), e.update(`${r}:${JSON.stringify(o)}`), n ||= !!o.bitmap);
    }
    if (n)
      for (const r of t.values())
        r.bitmap && s.push(r.bitmap);
    return t.size > 0 ? {
      map: t,
      hash: e.hexdigest(),
      transfer: s
    } : hs;
  }
  get editorStats() {
    let t = null;
    const e = /* @__PURE__ */ new Map();
    let s = 0, i = 0;
    for (const n of this.#s.values()) {
      if (!(n instanceof D)) {
        n.popup && (n.popup.deleted ? i += 1 : s += 1);
        continue;
      }
      n.isCommentDeleted ? i += 1 : n.hasEditedComment && (s += 1);
      const r = n.telemetryFinalData;
      if (!r)
        continue;
      const {
        type: a
      } = r;
      e.has(a) || e.set(a, Object.getPrototypeOf(n).constructor), t ||= /* @__PURE__ */ Object.create(null);
      const o = t[a] ||= /* @__PURE__ */ new Map();
      for (const [l, h] of Object.entries(r)) {
        if (l === "type")
          continue;
        let c = o.get(l);
        c || (c = /* @__PURE__ */ new Map(), o.set(l, c));
        const u = c.get(h) ?? 0;
        c.set(h, u + 1);
      }
    }
    if ((i > 0 || s > 0) && (t ||= /* @__PURE__ */ Object.create(null), t.comments = {
      deleted: i,
      edited: s
    }), !t)
      return null;
    for (const [n, r] of e)
      t[n] = r.computeTelemetryFinalData(t[n]);
    return t;
  }
  resetModifiedIds() {
    this.#e = null;
  }
  updateEditor(t, e) {
    const s = this.#i?.get(t);
    return s ? (s.updateFromAnnotationLayer(e), !0) : !1;
  }
  getEditor(t) {
    return this.#i?.get(t) || null;
  }
  get modifiedIds() {
    if (this.#e)
      return this.#e;
    const t = [];
    if (this.#i)
      for (const e of this.#i.values())
        e.serialize() && t.push(e.annotationElementId);
    return this.#e = {
      ids: new Set(t),
      hash: t.join(",")
    };
  }
  [Symbol.iterator]() {
    return this.#s.entries();
  }
}
class Si extends _s {
  #t;
  constructor(t) {
    super();
    const {
      map: e,
      hash: s,
      transfer: i
    } = t.serializable, n = structuredClone(e, i ? {
      transfer: i
    } : null);
    this.#t = {
      map: n,
      hash: s,
      transfer: i
    };
  }
  get print() {
    j("Should not call PrintAnnotationStorage.print");
  }
  get serializable() {
    return this.#t;
  }
  get modifiedIds() {
    return I(this, "modifiedIds", {
      ids: /* @__PURE__ */ new Set(),
      hash: ""
    });
  }
}
class gn {
  #t = /* @__PURE__ */ new Set();
  constructor({
    ownerDocument: t = globalThis.document,
    styleElement: e = null
  }) {
    this._document = t, this.nativeFontFaces = /* @__PURE__ */ new Set(), this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
  }
  addNativeFontFace(t) {
    this.nativeFontFaces.add(t), this._document.fonts.add(t);
  }
  removeNativeFontFace(t) {
    this.nativeFontFaces.delete(t), this._document.fonts.delete(t);
  }
  insertRule(t) {
    this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement));
    const e = this.styleElement.sheet;
    e.insertRule(t, e.cssRules.length);
  }
  clear() {
    for (const t of this.nativeFontFaces)
      this._document.fonts.delete(t);
    this.nativeFontFaces.clear(), this.#t.clear(), this.styleElement && (this.styleElement.remove(), this.styleElement = null);
  }
  async loadSystemFont({
    systemFontInfo: t,
    disableFontFace: e,
    _inspectFont: s
  }) {
    if (!(!t || this.#t.has(t.loadedName))) {
      if ($(!e, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
        const {
          loadedName: i,
          src: n,
          style: r
        } = t, a = new FontFace(i, n, r);
        this.addNativeFontFace(a);
        try {
          await a.load(), this.#t.add(i), s?.(t);
        } catch {
          R(`Cannot load system font: ${t.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(a);
        }
        return;
      }
      j("Not implemented: loadSystemFont without the Font Loading API.");
    }
  }
  async bind(t) {
    if (t.attached || t.missingFile && !t.systemFontInfo)
      return;
    if (t.attached = !0, t.systemFontInfo) {
      await this.loadSystemFont(t);
      return;
    }
    if (this.isFontLoadingAPISupported) {
      const s = t.createNativeFontFace();
      if (s) {
        this.addNativeFontFace(s);
        try {
          await s.loaded;
        } catch (i) {
          throw R(`Failed to load font '${s.family}': '${i}'.`), t.disableFontFace = !0, i;
        }
      }
      return;
    }
    const e = t.createFontFaceRule();
    if (e) {
      if (this.insertRule(e), this.isSyncFontLoadingSupported)
        return;
      await new Promise((s) => {
        const i = this._queueLoadingCallback(s);
        this._prepareFontLoadEvent(t, i);
      });
    }
  }
  get isFontLoadingAPISupported() {
    const t = !!this._document?.fonts;
    return I(this, "isFontLoadingAPISupported", t);
  }
  get isSyncFontLoadingSupported() {
    return I(this, "isSyncFontLoadingSupported", ut || nt.platform.isFirefox);
  }
  _queueLoadingCallback(t) {
    function e() {
      for ($(!i.done, "completeRequest() cannot be called twice."), i.done = !0; s.length > 0 && s[0].done; ) {
        const n = s.shift();
        setTimeout(n.callback, 0);
      }
    }
    const {
      loadingRequests: s
    } = this, i = {
      done: !1,
      complete: e,
      callback: t
    };
    return s.push(i), i;
  }
  get _loadTestFont() {
    const t = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
    return I(this, "_loadTestFont", t);
  }
  _prepareFontLoadEvent(t, e) {
    function s(v, w) {
      return v.charCodeAt(w) << 24 | v.charCodeAt(w + 1) << 16 | v.charCodeAt(w + 2) << 8 | v.charCodeAt(w + 3) & 255;
    }
    function i(v, w, S, E) {
      const _ = v.substring(0, w), C = v.substring(w + S);
      return _ + E + C;
    }
    let n, r;
    const a = this._document.createElement("canvas");
    a.width = 1, a.height = 1;
    const o = a.getContext("2d");
    let l = 0;
    function h(v, w) {
      if (++l > 30) {
        R("Load test font never loaded."), w();
        return;
      }
      if (o.font = "30px " + v, o.fillText(".", 0, 20), o.getImageData(0, 0, 1, 1).data[3] > 0) {
        w();
        return;
      }
      setTimeout(h.bind(null, v, w));
    }
    const c = `lt${Date.now()}${this.loadTestFontId++}`;
    let u = this._loadTestFont;
    u = i(u, 976, c.length, c);
    const g = 16, p = 1482184792;
    let b = s(u, g);
    for (n = 0, r = c.length - 3; n < r; n += 4)
      b = b - p + s(c, n) | 0;
    n < c.length && (b = b - p + s(c + "XXX", n) | 0), u = i(u, g, 4, sn(b));
    const m = `url(data:font/opentype;base64,${btoa(u)});`, y = `@font-face {font-family:"${c}";src:${m}}`;
    this.insertRule(y);
    const A = this._document.createElement("div");
    A.style.visibility = "hidden", A.style.width = A.style.height = "10px", A.style.position = "absolute", A.style.top = A.style.left = "0px";
    for (const v of [t.loadedName, c]) {
      const w = this._document.createElement("span");
      w.textContent = "Hi", w.style.fontFamily = v, A.append(w);
    }
    this._document.body.append(A), h(c, () => {
      A.remove(), e.complete();
    });
  }
}
class mn {
  #t;
  constructor(t, e = null, s, i) {
    this.compiledGlyphs = /* @__PURE__ */ Object.create(null), this.#t = t, this._inspectFont = e, s && Object.assign(this, s), i && (this.charProcOperatorList = i);
  }
  createNativeFontFace() {
    if (!this.data || this.disableFontFace)
      return null;
    let t;
    if (!this.cssFontInfo)
      t = new FontFace(this.loadedName, this.data, {});
    else {
      const e = {
        weight: this.cssFontInfo.fontWeight
      };
      this.cssFontInfo.italicAngle && (e.style = `oblique ${this.cssFontInfo.italicAngle}deg`), t = new FontFace(this.cssFontInfo.fontFamily, this.data, e);
    }
    return this._inspectFont?.(this), t;
  }
  createFontFaceRule() {
    if (!this.data || this.disableFontFace)
      return null;
    const t = `url(data:${this.mimetype};base64,${this.data.toBase64()});`;
    let e;
    if (!this.cssFontInfo)
      e = `@font-face {font-family:"${this.loadedName}";src:${t}}`;
    else {
      let s = `font-weight: ${this.cssFontInfo.fontWeight};`;
      this.cssFontInfo.italicAngle && (s += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), e = `@font-face {font-family:"${this.cssFontInfo.fontFamily}";${s}src:${t}}`;
    }
    return this._inspectFont?.(this, t), e;
  }
  getPathGenerator(t, e) {
    if (this.compiledGlyphs[e] !== void 0)
      return this.compiledGlyphs[e];
    const s = this.loadedName + "_path_" + e;
    let i;
    try {
      i = t.get(s);
    } catch (r) {
      R(`getPathGenerator - ignoring character: "${r}".`);
    }
    const n = yi(i?.path);
    return this.fontExtraProperties || t.delete(s), this.compiledGlyphs[e] = n;
  }
  get black() {
    return this.#t.black;
  }
  get bold() {
    return this.#t.bold;
  }
  get disableFontFace() {
    return this.#t.disableFontFace ?? !1;
  }
  set disableFontFace(t) {
    I(this, "disableFontFace", !!t);
  }
  get fontExtraProperties() {
    return this.#t.fontExtraProperties ?? !1;
  }
  get isInvalidPDFjsFont() {
    return this.#t.isInvalidPDFjsFont;
  }
  get isType3Font() {
    return this.#t.isType3Font;
  }
  get italic() {
    return this.#t.italic;
  }
  get missingFile() {
    return this.#t.missingFile;
  }
  get remeasure() {
    return this.#t.remeasure;
  }
  get vertical() {
    return this.#t.vertical;
  }
  get ascent() {
    return this.#t.ascent;
  }
  get defaultWidth() {
    return this.#t.defaultWidth;
  }
  get descent() {
    return this.#t.descent;
  }
  get bbox() {
    return this.#t.bbox;
  }
  set bbox(t) {
    I(this, "bbox", t);
  }
  get fontMatrix() {
    return this.#t.fontMatrix;
  }
  get fallbackName() {
    return this.#t.fallbackName;
  }
  get loadedName() {
    return this.#t.loadedName;
  }
  get mimetype() {
    return this.#t.mimetype;
  }
  get name() {
    return this.#t.name;
  }
  get data() {
    return this.#t.data;
  }
  clearData() {
    this.#t.clearData();
  }
  get cssFontInfo() {
    return this.#t.cssFontInfo;
  }
  get systemFontInfo() {
    return this.#t.systemFontInfo;
  }
  get defaultVMetrics() {
    return this.#t.defaultVMetrics;
  }
}
class Kt {
  #t;
  #e;
  #i;
  static strings = ["fontFamily", "fontWeight", "italicAngle"];
  static write(t) {
    const e = new TextEncoder(), s = {};
    let i = 0;
    for (const l of Kt.strings) {
      const h = e.encode(t[l]);
      s[l] = h, i += 4 + h.length;
    }
    const n = new ArrayBuffer(i), r = new Uint8Array(n), a = new DataView(n);
    let o = 0;
    for (const l of Kt.strings) {
      const h = s[l], c = h.length;
      a.setUint32(o, c), r.set(h, o + 4), o += 4 + c;
    }
    return $(o === n.byteLength, "CssFontInfo.write: Buffer overflow"), n;
  }
  constructor(t) {
    this.#t = t, this.#e = new DataView(this.#t), this.#i = new TextDecoder();
  }
  #s(t) {
    $(t < Kt.strings.length, "Invalid string index");
    let e = 0;
    for (let i = 0; i < t; i++)
      e += this.#e.getUint32(e) + 4;
    const s = this.#e.getUint32(e);
    return this.#i.decode(new Uint8Array(this.#t, e + 4, s));
  }
  get fontFamily() {
    return this.#s(0);
  }
  get fontWeight() {
    return this.#s(1);
  }
  get italicAngle() {
    return this.#s(2);
  }
}
class Qt {
  #t;
  #e;
  #i;
  static strings = ["css", "loadedName", "baseFontName", "src"];
  static write(t) {
    const e = new TextEncoder(), s = {};
    let i = 0;
    for (const u of Qt.strings) {
      const f = e.encode(t[u]);
      s[u] = f, i += 4 + f.length;
    }
    i += 4;
    let n, r, a = 1 + i;
    t.style && (n = e.encode(t.style.style), r = e.encode(t.style.weight), a += 4 + n.length + 4 + r.length);
    const o = new ArrayBuffer(a), l = new Uint8Array(o), h = new DataView(o);
    let c = 0;
    h.setUint8(c++, t.guessFallback ? 1 : 0), h.setUint32(c, 0), c += 4, i = 0;
    for (const u of Qt.strings) {
      const f = s[u], g = f.length;
      i += 4 + g, h.setUint32(c, g), l.set(f, c + 4), c += 4 + g;
    }
    return h.setUint32(c - i - 4, i), t.style && (h.setUint32(c, n.length), l.set(n, c + 4), c += 4 + n.length, h.setUint32(c, r.length), l.set(r, c + 4), c += 4 + r.length), $(c <= o.byteLength, "SubstitionInfo.write: Buffer overflow"), o.transferToFixedLength(c);
  }
  constructor(t) {
    this.#t = t, this.#e = new DataView(this.#t), this.#i = new TextDecoder();
  }
  get guessFallback() {
    return this.#e.getUint8(0) !== 0;
  }
  #s(t) {
    $(t < Qt.strings.length, "Invalid string index");
    let e = 5;
    for (let i = 0; i < t; i++)
      e += this.#e.getUint32(e) + 4;
    const s = this.#e.getUint32(e);
    return this.#i.decode(new Uint8Array(this.#t, e + 4, s));
  }
  get css() {
    return this.#s(0);
  }
  get loadedName() {
    return this.#s(1);
  }
  get baseFontName() {
    return this.#s(2);
  }
  get src() {
    return this.#s(3);
  }
  get style() {
    let t = 1;
    t += 4 + this.#e.getUint32(t);
    const e = this.#e.getUint32(t), s = this.#i.decode(new Uint8Array(this.#t, t + 4, e));
    t += 4 + e;
    const i = this.#e.getUint32(t), n = this.#i.decode(new Uint8Array(this.#t, t + 4, i));
    return {
      style: s,
      weight: n
    };
  }
}
class V {
  static bools = ["black", "bold", "disableFontFace", "fontExtraProperties", "isInvalidPDFjsFont", "isType3Font", "italic", "missingFile", "remeasure", "vertical"];
  static numbers = ["ascent", "defaultWidth", "descent"];
  static strings = ["fallbackName", "loadedName", "mimetype", "name"];
  static #t = Math.ceil(this.bools.length * 2 / 8);
  static #e = this.#t + this.numbers.length * 8;
  static #i = this.#e + 1 + 2 * 4;
  static #s = this.#i + 1 + 8 * 6;
  static #a = this.#s + 1 + 2 * 3;
  #r;
  #n;
  #o;
  constructor({
    data: t,
    extra: e
  }) {
    this.#r = t, this.#n = new TextDecoder(), this.#o = new DataView(this.#r), e && Object.assign(this, e);
  }
  #h(t) {
    $(t < V.bools.length, "Invalid boolean index");
    const e = Math.floor(t / 4), s = t * 2 % 8, i = this.#o.getUint8(e) >> s & 3;
    return i === 0 ? void 0 : i === 2;
  }
  get black() {
    return this.#h(0);
  }
  get bold() {
    return this.#h(1);
  }
  get disableFontFace() {
    return this.#h(2);
  }
  get fontExtraProperties() {
    return this.#h(3);
  }
  get isInvalidPDFjsFont() {
    return this.#h(4);
  }
  get isType3Font() {
    return this.#h(5);
  }
  get italic() {
    return this.#h(6);
  }
  get missingFile() {
    return this.#h(7);
  }
  get remeasure() {
    return this.#h(8);
  }
  get vertical() {
    return this.#h(9);
  }
  #l(t) {
    return $(t < V.numbers.length, "Invalid number index"), this.#o.getFloat64(V.#t + t * 8);
  }
  get ascent() {
    return this.#l(0);
  }
  get defaultWidth() {
    return this.#l(1);
  }
  get descent() {
    return this.#l(2);
  }
  get bbox() {
    let t = V.#e;
    if (this.#o.getUint8(t) === 0)
      return;
    t += 1;
    const s = [];
    for (let i = 0; i < 4; i++)
      s.push(this.#o.getInt16(t, !0)), t += 2;
    return s;
  }
  get fontMatrix() {
    let t = V.#i;
    if (this.#o.getUint8(t) === 0)
      return;
    t += 1;
    const s = [];
    for (let i = 0; i < 6; i++)
      s.push(this.#o.getFloat64(t, !0)), t += 8;
    return s;
  }
  get defaultVMetrics() {
    let t = V.#s;
    if (this.#o.getUint8(t) === 0)
      return;
    t += 1;
    const s = [];
    for (let i = 0; i < 3; i++)
      s.push(this.#o.getInt16(t, !0)), t += 2;
    return s;
  }
  #u(t) {
    $(t < V.strings.length, "Invalid string index");
    let e = V.#a + 4;
    for (let n = 0; n < t; n++)
      e += this.#o.getUint32(e) + 4;
    const s = this.#o.getUint32(e), i = new Uint8Array(s);
    return i.set(new Uint8Array(this.#r, e + 4, s)), this.#n.decode(i);
  }
  get fallbackName() {
    return this.#u(0);
  }
  get loadedName() {
    return this.#u(1);
  }
  get mimetype() {
    return this.#u(2);
  }
  get name() {
    return this.#u(3);
  }
  get data() {
    let t = V.#a;
    const e = this.#o.getUint32(t);
    t += 4 + e;
    const s = this.#o.getUint32(t);
    t += 4 + s;
    const i = this.#o.getUint32(t);
    t += 4 + i;
    const n = this.#o.getUint32(t);
    if (n !== 0)
      return new Uint8Array(this.#r, t + 4, n);
  }
  clearData() {
    let t = V.#a;
    const e = this.#o.getUint32(t);
    t += 4 + e;
    const s = this.#o.getUint32(t);
    t += 4 + s;
    const i = this.#o.getUint32(t);
    t += 4 + i;
    const n = this.#o.getUint32(t);
    new Uint8Array(this.#r, t + 4, n).fill(0), this.#o.setUint32(t, 0);
  }
  get cssFontInfo() {
    let t = V.#a;
    const e = this.#o.getUint32(t);
    t += 4 + e;
    const s = this.#o.getUint32(t);
    t += 4 + s;
    const i = this.#o.getUint32(t);
    if (i === 0)
      return null;
    const n = new Uint8Array(i);
    return n.set(new Uint8Array(this.#r, t + 4, i)), new Kt(n.buffer);
  }
  get systemFontInfo() {
    let t = V.#a;
    const e = this.#o.getUint32(t);
    t += 4 + e;
    const s = this.#o.getUint32(t);
    if (s === 0)
      return null;
    const i = new Uint8Array(s);
    return i.set(new Uint8Array(this.#r, t + 4, s)), new Qt(i.buffer);
  }
  static write(t) {
    const e = t.systemFontInfo ? Qt.write(t.systemFontInfo) : null, s = t.cssFontInfo ? Kt.write(t.cssFontInfo) : null, i = new TextEncoder(), n = {};
    let r = 0;
    for (const p of V.strings)
      n[p] = i.encode(t[p]), r += 4 + n[p].length;
    const a = V.#a + 4 + r + 4 + (e ? e.byteLength : 0) + 4 + (s ? s.byteLength : 0) + 4 + (t.data ? t.data.length : 0), o = new ArrayBuffer(a), l = new Uint8Array(o), h = new DataView(o);
    let c = 0;
    const u = V.bools.length;
    let f = 0, g = 0;
    for (let p = 0; p < u; p++) {
      const b = t[V.bools[p]];
      f |= (b === void 0 ? 0 : b ? 2 : 1) << g, g += 2, (g === 8 || p === u - 1) && (h.setUint8(c++, f), f = 0, g = 0);
    }
    $(c === V.#t, "FontInfo.write: Boolean properties offset mismatch");
    for (const p of V.numbers)
      h.setFloat64(c, t[p]), c += 8;
    if ($(c === V.#e, "FontInfo.write: Number properties offset mismatch"), t.bbox) {
      h.setUint8(c++, 4);
      for (const p of t.bbox)
        h.setInt16(c, p, !0), c += 2;
    } else
      h.setUint8(c++, 0), c += 2 * 4;
    if ($(c === V.#i, "FontInfo.write: BBox properties offset mismatch"), t.fontMatrix) {
      h.setUint8(c++, 6);
      for (const p of t.fontMatrix)
        h.setFloat64(c, p, !0), c += 8;
    } else
      h.setUint8(c++, 0), c += 8 * 6;
    if ($(c === V.#s, "FontInfo.write: FontMatrix properties offset mismatch"), t.defaultVMetrics) {
      h.setUint8(c++, 1);
      for (const p of t.defaultVMetrics)
        h.setInt16(c, p, !0), c += 2;
    } else
      h.setUint8(c++, 0), c += 3 * 2;
    $(c === V.#a, "FontInfo.write: DefaultVMetrics properties offset mismatch"), h.setUint32(V.#a, 0), c += 4;
    for (const p of V.strings) {
      const b = n[p], m = b.length;
      h.setUint32(c, m), l.set(b, c + 4), c += 4 + m;
    }
    if (h.setUint32(V.#a, c - V.#a - 4), !e)
      h.setUint32(c, 0), c += 4;
    else {
      const p = e.byteLength;
      h.setUint32(c, p), $(c + 4 + p <= o.byteLength, "FontInfo.write: Buffer overflow at systemFontInfo"), l.set(new Uint8Array(e), c + 4), c += 4 + p;
    }
    if (!s)
      h.setUint32(c, 0), c += 4;
    else {
      const p = s.byteLength;
      h.setUint32(c, p), $(c + 4 + p <= o.byteLength, "FontInfo.write: Buffer overflow at cssFontInfo"), l.set(new Uint8Array(s), c + 4), c += 4 + p;
    }
    return t.data === void 0 ? (h.setUint32(c, 0), c += 4) : (h.setUint32(c, t.data.length), l.set(t.data, c + 4), c += 4 + t.data.length), $(c <= o.byteLength, "FontInfo.write: Buffer overflow"), o.transferToFixedLength(c);
  }
}
class at {
  static #t = 0;
  static #e = 1;
  static #i = 2;
  static #s = 3;
  static #a = 4;
  static #r = 8;
  static #n = 12;
  static #o = 16;
  constructor(t) {
    this.buffer = t, this.view = new DataView(t), this.data = new Uint8Array(t);
  }
  static write(t) {
    let e, s = null, i = [], n = [], r = [], a = [], o = null, l = null;
    switch (t[0]) {
      case "RadialAxial":
        e = t[1] === "axial" ? 1 : 2, s = t[2], r = t[3], e === 1 ? i.push(...t[4], ...t[5]) : i.push(t[4][0], t[4][1], t[6], t[5][0], t[5][1], t[7]);
        break;
      case "Mesh":
        e = 3, o = t[1], i = t[2], n = t[3], a = t[4] || [], s = t[6], l = t[7];
        break;
      default:
        throw new Error(`Unsupported pattern type: ${t[0]}`);
    }
    const h = Math.floor(i.length / 2), c = Math.floor(n.length / 3), u = r.length, f = a.length;
    let g = 0;
    for (const w of a)
      g += 1, g = Math.ceil(g / 4) * 4, g += 4 + w.coords.length * 4, g += 4 + w.colors.length * 4, w.verticesPerRow !== void 0 && (g += 4);
    const p = 20 + h * 8 + c * 3 + u * 8 + (s ? 16 : 0) + (l ? 3 : 0) + g, b = new ArrayBuffer(p), m = new DataView(b), y = new Uint8Array(b);
    m.setUint8(at.#t, e), m.setUint8(at.#e, s ? 1 : 0), m.setUint8(at.#i, l ? 1 : 0), m.setUint8(at.#s, o), m.setUint32(at.#a, h, !0), m.setUint32(at.#r, c, !0), m.setUint32(at.#n, u, !0), m.setUint32(at.#o, f, !0);
    let A = 20;
    new Float32Array(b, A, h * 2).set(i), A += h * 8, y.set(n, A), A += c * 3;
    for (const [w, S] of r)
      m.setFloat32(A, w, !0), A += 4, m.setUint32(A, parseInt(S.slice(1), 16), !0), A += 4;
    if (s)
      for (const w of s)
        m.setFloat32(A, w, !0), A += 4;
    l && (y.set(l, A), A += 3);
    for (let w = 0; w < a.length; w++) {
      const S = a[w];
      m.setUint8(A, S.type), A += 1, A = Math.ceil(A / 4) * 4, m.setUint32(A, S.coords.length, !0), A += 4, new Int32Array(b, A, S.coords.length).set(S.coords), A += S.coords.length * 4, m.setUint32(A, S.colors.length, !0), A += 4, new Int32Array(b, A, S.colors.length).set(S.colors), A += S.colors.length * 4, S.verticesPerRow !== void 0 && (m.setUint32(A, S.verticesPerRow, !0), A += 4);
    }
    return b;
  }
  getIR() {
    const t = this.view, e = this.data[at.#t], s = !!this.data[at.#e], i = !!this.data[at.#i], n = t.getUint32(at.#a, !0), r = t.getUint32(at.#r, !0), a = t.getUint32(at.#n, !0), o = t.getUint32(at.#o, !0);
    let l = 20;
    const h = new Float32Array(this.buffer, l, n * 2);
    l += n * 8;
    const c = new Uint8Array(this.buffer, l, r * 3);
    l += r * 3;
    const u = [];
    for (let b = 0; b < a; ++b) {
      const m = t.getFloat32(l, !0);
      l += 4;
      const y = t.getUint32(l, !0);
      l += 4, u.push([m, `#${y.toString(16).padStart(6, "0")}`]);
    }
    let f = null;
    if (s) {
      f = [];
      for (let b = 0; b < 4; ++b)
        f.push(t.getFloat32(l, !0)), l += 4;
    }
    let g = null;
    i && (g = new Uint8Array(this.buffer, l, 3), l += 3);
    const p = [];
    for (let b = 0; b < o; ++b) {
      const m = t.getUint8(l);
      l += 1, l = Math.ceil(l / 4) * 4;
      const y = t.getUint32(l, !0);
      l += 4;
      const A = new Int32Array(this.buffer, l, y);
      l += y * 4;
      const v = t.getUint32(l, !0);
      l += 4;
      const w = new Int32Array(this.buffer, l, v);
      l += v * 4;
      const S = {
        type: m,
        coords: A,
        colors: w
      };
      m === os.LATTICE && (S.verticesPerRow = t.getUint32(l, !0), l += 4), p.push(S);
    }
    if (e === 1)
      return ["RadialAxial", "axial", f, u, Array.from(h.slice(0, 2)), Array.from(h.slice(2, 4)), null, null];
    if (e === 2)
      return ["RadialAxial", "radial", f, u, [h[0], h[1]], [h[3], h[4]], h[2], h[5]];
    if (e === 3) {
      const b = this.data[at.#s];
      let m = null;
      if (h.length > 0) {
        let y = h[0], A = h[0], v = h[1], w = h[1];
        for (let S = 0; S < h.length; S += 2) {
          const E = h[S], _ = h[S + 1];
          y = y > E ? E : y, v = v > _ ? _ : v, A = A < E ? E : A, w = w < _ ? _ : w;
        }
        m = [y, v, A, w];
      }
      return ["Mesh", b, h, c, p, m, f, g];
    }
    throw new Error(`Unsupported pattern kind: ${e}`);
  }
}
class bn {
  static write(t) {
    let e, s;
    return nt.isFloat16ArraySupported ? (s = new ArrayBuffer(t.length * 2), e = new Float16Array(s)) : (s = new ArrayBuffer(t.length * 4), e = new Float32Array(s)), e.set(t), s;
  }
  #t;
  constructor(t) {
    this.#t = t;
  }
  get path() {
    return nt.isFloat16ArraySupported ? new Float16Array(this.#t) : new Float32Array(this.#t);
  }
}
function An(d) {
  if (d instanceof URL)
    return d.href;
  if (typeof d == "string") {
    if (ut)
      return d;
    const t = URL.parse(d, window.location);
    if (t)
      return t.href;
  }
  throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
}
function yn(d) {
  if (ut && typeof Buffer < "u" && d instanceof Buffer)
    throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
  if (d instanceof Uint8Array && d.byteLength === d.buffer.byteLength)
    return d;
  if (typeof d == "string")
    return He(d);
  if (d instanceof ArrayBuffer || ArrayBuffer.isView(d) || typeof d == "object" && !isNaN(d?.length))
    return new Uint8Array(d);
  throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
}
function Te(d) {
  if (typeof d != "string")
    return null;
  if (d.endsWith("/"))
    return d;
  throw new Error(`Invalid factory url: "${d}" must include trailing slash.`);
}
const cs = (d) => typeof d == "object" && Number.isInteger(d?.num) && d.num >= 0 && Number.isInteger(d?.gen) && d.gen >= 0, wn = (d) => typeof d == "object" && typeof d?.name == "string", Ei = on.bind(null, cs, wn);
class vn {
  #t = /* @__PURE__ */ new Map();
  #e = Promise.resolve();
  postMessage(t, e) {
    const s = {
      data: structuredClone(t, e ? {
        transfer: e
      } : null)
    };
    this.#e.then(() => {
      for (const [i] of this.#t)
        i.call(this, s);
    });
  }
  addEventListener(t, e, s = null) {
    let i = null;
    if (s?.signal instanceof AbortSignal) {
      const {
        signal: n
      } = s;
      if (n.aborted) {
        R("LoopbackPort - cannot use an `aborted` signal.");
        return;
      }
      const r = () => this.removeEventListener(t, e);
      i = () => n.removeEventListener("abort", r), n.addEventListener("abort", r);
    }
    this.#t.set(e, i);
  }
  removeEventListener(t, e) {
    this.#t.get(e)?.(), this.#t.delete(e);
  }
  terminate() {
    for (const [, t] of this.#t)
      t?.();
    this.#t.clear();
  }
}
const xe = {
  DATA: 1,
  ERROR: 2
}, it = {
  CANCEL: 1,
  CANCEL_COMPLETE: 2,
  CLOSE: 3,
  ENQUEUE: 4,
  ERROR: 5,
  PULL: 6,
  PULL_COMPLETE: 7,
  START_COMPLETE: 8
};
function Gs() {
}
function ft(d) {
  if (d instanceof Lt || d instanceof Re || d instanceof Ns || d instanceof ge || d instanceof Ze)
    return d;
  switch (d instanceof Error || typeof d == "object" && d !== null || j('wrapReason: Expected "reason" to be a (possibly cloned) Error.'), d.name) {
    case "AbortException":
      return new Lt(d.message);
    case "InvalidPDFException":
      return new Re(d.message);
    case "PasswordException":
      return new Ns(d.message, d.code);
    case "ResponseException":
      return new ge(d.message, d.status, d.missing);
    case "UnknownErrorException":
      return new Ze(d.message, d.details);
  }
  return new Ze(d.message, d.toString());
}
class de {
  #t = new AbortController();
  constructor(t, e, s) {
    this.sourceName = t, this.targetName = e, this.comObj = s, this.callbackId = 1, this.streamId = 1, this.streamSinks = /* @__PURE__ */ Object.create(null), this.streamControllers = /* @__PURE__ */ Object.create(null), this.callbackCapabilities = /* @__PURE__ */ Object.create(null), this.actionHandler = /* @__PURE__ */ Object.create(null), s.addEventListener("message", this.#e.bind(this), {
      signal: this.#t.signal
    });
  }
  #e({
    data: t
  }) {
    if (t.targetName !== this.sourceName)
      return;
    if (t.stream) {
      this.#s(t);
      return;
    }
    if (t.callback) {
      const s = t.callbackId, i = this.callbackCapabilities[s];
      if (!i)
        throw new Error(`Cannot resolve callback ${s}`);
      if (delete this.callbackCapabilities[s], t.callback === xe.DATA)
        i.resolve(t.data);
      else if (t.callback === xe.ERROR)
        i.reject(ft(t.reason));
      else
        throw new Error("Unexpected callback case");
      return;
    }
    const e = this.actionHandler[t.action];
    if (!e)
      throw new Error(`Unknown action from worker: ${t.action}`);
    if (t.callbackId) {
      const s = this.sourceName, i = t.sourceName, n = this.comObj;
      Promise.try(e, t.data).then(function(r) {
        n.postMessage({
          sourceName: s,
          targetName: i,
          callback: xe.DATA,
          callbackId: t.callbackId,
          data: r
        });
      }, function(r) {
        n.postMessage({
          sourceName: s,
          targetName: i,
          callback: xe.ERROR,
          callbackId: t.callbackId,
          reason: ft(r)
        });
      });
      return;
    }
    if (t.streamId) {
      this.#i(t);
      return;
    }
    e(t.data);
  }
  on(t, e) {
    const s = this.actionHandler;
    if (s[t])
      throw new Error(`There is already an actionName called "${t}"`);
    s[t] = e;
  }
  send(t, e, s) {
    this.comObj.postMessage({
      sourceName: this.sourceName,
      targetName: this.targetName,
      action: t,
      data: e
    }, s);
  }
  sendWithPromise(t, e, s) {
    const i = this.callbackId++, n = Promise.withResolvers();
    this.callbackCapabilities[i] = n;
    try {
      this.comObj.postMessage({
        sourceName: this.sourceName,
        targetName: this.targetName,
        action: t,
        callbackId: i,
        data: e
      }, s);
    } catch (r) {
      n.reject(r);
    }
    return n.promise;
  }
  sendWithStream(t, e, s, i) {
    const n = this.streamId++, r = this.sourceName, a = this.targetName, o = this.comObj;
    return new ReadableStream({
      start: (l) => {
        const h = Promise.withResolvers();
        return this.streamControllers[n] = {
          controller: l,
          startCall: h,
          pullCall: null,
          cancelCall: null,
          isClosed: !1
        }, o.postMessage({
          sourceName: r,
          targetName: a,
          action: t,
          streamId: n,
          data: e,
          desiredSize: l.desiredSize
        }, i), h.promise;
      },
      pull: (l) => {
        const h = Promise.withResolvers();
        return this.streamControllers[n].pullCall = h, o.postMessage({
          sourceName: r,
          targetName: a,
          stream: it.PULL,
          streamId: n,
          desiredSize: l.desiredSize
        }), h.promise;
      },
      cancel: (l) => {
        $(l instanceof Error, "cancel must have a valid reason");
        const h = Promise.withResolvers();
        return this.streamControllers[n].cancelCall = h, this.streamControllers[n].isClosed = !0, o.postMessage({
          sourceName: r,
          targetName: a,
          stream: it.CANCEL,
          streamId: n,
          reason: ft(l)
        }), h.promise;
      }
    }, s);
  }
  #i(t) {
    const e = t.streamId, s = this.sourceName, i = t.sourceName, n = this.comObj, r = this, a = this.actionHandler[t.action], o = {
      enqueue(l, h = 1, c) {
        if (this.isCancelled)
          return;
        const u = this.desiredSize;
        this.desiredSize -= h, u > 0 && this.desiredSize <= 0 && (this.sinkCapability = Promise.withResolvers(), this.ready = this.sinkCapability.promise), n.postMessage({
          sourceName: s,
          targetName: i,
          stream: it.ENQUEUE,
          streamId: e,
          chunk: l
        }, c);
      },
      close() {
        this.isCancelled || (this.isCancelled = !0, n.postMessage({
          sourceName: s,
          targetName: i,
          stream: it.CLOSE,
          streamId: e
        }), delete r.streamSinks[e]);
      },
      error(l) {
        $(l instanceof Error, "error must have a valid reason"), !this.isCancelled && (this.isCancelled = !0, n.postMessage({
          sourceName: s,
          targetName: i,
          stream: it.ERROR,
          streamId: e,
          reason: ft(l)
        }));
      },
      sinkCapability: Promise.withResolvers(),
      onPull: null,
      onCancel: null,
      isCancelled: !1,
      desiredSize: t.desiredSize,
      ready: null
    };
    o.sinkCapability.resolve(), o.ready = o.sinkCapability.promise, this.streamSinks[e] = o, Promise.try(a, t.data, o).then(function() {
      n.postMessage({
        sourceName: s,
        targetName: i,
        stream: it.START_COMPLETE,
        streamId: e,
        success: !0
      });
    }, function(l) {
      n.postMessage({
        sourceName: s,
        targetName: i,
        stream: it.START_COMPLETE,
        streamId: e,
        reason: ft(l)
      });
    });
  }
  #s(t) {
    const e = t.streamId, s = this.sourceName, i = t.sourceName, n = this.comObj, r = this.streamControllers[e], a = this.streamSinks[e];
    switch (t.stream) {
      case it.START_COMPLETE:
        t.success ? r.startCall.resolve() : r.startCall.reject(ft(t.reason));
        break;
      case it.PULL_COMPLETE:
        t.success ? r.pullCall.resolve() : r.pullCall.reject(ft(t.reason));
        break;
      case it.PULL:
        if (!a) {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: it.PULL_COMPLETE,
            streamId: e,
            success: !0
          });
          break;
        }
        a.desiredSize <= 0 && t.desiredSize > 0 && a.sinkCapability.resolve(), a.desiredSize = t.desiredSize, Promise.try(a.onPull || Gs).then(function() {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: it.PULL_COMPLETE,
            streamId: e,
            success: !0
          });
        }, function(l) {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: it.PULL_COMPLETE,
            streamId: e,
            reason: ft(l)
          });
        });
        break;
      case it.ENQUEUE:
        if ($(r, "enqueue should have stream controller"), r.isClosed)
          break;
        r.controller.enqueue(t.chunk);
        break;
      case it.CLOSE:
        if ($(r, "close should have stream controller"), r.isClosed)
          break;
        r.isClosed = !0, r.controller.close(), this.#a(r, e);
        break;
      case it.ERROR:
        $(r, "error should have stream controller"), r.controller.error(ft(t.reason)), this.#a(r, e);
        break;
      case it.CANCEL_COMPLETE:
        t.success ? r.cancelCall.resolve() : r.cancelCall.reject(ft(t.reason)), this.#a(r, e);
        break;
      case it.CANCEL:
        if (!a)
          break;
        const o = ft(t.reason);
        Promise.try(a.onCancel || Gs, o).then(function() {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: it.CANCEL_COMPLETE,
            streamId: e,
            success: !0
          });
        }, function(l) {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: it.CANCEL_COMPLETE,
            streamId: e,
            reason: ft(l)
          });
        }), a.sinkCapability.reject(o), a.isCancelled = !0, delete this.streamSinks[e];
        break;
      default:
        throw new Error("Unexpected stream case");
    }
  }
  async #a(t, e) {
    await Promise.allSettled([t.startCall?.promise, t.pullCall?.promise, t.cancelCall?.promise]), delete this.streamControllers[e];
  }
  destroy() {
    this.#t?.abort(), this.#t = null;
  }
}
class _i {
  #t = !1;
  constructor({
    enableHWA: t = !1
  }) {
    this.#t = t;
  }
  create(t, e) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid canvas size");
    const s = this._createCanvas(t, e);
    return {
      canvas: s,
      context: s.getContext("2d", {
        willReadFrequently: !this.#t
      })
    };
  }
  reset(t, e, s) {
    if (!t.canvas)
      throw new Error("Canvas is not specified");
    if (e <= 0 || s <= 0)
      throw new Error("Invalid canvas size");
    t.canvas.width = e, t.canvas.height = s;
  }
  destroy(t) {
    if (!t.canvas)
      throw new Error("Canvas is not specified");
    t.canvas.width = 0, t.canvas.height = 0, t.canvas = null, t.context = null;
  }
  _createCanvas(t, e) {
    j("Abstract method `_createCanvas` called.");
  }
}
class Sn extends _i {
  constructor({
    ownerDocument: t = globalThis.document,
    enableHWA: e = !1
  }) {
    super({
      enableHWA: e
    }), this._document = t;
  }
  _createCanvas(t, e) {
    const s = this._document.createElement("canvas");
    return s.width = t, s.height = e, s;
  }
}
class Ci {
  constructor({
    baseUrl: t = null,
    isCompressed: e = !0
  }) {
    this.baseUrl = t, this.isCompressed = e;
  }
  async fetch({
    name: t
  }) {
    if (!this.baseUrl)
      throw new Error("Ensure that the `cMapUrl` and `cMapPacked` API parameters are provided.");
    if (!t)
      throw new Error("CMap name must be specified.");
    const e = this.baseUrl + t + (this.isCompressed ? ".bcmap" : "");
    return this._fetch(e).then((s) => ({
      cMapData: s,
      isCompressed: this.isCompressed
    })).catch((s) => {
      throw new Error(`Unable to load ${this.isCompressed ? "binary " : ""}CMap at: ${e}`);
    });
  }
  async _fetch(t) {
    j("Abstract method `_fetch` called.");
  }
}
class Vs extends Ci {
  async _fetch(t) {
    const e = await ee(t, this.isCompressed ? "arraybuffer" : "text");
    return e instanceof ArrayBuffer ? new Uint8Array(e) : He(e);
  }
}
class Ti {
  addFilter(t) {
    return "none";
  }
  addHCMFilter(t, e) {
    return "none";
  }
  addAlphaFilter(t) {
    return "none";
  }
  addLuminosityFilter(t) {
    return "none";
  }
  addHighlightHCMFilter(t, e, s, i, n) {
    return "none";
  }
  destroy(t = !1) {
  }
}
class En extends Ti {
  #t;
  #e;
  #i;
  #s;
  #a;
  #r;
  #n = 0;
  constructor({
    docId: t,
    ownerDocument: e = globalThis.document
  }) {
    super(), this.#s = t, this.#a = e;
  }
  get #o() {
    return this.#e ||= /* @__PURE__ */ new Map();
  }
  get #h() {
    return this.#r ||= /* @__PURE__ */ new Map();
  }
  get #l() {
    if (!this.#i) {
      const t = this.#a.createElement("div"), {
        style: e
      } = t;
      e.visibility = "hidden", e.contain = "strict", e.width = e.height = 0, e.position = "absolute", e.top = e.left = 0, e.zIndex = -1;
      const s = this.#a.createElementNS(Mt, "svg");
      s.setAttribute("width", 0), s.setAttribute("height", 0), this.#i = this.#a.createElementNS(Mt, "defs"), t.append(s), s.append(this.#i), this.#a.body.append(t);
    }
    return this.#i;
  }
  #u(t) {
    if (t.length === 1) {
      const o = t[0], l = new Array(256);
      for (let c = 0; c < 256; c++)
        l[c] = o[c] / 255;
      const h = l.join(",");
      return [h, h, h];
    }
    const [e, s, i] = t, n = new Array(256), r = new Array(256), a = new Array(256);
    for (let o = 0; o < 256; o++)
      n[o] = e[o] / 255, r[o] = s[o] / 255, a[o] = i[o] / 255;
    return [n.join(","), r.join(","), a.join(",")];
  }
  #d(t) {
    if (this.#t === void 0) {
      this.#t = "";
      const e = this.#a.URL;
      e !== this.#a.baseURI && (ve(e) ? R('#createUrl: ignore "data:"-URL for performance reasons.') : this.#t = As(e, ""));
    }
    return `url(${this.#t}#${t})`;
  }
  addFilter(t) {
    if (!t)
      return "none";
    let e = this.#o.get(t);
    if (e)
      return e;
    const [s, i, n] = this.#u(t), r = t.length === 1 ? s : `${s}${i}${n}`;
    if (e = this.#o.get(r), e)
      return this.#o.set(t, e), e;
    const a = `g_${this.#s}_transfer_map_${this.#n++}`, o = this.#d(a);
    this.#o.set(t, o), this.#o.set(r, o);
    const l = this.#g(a);
    return this.#p(s, i, n, l), o;
  }
  addHCMFilter(t, e) {
    const s = `${t}-${e}`, i = "base";
    let n = this.#h.get(i);
    if (n?.key === s || (n ? (n.filter?.remove(), n.key = s, n.url = "none", n.filter = null) : (n = {
      key: s,
      url: "none",
      filter: null
    }, this.#h.set(i, n)), !t || !e))
      return n.url;
    const r = this.#y(t);
    t = T.makeHexColor(...r);
    const a = this.#y(e);
    if (e = T.makeHexColor(...a), this.#l.style.color = "", t === "#000000" && e === "#ffffff" || t === e)
      return n.url;
    const o = new Array(256);
    for (let f = 0; f <= 255; f++) {
      const g = f / 255;
      o[f] = g <= 0.03928 ? g / 12.92 : ((g + 0.055) / 1.055) ** 2.4;
    }
    const l = o.join(","), h = `g_${this.#s}_hcm_filter`, c = n.filter = this.#g(h);
    this.#p(l, l, l, c), this.#m(c);
    const u = (f, g) => {
      const p = r[f] / 255, b = a[f] / 255, m = new Array(g + 1);
      for (let y = 0; y <= g; y++)
        m[y] = p + y / g * (b - p);
      return m.join(",");
    };
    return this.#p(u(0, 5), u(1, 5), u(2, 5), c), n.url = this.#d(h), n.url;
  }
  addAlphaFilter(t) {
    let e = this.#o.get(t);
    if (e)
      return e;
    const [s] = this.#u([t]), i = `alpha_${s}`;
    if (e = this.#o.get(i), e)
      return this.#o.set(t, e), e;
    const n = `g_${this.#s}_alpha_map_${this.#n++}`, r = this.#d(n);
    this.#o.set(t, r), this.#o.set(i, r);
    const a = this.#g(n);
    return this.#b(s, a), r;
  }
  addLuminosityFilter(t) {
    let e = this.#o.get(t || "luminosity");
    if (e)
      return e;
    let s, i;
    if (t ? ([s] = this.#u([t]), i = `luminosity_${s}`) : i = "luminosity", e = this.#o.get(i), e)
      return this.#o.set(t, e), e;
    const n = `g_${this.#s}_luminosity_map_${this.#n++}`, r = this.#d(n);
    this.#o.set(t, r), this.#o.set(i, r);
    const a = this.#g(n);
    return this.#f(a), t && this.#b(s, a), r;
  }
  addHighlightHCMFilter(t, e, s, i, n) {
    const r = `${e}-${s}-${i}-${n}`;
    let a = this.#h.get(t);
    if (a?.key === r || (a ? (a.filter?.remove(), a.key = r, a.url = "none", a.filter = null) : (a = {
      key: r,
      url: "none",
      filter: null
    }, this.#h.set(t, a)), !e || !s))
      return a.url;
    const [o, l] = [e, s].map(this.#y.bind(this));
    let h = Math.round(0.2126 * o[0] + 0.7152 * o[1] + 0.0722 * o[2]), c = Math.round(0.2126 * l[0] + 0.7152 * l[1] + 0.0722 * l[2]), [u, f] = [i, n].map(this.#y.bind(this));
    c < h && ([h, c, u, f] = [c, h, f, u]), this.#l.style.color = "";
    const g = (m, y, A) => {
      const v = new Array(256), w = (c - h) / A, S = m / 255, E = (y - m) / (255 * A);
      let _ = 0;
      for (let C = 0; C <= A; C++) {
        const k = Math.round(h + C * w), x = S + C * E;
        for (let z = _; z <= k; z++)
          v[z] = x;
        _ = k + 1;
      }
      for (let C = _; C < 256; C++)
        v[C] = v[_ - 1];
      return v.join(",");
    }, p = `g_${this.#s}_hcm_${t}_filter`, b = a.filter = this.#g(p);
    return this.#m(b), this.#p(g(u[0], f[0], 5), g(u[1], f[1], 5), g(u[2], f[2], 5), b), a.url = this.#d(p), a.url;
  }
  destroy(t = !1) {
    t && this.#r?.size || (this.#i?.parentNode.parentNode.remove(), this.#i = null, this.#e?.clear(), this.#e = null, this.#r?.clear(), this.#r = null, this.#n = 0);
  }
  #f(t) {
    const e = this.#a.createElementNS(Mt, "feColorMatrix");
    e.setAttribute("type", "matrix"), e.setAttribute("values", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.3 0.59 0.11 0 0"), t.append(e);
  }
  #m(t) {
    const e = this.#a.createElementNS(Mt, "feColorMatrix");
    e.setAttribute("type", "matrix"), e.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), t.append(e);
  }
  #g(t) {
    const e = this.#a.createElementNS(Mt, "filter");
    return e.setAttribute("color-interpolation-filters", "sRGB"), e.setAttribute("id", t), this.#l.append(e), e;
  }
  #c(t, e, s) {
    const i = this.#a.createElementNS(Mt, e);
    i.setAttribute("type", "discrete"), i.setAttribute("tableValues", s), t.append(i);
  }
  #p(t, e, s, i) {
    const n = this.#a.createElementNS(Mt, "feComponentTransfer");
    i.append(n), this.#c(n, "feFuncR", t), this.#c(n, "feFuncG", e), this.#c(n, "feFuncB", s);
  }
  #b(t, e) {
    const s = this.#a.createElementNS(Mt, "feComponentTransfer");
    e.append(s), this.#c(s, "feFuncA", t);
  }
  #y(t) {
    return this.#l.style.color = t, se(getComputedStyle(this.#l).getPropertyValue("color"));
  }
}
class xi {
  constructor({
    baseUrl: t = null
  }) {
    this.baseUrl = t;
  }
  async fetch({
    filename: t
  }) {
    if (!this.baseUrl)
      throw new Error("Ensure that the `standardFontDataUrl` API parameter is provided.");
    if (!t)
      throw new Error("Font filename must be specified.");
    const e = `${this.baseUrl}${t}`;
    return this._fetch(e).catch((s) => {
      throw new Error(`Unable to load font data at: ${e}`);
    });
  }
  async _fetch(t) {
    j("Abstract method `_fetch` called.");
  }
}
class Ws extends xi {
  async _fetch(t) {
    const e = await ee(t, "arraybuffer");
    return new Uint8Array(e);
  }
}
class Pi {
  constructor({
    baseUrl: t = null
  }) {
    this.baseUrl = t;
  }
  async fetch({
    filename: t
  }) {
    if (!this.baseUrl)
      throw new Error("Ensure that the `wasmUrl` API parameter is provided.");
    if (!t)
      throw new Error("Wasm filename must be specified.");
    const e = `${this.baseUrl}${t}`;
    return this._fetch(e).catch((s) => {
      throw new Error(`Unable to load wasm data at: ${e}`);
    });
  }
  async _fetch(t) {
    j("Abstract method `_fetch` called.");
  }
}
class Xs extends Pi {
  async _fetch(t) {
    const e = await ee(t, "arraybuffer");
    return new Uint8Array(e);
  }
}
ut && R("Please use the `legacy` build in Node.js environments.");
async function Cs(d) {
  const e = await process.getBuiltinModule("fs").promises.readFile(d);
  return new Uint8Array(e);
}
class _n extends Ti {
}
class Cn extends _i {
  _createCanvas(t, e) {
    return process.getBuiltinModule("module").createRequire(import.meta.url)("@napi-rs/canvas").createCanvas(t, e);
  }
}
class Tn extends Ci {
  async _fetch(t) {
    return Cs(t);
  }
}
class xn extends xi {
  async _fetch(t) {
    return Cs(t);
  }
}
class Pn extends Pi {
  async _fetch(t) {
    return Cs(t);
  }
}
const Gt = "__forcedDependency", {
  floor: Ys,
  ceil: qs
} = Math;
function Pe(d, t, e, s, i, n) {
  d[t * 4 + 0] = Math.min(d[t * 4 + 0], e), d[t * 4 + 1] = Math.min(d[t * 4 + 1], s), d[t * 4 + 2] = Math.max(d[t * 4 + 2], i), d[t * 4 + 3] = Math.max(d[t * 4 + 3], n);
}
const ds = new Uint32Array(new Uint8Array([255, 255, 0, 0]).buffer)[0];
class kn {
  #t;
  #e;
  constructor(t, e) {
    this.#t = t, this.#e = e;
  }
  get length() {
    return this.#t.length;
  }
  isEmpty(t) {
    return this.#t[t] === ds;
  }
  minX(t) {
    return this.#e[t * 4 + 0] / 256;
  }
  minY(t) {
    return this.#e[t * 4 + 1] / 256;
  }
  maxX(t) {
    return (this.#e[t * 4 + 2] + 1) / 256;
  }
  maxY(t) {
    return (this.#e[t * 4 + 3] + 1) / 256;
  }
}
const ke = (d, t) => {
  if (!d)
    return;
  let e = d.get(t);
  return e || (e = {
    dependencies: /* @__PURE__ */ new Set(),
    isRenderingOperation: !1
  }, d.set(t, e)), e;
};
class Mn {
  #t = {
    __proto__: null
  };
  #e = {
    __proto__: null,
    transform: [],
    moveText: [],
    sameLineText: [],
    [Gt]: []
  };
  #i = /* @__PURE__ */ new Map();
  #s = [];
  #a = [];
  #r = [[1, 0, 0, 1, 0, 0]];
  #n = [-1 / 0, -1 / 0, 1 / 0, 1 / 0];
  #o = new Float64Array([1 / 0, 1 / 0, -1 / 0, -1 / 0]);
  #h = -1;
  #l = /* @__PURE__ */ new Set();
  #u = /* @__PURE__ */ new Map();
  #d = /* @__PURE__ */ new Map();
  #f;
  #m;
  #g;
  #c;
  #p;
  constructor(t, e, s = !1) {
    this.#f = t.width, this.#m = t.height, this.#b(e), s && (this.#p = /* @__PURE__ */ new Map());
  }
  growOperationsCount(t) {
    t >= this.#c.length && this.#b(t, this.#c);
  }
  #b(t, e) {
    const s = new ArrayBuffer(t * 4);
    this.#g = new Uint8ClampedArray(s), this.#c = new Uint32Array(s), e && e.length > 0 ? (this.#c.set(e), this.#c.fill(ds, e.length)) : this.#c.fill(ds);
  }
  save(t) {
    return this.#t = {
      __proto__: this.#t
    }, this.#e = {
      __proto__: this.#e,
      transform: {
        __proto__: this.#e.transform
      },
      moveText: {
        __proto__: this.#e.moveText
      },
      sameLineText: {
        __proto__: this.#e.sameLineText
      },
      [Gt]: {
        __proto__: this.#e[Gt]
      }
    }, this.#n = {
      __proto__: this.#n
    }, this.#s.push(t), this;
  }
  restore(t) {
    const e = Object.getPrototypeOf(this.#t);
    if (e === null)
      return this;
    this.#t = e, this.#e = Object.getPrototypeOf(this.#e), this.#n = Object.getPrototypeOf(this.#n);
    const s = this.#s.pop();
    return s !== void 0 && (ke(this.#p, t)?.dependencies.add(s), this.#c[t] = this.#c[s]), this;
  }
  recordOpenMarker(t) {
    return this.#s.push(t), this;
  }
  getOpenMarker() {
    return this.#s.length === 0 ? null : this.#s.at(-1);
  }
  recordCloseMarker(t) {
    const e = this.#s.pop();
    return e !== void 0 && (ke(this.#p, t)?.dependencies.add(e), this.#c[t] = this.#c[e]), this;
  }
  beginMarkedContent(t) {
    return this.#a.push(t), this;
  }
  endMarkedContent(t) {
    const e = this.#a.pop();
    return e !== void 0 && (ke(this.#p, t)?.dependencies.add(e), this.#c[t] = this.#c[e]), this;
  }
  pushBaseTransform(t) {
    return this.#r.push(T.multiplyByDOMMatrix(this.#r.at(-1), t.getTransform())), this;
  }
  popBaseTransform() {
    return this.#r.length > 1 && this.#r.pop(), this;
  }
  recordSimpleData(t, e) {
    return this.#t[t] = e, this;
  }
  recordIncrementalData(t, e) {
    return this.#e[t].push(e), this;
  }
  resetIncrementalData(t, e) {
    return this.#e[t].length = 0, this;
  }
  recordNamedData(t, e) {
    return this.#i.set(t, e), this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    this.#t[t] = this.#i.get(e) ?? s;
  }
  recordFutureForcedDependency(t, e) {
    return this.recordIncrementalData(Gt, e), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    for (const e of t)
      e in this.#t && this.recordFutureForcedDependency(e, this.#t[e]);
    return this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    for (const t of this.#l)
      this.recordFutureForcedDependency(Gt, t);
    return this;
  }
  resetBBox(t) {
    return this.#h !== t && (this.#h = t, this.#o[0] = 1 / 0, this.#o[1] = 1 / 0, this.#o[2] = -1 / 0, this.#o[3] = -1 / 0), this;
  }
  recordClipBox(t, e, s, i, n, r) {
    const a = T.multiplyByDOMMatrix(this.#r.at(-1), e.getTransform()), o = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
    T.axialAlignedBoundingBox([s, n, i, r], a, o);
    const l = T.intersect(this.#n, o);
    return l ? (this.#n[0] = l[0], this.#n[1] = l[1], this.#n[2] = l[2], this.#n[3] = l[3]) : (this.#n[0] = this.#n[1] = 1 / 0, this.#n[2] = this.#n[3] = -1 / 0), this;
  }
  recordBBox(t, e, s, i, n, r) {
    const a = this.#n;
    if (a[0] === 1 / 0)
      return this;
    const o = T.multiplyByDOMMatrix(this.#r.at(-1), e.getTransform());
    if (a[0] === -1 / 0)
      return T.axialAlignedBoundingBox([s, n, i, r], o, this.#o), this;
    const l = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
    return T.axialAlignedBoundingBox([s, n, i, r], o, l), this.#o[0] = Math.min(this.#o[0], Math.max(l[0], a[0])), this.#o[1] = Math.min(this.#o[1], Math.max(l[1], a[1])), this.#o[2] = Math.max(this.#o[2], Math.min(l[2], a[2])), this.#o[3] = Math.max(this.#o[3], Math.min(l[3], a[3])), this;
  }
  recordCharacterBBox(t, e, s, i = 1, n = 0, r = 0, a) {
    const o = s.bbox;
    let l, h;
    if (o && (l = o[2] !== o[0] && o[3] !== o[1] && this.#d.get(s), l !== !1 && (h = [0, 0, 0, 0], T.axialAlignedBoundingBox(o, s.fontMatrix, h), (i !== 1 || n !== 0 || r !== 0) && T.scaleMinMax([i, 0, 0, -i, n, r], h), l)))
      return this.recordBBox(t, e, h[0], h[2], h[1], h[3]);
    if (!a)
      return this.recordFullPageBBox(t);
    const c = a();
    return o && h && l === void 0 && (l = h[0] <= n - c.actualBoundingBoxLeft && h[2] >= n + c.actualBoundingBoxRight && h[1] <= r - c.actualBoundingBoxAscent && h[3] >= r + c.actualBoundingBoxDescent, this.#d.set(s, l), l) ? this.recordBBox(t, e, h[0], h[2], h[1], h[3]) : this.recordBBox(t, e, n - c.actualBoundingBoxLeft, n + c.actualBoundingBoxRight, r - c.actualBoundingBoxAscent, r + c.actualBoundingBoxDescent);
  }
  recordFullPageBBox(t) {
    return this.#o[0] = Math.max(0, this.#n[0]), this.#o[1] = Math.max(0, this.#n[1]), this.#o[2] = Math.min(this.#f, this.#n[2]), this.#o[3] = Math.min(this.#m, this.#n[3]), this;
  }
  getSimpleIndex(t) {
    return this.#t[t];
  }
  recordDependencies(t, e) {
    const s = this.#l, i = this.#t, n = this.#e;
    for (const r of e)
      r in this.#t ? s.add(i[r]) : r in n && n[r].forEach(s.add, s);
    return this;
  }
  recordNamedDependency(t, e) {
    return this.#i.has(e) && this.#l.add(this.#i.get(e)), this;
  }
  recordOperation(t, e = !1) {
    if (this.recordDependencies(t, [Gt]), this.#p) {
      const s = ke(this.#p, t), {
        dependencies: i
      } = s;
      this.#l.forEach(i.add, i), this.#s.forEach(i.add, i), this.#a.forEach(i.add, i), i.delete(t), s.isRenderingOperation = !0;
    }
    if (this.#h === t) {
      const s = Ys(this.#o[0] * 256 / this.#f), i = Ys(this.#o[1] * 256 / this.#m), n = qs(this.#o[2] * 256 / this.#f), r = qs(this.#o[3] * 256 / this.#m);
      Pe(this.#g, t, s, i, n, r);
      for (const a of this.#l)
        a !== t && Pe(this.#g, a, s, i, n, r);
      for (const a of this.#s)
        a !== t && Pe(this.#g, a, s, i, n, r);
      for (const a of this.#a)
        a !== t && Pe(this.#g, a, s, i, n, r);
      e || (this.#l.clear(), this.#h = -1);
    }
    return this;
  }
  recordShowTextOperation(t, e = !1) {
    const s = Array.from(this.#l);
    this.recordOperation(t, e), this.recordIncrementalData("sameLineText", t);
    for (const i of s)
      this.recordIncrementalData("sameLineText", i);
    return this;
  }
  bboxToClipBoxDropOperation(t, e = !1) {
    return this.#h === t && (this.#h = -1, this.#n[0] = Math.max(this.#n[0], this.#o[0]), this.#n[1] = Math.max(this.#n[1], this.#o[1]), this.#n[2] = Math.min(this.#n[2], this.#o[2]), this.#n[3] = Math.min(this.#n[3], this.#o[3]), e || this.#l.clear()), this;
  }
  _takePendingDependencies() {
    const t = this.#l;
    return this.#l = /* @__PURE__ */ new Set(), t;
  }
  _extractOperation(t) {
    const e = this.#u.get(t);
    return this.#u.delete(t), e;
  }
  _pushPendingDependencies(t) {
    for (const e of t)
      this.#l.add(e);
  }
  take() {
    return this.#d.clear(), new kn(this.#c, this.#g);
  }
  takeDebugMetadata() {
    return this.#p;
  }
}
class Oe {
  #t;
  #e;
  #i;
  #s = 0;
  #a = 0;
  constructor(t, e, s) {
    if (t instanceof Oe && t.#i === !!s)
      return t;
    this.#t = t, this.#e = e, this.#i = !!s;
  }
  growOperationsCount() {
    throw new Error("Unreachable");
  }
  save(t) {
    return this.#a++, this.#t.save(this.#e), this;
  }
  restore(t) {
    return this.#a > 0 && (this.#t.restore(this.#e), this.#a--), this;
  }
  recordOpenMarker(t) {
    return this.#s++, this;
  }
  getOpenMarker() {
    return this.#s > 0 ? this.#e : this.#t.getOpenMarker();
  }
  recordCloseMarker(t) {
    return this.#s--, this;
  }
  beginMarkedContent(t) {
    return this;
  }
  endMarkedContent(t) {
    return this;
  }
  pushBaseTransform(t) {
    return this.#t.pushBaseTransform(t), this;
  }
  popBaseTransform() {
    return this.#t.popBaseTransform(), this;
  }
  recordSimpleData(t, e) {
    return this.#t.recordSimpleData(t, this.#e), this;
  }
  recordIncrementalData(t, e) {
    return this.#t.recordIncrementalData(t, this.#e), this;
  }
  resetIncrementalData(t, e) {
    return this.#t.resetIncrementalData(t, this.#e), this;
  }
  recordNamedData(t, e) {
    return this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    return this.#t.recordSimpleDataFromNamed(t, e, this.#e), this;
  }
  recordFutureForcedDependency(t, e) {
    return this.#t.recordFutureForcedDependency(t, this.#e), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    return this.#t.inheritSimpleDataAsFutureForcedDependencies(t), this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    return this.#t.inheritPendingDependenciesAsFutureForcedDependencies(), this;
  }
  resetBBox(t) {
    return this.#i || this.#t.resetBBox(this.#e), this;
  }
  recordClipBox(t, e, s, i, n, r) {
    return this.#i || this.#t.recordClipBox(this.#e, e, s, i, n, r), this;
  }
  recordBBox(t, e, s, i, n, r) {
    return this.#i || this.#t.recordBBox(this.#e, e, s, i, n, r), this;
  }
  recordCharacterBBox(t, e, s, i, n, r, a) {
    return this.#i || this.#t.recordCharacterBBox(this.#e, e, s, i, n, r, a), this;
  }
  recordFullPageBBox(t) {
    return this.#i || this.#t.recordFullPageBBox(this.#e), this;
  }
  getSimpleIndex(t) {
    return this.#t.getSimpleIndex(t);
  }
  recordDependencies(t, e) {
    return this.#t.recordDependencies(this.#e, e), this;
  }
  recordNamedDependency(t, e) {
    return this.#t.recordNamedDependency(this.#e, e), this;
  }
  recordOperation(t) {
    return this.#t.recordOperation(this.#e, !0), this;
  }
  recordShowTextOperation(t) {
    return this.#t.recordShowTextOperation(this.#e, !0), this;
  }
  bboxToClipBoxDropOperation(t) {
    return this.#i || this.#t.bboxToClipBoxDropOperation(this.#e, !0), this;
  }
  take() {
    throw new Error("Unreachable");
  }
  takeDebugMetadata() {
    throw new Error("Unreachable");
  }
}
const St = {
  stroke: ["path", "transform", "filter", "strokeColor", "strokeAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "dash"],
  fill: ["path", "transform", "filter", "fillColor", "fillAlpha", "globalCompositeOperation", "SMask"],
  imageXObject: ["transform", "SMask", "filter", "fillAlpha", "strokeAlpha", "globalCompositeOperation"],
  rawFillPath: ["filter", "fillColor", "fillAlpha"],
  showText: ["transform", "leading", "charSpacing", "wordSpacing", "hScale", "textRise", "moveText", "textMatrix", "font", "fontObj", "filter", "fillColor", "textRenderingMode", "SMask", "fillAlpha", "strokeAlpha", "globalCompositeOperation", "sameLineText"],
  transform: ["transform"],
  transformAndFill: ["transform", "fillColor"]
}, dt = {
  FILL: "Fill",
  STROKE: "Stroke",
  SHADING: "Shading"
};
function us(d, t) {
  if (!t)
    return;
  const e = t[2] - t[0], s = t[3] - t[1], i = new Path2D();
  i.rect(t[0], t[1], e, s), d.clip(i);
}
class Ts {
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern() {
    j("Abstract method `getPattern` called.");
  }
}
class Dn extends Ts {
  constructor(t) {
    super(), this._type = t[1], this._bbox = t[2], this._colorStops = t[3], this._p0 = t[4], this._p1 = t[5], this._r0 = t[6], this._r1 = t[7], this.matrix = null;
  }
  isOriginBased() {
    return this._p0[0] === 0 && this._p0[1] === 0 && (!this.isRadial() || this._p1[0] === 0 && this._p1[1] === 0);
  }
  isRadial() {
    return this._type === "radial";
  }
  _createGradient(t, e = null) {
    let s, i = this._p0, n = this._p1;
    if (e && (i = i.slice(), n = n.slice(), T.applyTransform(i, e), T.applyTransform(n, e)), this._type === "axial")
      s = t.createLinearGradient(i[0], i[1], n[0], n[1]);
    else if (this._type === "radial") {
      let r = this._r0, a = this._r1;
      if (e) {
        const o = new Float32Array(2);
        T.singularValueDecompose2dScale(e, o), r *= o[0], a *= o[0];
      }
      s = t.createRadialGradient(i[0], i[1], r, n[0], n[1], a);
    }
    for (const r of this._colorStops)
      s.addColorStop(r[0], r[1]);
    return s;
  }
  getPattern(t, e, s, i) {
    let n;
    if (i === dt.STROKE || i === dt.FILL) {
      if (this.isOriginBased()) {
        let u = T.transform(s, e.baseTransform);
        this.matrix && (u = T.transform(u, this.matrix));
        const f = 1e-3, g = Math.hypot(u[0], u[1]), p = Math.hypot(u[2], u[3]), b = (u[0] * u[2] + u[1] * u[3]) / (g * p);
        if (Math.abs(b) < f)
          if (this.isRadial()) {
            if (Math.abs(g - p) < f)
              return this._createGradient(t, u);
          } else
            return this._createGradient(t, u);
      }
      const r = e.current.getClippedPathBoundingBox(i, q(t)) || [0, 0, 0, 0], a = Math.ceil(r[2] - r[0]) || 1, o = Math.ceil(r[3] - r[1]) || 1, l = e.cachedCanvases.getCanvas("pattern", a, o), h = l.context;
      h.clearRect(0, 0, h.canvas.width, h.canvas.height), h.beginPath(), h.rect(0, 0, h.canvas.width, h.canvas.height), h.translate(-r[0], -r[1]), s = T.transform(s, [1, 0, 0, 1, r[0], r[1]]), h.transform(...e.baseTransform), this.matrix && h.transform(...this.matrix), us(h, this._bbox), h.fillStyle = this._createGradient(h), h.fill(), n = t.createPattern(l.canvas, "no-repeat");
      const c = new DOMMatrix(s);
      n.setTransform(c);
    } else
      us(t, this._bbox), n = this._createGradient(t);
    return n;
  }
}
function ss(d, t, e, s, i, n, r, a) {
  const o = t.coords, l = t.colors, h = d.data, c = d.width * 4;
  let u;
  o[e + 1] > o[s + 1] && (u = e, e = s, s = u, u = n, n = r, r = u), o[s + 1] > o[i + 1] && (u = s, s = i, i = u, u = r, r = a, a = u), o[e + 1] > o[s + 1] && (u = e, e = s, s = u, u = n, n = r, r = u);
  const f = (o[e] + t.offsetX) * t.scaleX, g = (o[e + 1] + t.offsetY) * t.scaleY, p = (o[s] + t.offsetX) * t.scaleX, b = (o[s + 1] + t.offsetY) * t.scaleY, m = (o[i] + t.offsetX) * t.scaleX, y = (o[i + 1] + t.offsetY) * t.scaleY;
  if (g >= y)
    return;
  const A = l[n], v = l[n + 1], w = l[n + 2], S = l[r], E = l[r + 1], _ = l[r + 2], C = l[a], k = l[a + 1], x = l[a + 2], z = Math.round(g), W = Math.round(y);
  let O, tt, M, L, G, mt, kt, et;
  for (let X = z; X <= W; X++) {
    if (X < b) {
      const st = X < g ? 0 : (g - X) / (g - b);
      O = f - (f - p) * st, tt = A - (A - S) * st, M = v - (v - E) * st, L = w - (w - _) * st;
    } else {
      let st;
      X > y ? st = 1 : b === y ? st = 0 : st = (b - X) / (b - y), O = p - (p - m) * st, tt = S - (S - C) * st, M = E - (E - k) * st, L = _ - (_ - x) * st;
    }
    let Y;
    X < g ? Y = 0 : X > y ? Y = 1 : Y = (g - X) / (g - y), G = f - (f - m) * Y, mt = A - (A - C) * Y, kt = v - (v - k) * Y, et = w - (w - x) * Y;
    const Ot = Math.round(Math.min(O, G)), Rt = Math.round(Math.max(O, G));
    let Ft = c * X + Ot * 4;
    for (let st = Ot; st <= Rt; st++)
      Y = (O - st) / (O - G), Y < 0 ? Y = 0 : Y > 1 && (Y = 1), h[Ft++] = tt - (tt - mt) * Y | 0, h[Ft++] = M - (M - kt) * Y | 0, h[Ft++] = L - (L - et) * Y | 0, h[Ft++] = 255;
  }
}
function Ln(d, t, e) {
  const s = t.coords, i = t.colors;
  let n, r;
  switch (t.type) {
    case os.LATTICE:
      const a = t.verticesPerRow, o = Math.floor(s.length / a) - 1, l = a - 1;
      for (n = 0; n < o; n++) {
        let h = n * a;
        for (let c = 0; c < l; c++, h++)
          ss(d, e, s[h], s[h + 1], s[h + a], i[h], i[h + 1], i[h + a]), ss(d, e, s[h + a + 1], s[h + 1], s[h + a], i[h + a + 1], i[h + 1], i[h + a]);
      }
      break;
    case os.TRIANGLES:
      for (n = 0, r = s.length; n < r; n += 3)
        ss(d, e, s[n], s[n + 1], s[n + 2], i[n], i[n + 1], i[n + 2]);
      break;
    default:
      throw new Error("illegal figure");
  }
}
class In extends Ts {
  constructor(t) {
    super(), this._coords = t[2], this._colors = t[3], this._figures = t[4], this._bounds = t[5], this._bbox = t[6], this._background = t[7], this.matrix = null;
  }
  _createMeshCanvas(t, e, s) {
    const a = Math.floor(this._bounds[0]), o = Math.floor(this._bounds[1]), l = Math.ceil(this._bounds[2]) - a, h = Math.ceil(this._bounds[3]) - o, c = Math.min(Math.ceil(Math.abs(l * t[0] * 1.1)), 3e3), u = Math.min(Math.ceil(Math.abs(h * t[1] * 1.1)), 3e3), f = l / c, g = h / u, p = {
      coords: this._coords,
      colors: this._colors,
      offsetX: -a,
      offsetY: -o,
      scaleX: 1 / f,
      scaleY: 1 / g
    }, b = c + 2 * 2, m = u + 2 * 2, y = s.getCanvas("mesh", b, m), A = y.context, v = A.createImageData(c, u);
    if (e) {
      const S = v.data;
      for (let E = 0, _ = S.length; E < _; E += 4)
        S[E] = e[0], S[E + 1] = e[1], S[E + 2] = e[2], S[E + 3] = 255;
    }
    for (const S of this._figures)
      Ln(v, S, p);
    return A.putImageData(v, 2, 2), {
      canvas: y.canvas,
      offsetX: a - 2 * f,
      offsetY: o - 2 * g,
      scaleX: f,
      scaleY: g
    };
  }
  isModifyingCurrentTransform() {
    return !0;
  }
  getPattern(t, e, s, i) {
    us(t, this._bbox);
    const n = new Float32Array(2);
    if (i === dt.SHADING)
      T.singularValueDecompose2dScale(q(t), n);
    else if (this.matrix) {
      T.singularValueDecompose2dScale(this.matrix, n);
      const [a, o] = n;
      T.singularValueDecompose2dScale(e.baseTransform, n), n[0] *= a, n[1] *= o;
    } else
      T.singularValueDecompose2dScale(e.baseTransform, n);
    const r = this._createMeshCanvas(n, i === dt.SHADING ? null : this._background, e.cachedCanvases);
    return i !== dt.SHADING && (t.setTransform(...e.baseTransform), this.matrix && t.transform(...this.matrix)), t.translate(r.offsetX, r.offsetY), t.scale(r.scaleX, r.scaleY), t.createPattern(r.canvas, "no-repeat");
  }
}
class Rn extends Ts {
  getPattern() {
    return "hotpink";
  }
}
function Fn(d) {
  switch (d[0]) {
    case "RadialAxial":
      return new Dn(d);
    case "Mesh":
      return new In(d);
    case "Dummy":
      return new Rn();
  }
  throw new Error(`Unknown IR type: ${d[0]}`);
}
const Ks = {
  COLORED: 1,
  UNCOLORED: 2
};
class xs {
  static MAX_PATTERN_SIZE = 3e3;
  constructor(t, e, s, i) {
    this.color = t[1], this.operatorList = t[2], this.matrix = t[3], this.bbox = t[4], this.xstep = t[5], this.ystep = t[6], this.paintType = t[7], this.tilingType = t[8], this.ctx = e, this.canvasGraphicsFactory = s, this.baseTransform = i;
  }
  createPatternCanvas(t, e) {
    const {
      bbox: s,
      operatorList: i,
      paintType: n,
      tilingType: r,
      color: a,
      canvasGraphicsFactory: o
    } = this;
    let {
      xstep: l,
      ystep: h
    } = this;
    l = Math.abs(l), h = Math.abs(h), Ue("TilingType: " + r);
    const c = s[0], u = s[1], f = s[2], g = s[3], p = f - c, b = g - u, m = new Float32Array(2);
    T.singularValueDecompose2dScale(this.matrix, m);
    const [y, A] = m;
    T.singularValueDecompose2dScale(this.baseTransform, m);
    const v = y * m[0], w = A * m[1];
    let S = p, E = b, _ = !1, C = !1;
    const k = Math.ceil(l * v), x = Math.ceil(h * w), z = Math.ceil(p * v), W = Math.ceil(b * w);
    k >= z ? S = l : _ = !0, x >= W ? E = h : C = !0;
    const O = this.getSizeAndScale(S, this.ctx.canvas.width, v), tt = this.getSizeAndScale(E, this.ctx.canvas.height, w), M = t.cachedCanvases.getCanvas("pattern", O.size, tt.size), L = M.context, G = o.createCanvasGraphics(L, e);
    if (G.groupLevel = t.groupLevel, this.setFillAndStrokeStyleToContext(G, n, a), L.translate(-O.scale * c, -tt.scale * u), G.transform(0, O.scale, 0, 0, tt.scale, 0, 0), L.save(), G.dependencyTracker?.save(), this.clipBbox(G, c, u, f, g), G.baseTransform = q(G.ctx), G.executeOperatorList(i), G.endDrawing(), G.dependencyTracker?.restore(), L.restore(), _ || C) {
      const mt = M.canvas;
      _ && (S = l), C && (E = h);
      const kt = this.getSizeAndScale(S, this.ctx.canvas.width, v), et = this.getSizeAndScale(E, this.ctx.canvas.height, w), X = kt.size, Y = et.size, Ot = t.cachedCanvases.getCanvas("pattern-workaround", X, Y), Rt = Ot.context, Ft = _ ? Math.floor(p / l) : 0, st = C ? Math.floor(b / h) : 0;
      for (let ie = 0; ie <= Ft; ie++)
        for (let ne = 0; ne <= st; ne++)
          Rt.drawImage(mt, X * ie, Y * ne, X, Y, 0, 0, X, Y);
      return {
        canvas: Ot.canvas,
        scaleX: kt.scale,
        scaleY: et.scale,
        offsetX: c,
        offsetY: u
      };
    }
    return {
      canvas: M.canvas,
      scaleX: O.scale,
      scaleY: tt.scale,
      offsetX: c,
      offsetY: u
    };
  }
  getSizeAndScale(t, e, s) {
    const i = Math.max(xs.MAX_PATTERN_SIZE, e);
    let n = Math.ceil(t * s);
    return n >= i ? n = i : s = n / t, {
      scale: s,
      size: n
    };
  }
  clipBbox(t, e, s, i, n) {
    const r = i - e, a = n - s;
    t.ctx.rect(e, s, r, a), T.axialAlignedBoundingBox([e, s, i, n], q(t.ctx), t.current.minMax), t.clip(), t.endPath();
  }
  setFillAndStrokeStyleToContext(t, e, s) {
    const i = t.ctx, n = t.current;
    switch (e) {
      case Ks.COLORED:
        const {
          fillStyle: r,
          strokeStyle: a
        } = this.ctx;
        i.fillStyle = n.fillColor = r, i.strokeStyle = n.strokeColor = a;
        break;
      case Ks.UNCOLORED:
        i.fillStyle = i.strokeStyle = s, n.fillColor = n.strokeColor = s;
        break;
      default:
        throw new tn(`Unsupported paint type: ${e}`);
    }
  }
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern(t, e, s, i, n) {
    let r = s;
    i !== dt.SHADING && (r = T.transform(r, e.baseTransform), this.matrix && (r = T.transform(r, this.matrix)));
    const a = this.createPatternCanvas(e, n);
    let o = new DOMMatrix(r);
    o = o.translate(a.offsetX, a.offsetY), o = o.scale(1 / a.scaleX, 1 / a.scaleY);
    const l = t.createPattern(a.canvas, "repeat");
    return l.setTransform(o), l;
  }
}
function Nn({
  src: d,
  srcPos: t = 0,
  dest: e,
  width: s,
  height: i,
  nonBlackColor: n = 4294967295,
  inverseDecode: r = !1
}) {
  const a = nt.isLittleEndian ? 4278190080 : 255, [o, l] = r ? [n, a] : [a, n], h = s >> 3, c = s & 7, u = d.length;
  e = new Uint32Array(e.buffer);
  let f = 0;
  for (let g = 0; g < i; g++) {
    for (const b = t + h; t < b; t++) {
      const m = t < u ? d[t] : 255;
      e[f++] = m & 128 ? l : o, e[f++] = m & 64 ? l : o, e[f++] = m & 32 ? l : o, e[f++] = m & 16 ? l : o, e[f++] = m & 8 ? l : o, e[f++] = m & 4 ? l : o, e[f++] = m & 2 ? l : o, e[f++] = m & 1 ? l : o;
    }
    if (c === 0)
      continue;
    const p = t < u ? d[t++] : 255;
    for (let b = 0; b < c; b++)
      e[f++] = p & 1 << 7 - b ? l : o;
  }
  return {
    srcPos: t,
    destPos: f
  };
}
const Qs = 16, Js = 100, On = 15, Zs = 10, pt = 16, is = new DOMMatrix(), yt = new Float32Array(2), Yt = new Float32Array([1 / 0, 1 / 0, -1 / 0, -1 / 0]);
function Bn(d, t) {
  if (d._removeMirroring)
    throw new Error("Context is already forwarding operations.");
  d.__originalSave = d.save, d.__originalRestore = d.restore, d.__originalRotate = d.rotate, d.__originalScale = d.scale, d.__originalTranslate = d.translate, d.__originalTransform = d.transform, d.__originalSetTransform = d.setTransform, d.__originalResetTransform = d.resetTransform, d.__originalClip = d.clip, d.__originalMoveTo = d.moveTo, d.__originalLineTo = d.lineTo, d.__originalBezierCurveTo = d.bezierCurveTo, d.__originalRect = d.rect, d.__originalClosePath = d.closePath, d.__originalBeginPath = d.beginPath, d._removeMirroring = () => {
    d.save = d.__originalSave, d.restore = d.__originalRestore, d.rotate = d.__originalRotate, d.scale = d.__originalScale, d.translate = d.__originalTranslate, d.transform = d.__originalTransform, d.setTransform = d.__originalSetTransform, d.resetTransform = d.__originalResetTransform, d.clip = d.__originalClip, d.moveTo = d.__originalMoveTo, d.lineTo = d.__originalLineTo, d.bezierCurveTo = d.__originalBezierCurveTo, d.rect = d.__originalRect, d.closePath = d.__originalClosePath, d.beginPath = d.__originalBeginPath, delete d._removeMirroring;
  }, d.save = function() {
    t.save(), this.__originalSave();
  }, d.restore = function() {
    t.restore(), this.__originalRestore();
  }, d.translate = function(e, s) {
    t.translate(e, s), this.__originalTranslate(e, s);
  }, d.scale = function(e, s) {
    t.scale(e, s), this.__originalScale(e, s);
  }, d.transform = function(e, s, i, n, r, a) {
    t.transform(e, s, i, n, r, a), this.__originalTransform(e, s, i, n, r, a);
  }, d.setTransform = function(e, s, i, n, r, a) {
    t.setTransform(e, s, i, n, r, a), this.__originalSetTransform(e, s, i, n, r, a);
  }, d.resetTransform = function() {
    t.resetTransform(), this.__originalResetTransform();
  }, d.rotate = function(e) {
    t.rotate(e), this.__originalRotate(e);
  }, d.clip = function(e) {
    t.clip(e), this.__originalClip(e);
  }, d.moveTo = function(e, s) {
    t.moveTo(e, s), this.__originalMoveTo(e, s);
  }, d.lineTo = function(e, s) {
    t.lineTo(e, s), this.__originalLineTo(e, s);
  }, d.bezierCurveTo = function(e, s, i, n, r, a) {
    t.bezierCurveTo(e, s, i, n, r, a), this.__originalBezierCurveTo(e, s, i, n, r, a);
  }, d.rect = function(e, s, i, n) {
    t.rect(e, s, i, n), this.__originalRect(e, s, i, n);
  }, d.closePath = function() {
    t.closePath(), this.__originalClosePath();
  }, d.beginPath = function() {
    t.beginPath(), this.__originalBeginPath();
  };
}
class Un {
  constructor(t) {
    this.canvasFactory = t, this.cache = /* @__PURE__ */ Object.create(null);
  }
  getCanvas(t, e, s) {
    let i;
    return this.cache[t] !== void 0 ? (i = this.cache[t], this.canvasFactory.reset(i, e, s)) : (i = this.canvasFactory.create(e, s), this.cache[t] = i), i;
  }
  delete(t) {
    delete this.cache[t];
  }
  clear() {
    for (const t in this.cache) {
      const e = this.cache[t];
      this.canvasFactory.destroy(e), delete this.cache[t];
    }
  }
}
function Me(d, t, e, s, i, n, r, a, o, l) {
  const [h, c, u, f, g, p] = q(d);
  if (c === 0 && u === 0) {
    const y = r * h + g, A = Math.round(y), v = a * f + p, w = Math.round(v), S = (r + o) * h + g, E = Math.abs(Math.round(S) - A) || 1, _ = (a + l) * f + p, C = Math.abs(Math.round(_) - w) || 1;
    return d.setTransform(Math.sign(h), 0, 0, Math.sign(f), A, w), d.drawImage(t, e, s, i, n, 0, 0, E, C), d.setTransform(h, c, u, f, g, p), [E, C];
  }
  if (h === 0 && f === 0) {
    const y = a * u + g, A = Math.round(y), v = r * c + p, w = Math.round(v), S = (a + l) * u + g, E = Math.abs(Math.round(S) - A) || 1, _ = (r + o) * c + p, C = Math.abs(Math.round(_) - w) || 1;
    return d.setTransform(0, Math.sign(c), Math.sign(u), 0, A, w), d.drawImage(t, e, s, i, n, 0, 0, C, E), d.setTransform(h, c, u, f, g, p), [C, E];
  }
  d.drawImage(t, e, s, i, n, r, a, o, l);
  const b = Math.hypot(h, c), m = Math.hypot(u, f);
  return [b * o, m * l];
}
class ti {
  alphaIsShape = !1;
  fontSize = 0;
  fontSizeScale = 1;
  textMatrix = null;
  textMatrixScale = 1;
  fontMatrix = as;
  leading = 0;
  x = 0;
  y = 0;
  lineX = 0;
  lineY = 0;
  charSpacing = 0;
  wordSpacing = 0;
  textHScale = 1;
  textRenderingMode = rt.FILL;
  textRise = 0;
  fillColor = "#000000";
  strokeColor = "#000000";
  patternFill = !1;
  patternStroke = !1;
  fillAlpha = 1;
  strokeAlpha = 1;
  lineWidth = 1;
  activeSMask = null;
  transferMaps = "none";
  constructor(t, e, s) {
    s?.(this), this.clipBox = new Float32Array([0, 0, t, e]), this.minMax = Yt.slice();
  }
  clone() {
    const t = Object.create(this);
    return t.clipBox = this.clipBox.slice(), t.minMax = this.minMax.slice(), t;
  }
  getPathBoundingBox(t = dt.FILL, e = null) {
    const s = this.minMax.slice();
    if (t === dt.STROKE) {
      e || j("Stroke bounding box must include transform."), T.singularValueDecompose2dScale(e, yt);
      const i = yt[0] * this.lineWidth / 2, n = yt[1] * this.lineWidth / 2;
      s[0] -= i, s[1] -= n, s[2] += i, s[3] += n;
    }
    return s;
  }
  updateClipFromPath() {
    const t = T.intersect(this.clipBox, this.getPathBoundingBox());
    this.startNewPathAndClipBox(t || [0, 0, 0, 0]);
  }
  isEmptyClip() {
    return this.minMax[0] === 1 / 0;
  }
  startNewPathAndClipBox(t) {
    this.clipBox.set(t, 0), this.minMax.set(Yt, 0);
  }
  getClippedPathBoundingBox(t = dt.FILL, e = null) {
    return T.intersect(this.clipBox, this.getPathBoundingBox(t, e));
  }
}
function ei(d, t) {
  if (t instanceof ImageData) {
    d.putImageData(t, 0, 0);
    return;
  }
  const e = t.height, s = t.width, i = e % pt, n = (e - i) / pt, r = i === 0 ? n : n + 1, a = d.createImageData(s, pt);
  let o = 0, l;
  const h = t.data, c = a.data;
  let u, f, g, p;
  if (t.kind === ue.GRAYSCALE_1BPP) {
    const b = h.byteLength, m = new Uint32Array(c.buffer, 0, c.byteLength >> 2), y = m.length, A = s + 7 >> 3, v = 4294967295, w = nt.isLittleEndian ? 4278190080 : 255;
    for (u = 0; u < r; u++) {
      for (g = u < n ? pt : i, l = 0, f = 0; f < g; f++) {
        const S = b - o;
        let E = 0;
        const _ = S > A ? s : S * 8 - 7, C = _ & -8;
        let k = 0, x = 0;
        for (; E < C; E += 8)
          x = h[o++], m[l++] = x & 128 ? v : w, m[l++] = x & 64 ? v : w, m[l++] = x & 32 ? v : w, m[l++] = x & 16 ? v : w, m[l++] = x & 8 ? v : w, m[l++] = x & 4 ? v : w, m[l++] = x & 2 ? v : w, m[l++] = x & 1 ? v : w;
        for (; E < _; E++)
          k === 0 && (x = h[o++], k = 128), m[l++] = x & k ? v : w, k >>= 1;
      }
      for (; l < y; )
        m[l++] = 0;
      d.putImageData(a, 0, u * pt);
    }
  } else if (t.kind === ue.RGBA_32BPP) {
    for (f = 0, p = s * pt * 4, u = 0; u < n; u++)
      c.set(h.subarray(o, o + p)), o += p, d.putImageData(a, 0, f), f += pt;
    u < r && (p = s * i * 4, c.set(h.subarray(o, o + p)), d.putImageData(a, 0, f));
  } else if (t.kind === ue.RGB_24BPP)
    for (g = pt, p = s * g, u = 0; u < r; u++) {
      for (u >= n && (g = i, p = s * g), l = 0, f = p; f--; )
        c[l++] = h[o++], c[l++] = h[o++], c[l++] = h[o++], c[l++] = 255;
      d.putImageData(a, 0, u * pt);
    }
  else
    throw new Error(`bad image kind: ${t.kind}`);
}
function si(d, t) {
  if (t.bitmap) {
    d.drawImage(t.bitmap, 0, 0);
    return;
  }
  const e = t.height, s = t.width, i = e % pt, n = (e - i) / pt, r = i === 0 ? n : n + 1, a = d.createImageData(s, pt);
  let o = 0;
  const l = t.data, h = a.data;
  for (let c = 0; c < r; c++) {
    const u = c < n ? pt : i;
    ({
      srcPos: o
    } = Nn({
      src: l,
      srcPos: o,
      dest: h,
      width: s,
      height: u,
      nonBlackColor: 0
    })), d.putImageData(a, 0, c * pt);
  }
}
function ae(d, t) {
  const e = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
  for (const s of e)
    d[s] !== void 0 && (t[s] = d[s]);
  d.setLineDash !== void 0 && (t.setLineDash(d.getLineDash()), t.lineDashOffset = d.lineDashOffset);
}
function De(d) {
  d.strokeStyle = d.fillStyle = "#000000", d.fillRule = "nonzero", d.globalAlpha = 1, d.lineWidth = 1, d.lineCap = "butt", d.lineJoin = "miter", d.miterLimit = 10, d.globalCompositeOperation = "source-over", d.font = "10px sans-serif", d.setLineDash !== void 0 && (d.setLineDash([]), d.lineDashOffset = 0);
  const {
    filter: t
  } = d;
  t !== "none" && t !== "" && (d.filter = "none");
}
function ii(d, t) {
  if (t)
    return !0;
  T.singularValueDecompose2dScale(d, yt);
  const e = Math.fround(Et.pixelRatio * Ht.PDF_TO_CSS_UNITS);
  return yt[0] <= e && yt[1] <= e;
}
const Hn = ["butt", "round", "square"], $n = ["miter", "round", "bevel"], jn = {}, ni = {};
class Jt {
  constructor(t, e, s, i, n, {
    optionalContentConfig: r,
    markedContentStack: a = null
  }, o, l, h) {
    this.ctx = t, this.current = new ti(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.res = null, this.xobjs = null, this.commonObjs = e, this.objs = s, this.canvasFactory = i, this.filterFactory = n, this.groupStack = [], this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.smaskCounter = 0, this.tempSMask = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = a || [], this.optionalContentConfig = r, this.cachedCanvases = new Un(this.canvasFactory), this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = o, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = l, this._cachedScaleForStroking = [-1, 0], this._cachedGetSinglePixelWidth = null, this._cachedBitmapsMap = /* @__PURE__ */ new Map(), this.dependencyTracker = h ?? null;
  }
  getObject(t, e, s = null) {
    return typeof e == "string" ? (this.dependencyTracker?.recordNamedDependency(t, e), e.startsWith("g_") ? this.commonObjs.get(e) : this.objs.get(e)) : s;
  }
  beginDrawing({
    transform: t,
    viewport: e,
    transparency: s = !1,
    background: i = null
  }) {
    const n = this.ctx.canvas.width, r = this.ctx.canvas.height, a = this.ctx.fillStyle;
    if (this.ctx.fillStyle = i || "#ffffff", this.ctx.fillRect(0, 0, n, r), this.ctx.fillStyle = a, s) {
      const o = this.cachedCanvases.getCanvas("transparent", n, r);
      this.compositeCtx = this.ctx, this.transparentCanvas = o.canvas, this.ctx = o.context, this.ctx.save(), this.ctx.transform(...q(this.compositeCtx));
    }
    this.ctx.save(), De(this.ctx), t && (this.ctx.transform(...t), this.outputScaleX = t[0], this.outputScaleY = t[0]), this.ctx.transform(...e.transform), this.viewportScale = e.scale, this.baseTransform = q(this.ctx);
  }
  executeOperatorList(t, e, s, i, n) {
    const r = t.argsArray, a = t.fnArray;
    let o = e || 0;
    const l = r.length;
    if (l === o)
      return o;
    const h = l - o > Zs && typeof s == "function", c = h ? Date.now() + On : 0;
    let u = 0;
    const f = this.commonObjs, g = this.objs;
    let p, b;
    for (; ; ) {
      if (i !== void 0 && o === i.nextBreakPoint)
        return i.breakIt(o, s), o;
      if (!n || n(o))
        if (p = a[o], b = r[o] ?? null, p !== te.dependency)
          b === null ? this[p](o) : this[p](o, ...b);
        else
          for (const m of b) {
            this.dependencyTracker?.recordNamedData(m, o);
            const y = m.startsWith("g_") ? f : g;
            if (!y.has(m))
              return y.get(m, s), o;
          }
      if (o++, o === l)
        return o;
      if (h && ++u > Zs) {
        if (Date.now() > c)
          return s(), o;
        u = 0;
      }
    }
  }
  #t() {
    for (; this.stateStack.length || this.inSMaskMode; )
      this.restore();
    this.current.activeSMask = null, this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.transparentCanvas = null);
  }
  endDrawing() {
    this.#t(), this.cachedCanvases.clear(), this.cachedPatterns.clear();
    for (const t of this._cachedBitmapsMap.values()) {
      for (const e of t.values())
        typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement && (e.width = e.height = 0);
      t.clear();
    }
    this._cachedBitmapsMap.clear(), this.#e();
  }
  #e() {
    if (this.pageColors) {
      const t = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
      if (t !== "none") {
        const e = this.ctx.filter;
        this.ctx.filter = t, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = e;
      }
    }
  }
  _scaleImage(t, e) {
    const s = t.width ?? t.displayWidth, i = t.height ?? t.displayHeight;
    let n = Math.max(Math.hypot(e[0], e[1]), 1), r = Math.max(Math.hypot(e[2], e[3]), 1), a = s, o = i, l = "prescale1", h, c;
    for (; n > 2 && a > 1 || r > 2 && o > 1; ) {
      let u = a, f = o;
      n > 2 && a > 1 && (u = a >= 16384 ? Math.floor(a / 2) - 1 || 1 : Math.ceil(a / 2), n /= a / u), r > 2 && o > 1 && (f = o >= 16384 ? Math.floor(o / 2) - 1 || 1 : Math.ceil(o) / 2, r /= o / f), h = this.cachedCanvases.getCanvas(l, u, f), c = h.context, c.clearRect(0, 0, u, f), c.drawImage(t, 0, 0, a, o, 0, 0, u, f), t = h.canvas, a = u, o = f, l = l === "prescale1" ? "prescale2" : "prescale1";
    }
    return {
      img: t,
      paintWidth: a,
      paintHeight: o
    };
  }
  _createMaskCanvas(t, e) {
    const s = this.ctx, {
      width: i,
      height: n
    } = e, r = this.current.fillColor, a = this.current.patternFill, o = q(s);
    let l, h, c, u;
    if ((e.bitmap || e.data) && e.count > 1) {
      const k = e.bitmap || e.data.buffer;
      h = JSON.stringify(a ? o : [o.slice(0, 4), r]), l = this._cachedBitmapsMap.get(k), l || (l = /* @__PURE__ */ new Map(), this._cachedBitmapsMap.set(k, l));
      const x = l.get(h);
      if (x && !a) {
        const z = Math.round(Math.min(o[0], o[2]) + o[4]), W = Math.round(Math.min(o[1], o[3]) + o[5]);
        return this.dependencyTracker?.recordDependencies(t, St.transformAndFill), {
          canvas: x,
          offsetX: z,
          offsetY: W
        };
      }
      c = x;
    }
    c || (u = this.cachedCanvases.getCanvas("maskCanvas", i, n), si(u.context, e));
    let f = T.transform(o, [1 / i, 0, 0, -1 / n, 0, 0]);
    f = T.transform(f, [1, 0, 0, 1, 0, -n]);
    const g = Yt.slice();
    T.axialAlignedBoundingBox([0, 0, i, n], f, g);
    const [p, b, m, y] = g, A = Math.round(m - p) || 1, v = Math.round(y - b) || 1, w = this.cachedCanvases.getCanvas("fillCanvas", A, v), S = w.context, E = p, _ = b;
    S.translate(-E, -_), S.transform(...f), c || (c = this._scaleImage(u.canvas, _t(S)), c = c.img, l && a && l.set(h, c)), S.imageSmoothingEnabled = ii(q(S), e.interpolate), Me(S, c, 0, 0, c.width, c.height, 0, 0, i, n), S.globalCompositeOperation = "source-in";
    const C = T.transform(_t(S), [1, 0, 0, 1, -E, -_]);
    return S.fillStyle = a ? r.getPattern(s, this, C, dt.FILL, t) : r, S.fillRect(0, 0, i, n), l && !a && (this.cachedCanvases.delete("fillCanvas"), l.set(h, w.canvas)), this.dependencyTracker?.recordDependencies(t, St.transformAndFill), {
      canvas: w.canvas,
      offsetX: Math.round(E),
      offsetY: Math.round(_)
    };
  }
  setLineWidth(t, e) {
    this.dependencyTracker?.recordSimpleData("lineWidth", t), e !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = e, this.ctx.lineWidth = e;
  }
  setLineCap(t, e) {
    this.dependencyTracker?.recordSimpleData("lineCap", t), this.ctx.lineCap = Hn[e];
  }
  setLineJoin(t, e) {
    this.dependencyTracker?.recordSimpleData("lineJoin", t), this.ctx.lineJoin = $n[e];
  }
  setMiterLimit(t, e) {
    this.dependencyTracker?.recordSimpleData("miterLimit", t), this.ctx.miterLimit = e;
  }
  setDash(t, e, s) {
    this.dependencyTracker?.recordSimpleData("dash", t);
    const i = this.ctx;
    i.setLineDash !== void 0 && (i.setLineDash(e), i.lineDashOffset = s);
  }
  setRenderingIntent(t, e) {
  }
  setFlatness(t, e) {
  }
  setGState(t, e) {
    for (const [s, i] of e)
      switch (s) {
        case "LW":
          this.setLineWidth(t, i);
          break;
        case "LC":
          this.setLineCap(t, i);
          break;
        case "LJ":
          this.setLineJoin(t, i);
          break;
        case "ML":
          this.setMiterLimit(t, i);
          break;
        case "D":
          this.setDash(t, i[0], i[1]);
          break;
        case "RI":
          this.setRenderingIntent(t, i);
          break;
        case "FL":
          this.setFlatness(t, i);
          break;
        case "Font":
          this.setFont(t, i[0], i[1]);
          break;
        case "CA":
          this.dependencyTracker?.recordSimpleData("strokeAlpha", t), this.current.strokeAlpha = i;
          break;
        case "ca":
          this.dependencyTracker?.recordSimpleData("fillAlpha", t), this.ctx.globalAlpha = this.current.fillAlpha = i;
          break;
        case "BM":
          this.dependencyTracker?.recordSimpleData("globalCompositeOperation", t), this.ctx.globalCompositeOperation = i;
          break;
        case "SMask":
          this.dependencyTracker?.recordSimpleData("SMask", t), this.current.activeSMask = i ? this.tempSMask : null, this.tempSMask = null, this.checkSMaskState();
          break;
        case "TR":
          this.dependencyTracker?.recordSimpleData("filter", t), this.ctx.filter = this.current.transferMaps = this.filterFactory.addFilter(i);
          break;
      }
  }
  get inSMaskMode() {
    return !!this.suspendedCtx;
  }
  checkSMaskState() {
    const t = this.inSMaskMode;
    this.current.activeSMask && !t ? this.beginSMaskMode() : !this.current.activeSMask && t && this.endSMaskMode();
  }
  beginSMaskMode(t) {
    if (this.inSMaskMode)
      throw new Error("beginSMaskMode called while already in smask mode");
    const e = this.ctx.canvas.width, s = this.ctx.canvas.height, i = "smaskGroupAt" + this.groupLevel, n = this.cachedCanvases.getCanvas(i, e, s);
    this.suspendedCtx = this.ctx;
    const r = this.ctx = n.context;
    r.setTransform(this.suspendedCtx.getTransform()), ae(this.suspendedCtx, r), Bn(r, this.suspendedCtx), this.setGState(t, [["BM", "source-over"]]);
  }
  endSMaskMode() {
    if (!this.inSMaskMode)
      throw new Error("endSMaskMode called while not in smask mode");
    this.ctx._removeMirroring(), ae(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null;
  }
  compose(t) {
    if (!this.current.activeSMask)
      return;
    t ? (t[0] = Math.floor(t[0]), t[1] = Math.floor(t[1]), t[2] = Math.ceil(t[2]), t[3] = Math.ceil(t[3])) : t = [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
    const e = this.current.activeSMask, s = this.suspendedCtx;
    this.composeSMask(s, e, this.ctx, t), this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore();
  }
  composeSMask(t, e, s, i) {
    const n = i[0], r = i[1], a = i[2] - n, o = i[3] - r;
    a === 0 || o === 0 || (this.genericComposeSMask(e.context, s, a, o, e.subtype, e.backdrop, e.transferMap, n, r, e.offsetX, e.offsetY), t.save(), t.globalAlpha = 1, t.globalCompositeOperation = "source-over", t.setTransform(1, 0, 0, 1, 0, 0), t.drawImage(s.canvas, 0, 0), t.restore());
  }
  genericComposeSMask(t, e, s, i, n, r, a, o, l, h, c) {
    let u = t.canvas, f = o - h, g = l - c;
    if (r)
      if (f < 0 || g < 0 || f + s > u.width || g + i > u.height) {
        const b = this.cachedCanvases.getCanvas("maskExtension", s, i), m = b.context;
        m.drawImage(u, -f, -g), m.globalCompositeOperation = "destination-atop", m.fillStyle = r, m.fillRect(0, 0, s, i), m.globalCompositeOperation = "source-over", u = b.canvas, f = g = 0;
      } else {
        t.save(), t.globalAlpha = 1, t.setTransform(1, 0, 0, 1, 0, 0);
        const b = new Path2D();
        b.rect(f, g, s, i), t.clip(b), t.globalCompositeOperation = "destination-atop", t.fillStyle = r, t.fillRect(f, g, s, i), t.restore();
      }
    e.save(), e.globalAlpha = 1, e.setTransform(1, 0, 0, 1, 0, 0), n === "Alpha" && a ? e.filter = this.filterFactory.addAlphaFilter(a) : n === "Luminosity" && (e.filter = this.filterFactory.addLuminosityFilter(a));
    const p = new Path2D();
    p.rect(o, l, s, i), e.clip(p), e.globalCompositeOperation = "destination-in", e.drawImage(u, f, g, s, i, o, l, s, i), e.restore();
  }
  save(t) {
    this.inSMaskMode && ae(this.ctx, this.suspendedCtx), this.ctx.save();
    const e = this.current;
    this.stateStack.push(e), this.current = e.clone(), this.dependencyTracker?.save(t);
  }
  restore(t) {
    if (this.dependencyTracker?.restore(t), this.stateStack.length === 0) {
      this.inSMaskMode && this.endSMaskMode();
      return;
    }
    this.current = this.stateStack.pop(), this.ctx.restore(), this.inSMaskMode && ae(this.suspendedCtx, this.ctx), this.checkSMaskState(), this.pendingClip = null, this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
  }
  transform(t, e, s, i, n, r, a) {
    this.dependencyTracker?.recordIncrementalData("transform", t), this.ctx.transform(e, s, i, n, r, a), this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
  }
  constructPath(t, e, s, i) {
    let [n] = s;
    if (!i) {
      n ||= s[0] = new Path2D(), this[e](t, n);
      return;
    }
    if (this.dependencyTracker !== null) {
      const r = e === te.stroke ? this.current.lineWidth / 2 : 0;
      this.dependencyTracker.resetBBox(t).recordBBox(t, this.ctx, i[0] - r, i[2] + r, i[1] - r, i[3] + r).recordDependencies(t, ["transform"]);
    }
    n instanceof Path2D || (n = s[0] = yi(n)), T.axialAlignedBoundingBox(i, q(this.ctx), this.current.minMax), this[e](t, n), this._pathStartIdx = t;
  }
  closePath(t) {
    this.ctx.closePath();
  }
  stroke(t, e, s = !0) {
    const i = this.ctx, n = this.current.strokeColor;
    if (i.globalAlpha = this.current.strokeAlpha, this.contentVisible)
      if (typeof n == "object" && n?.getPattern) {
        const r = n.isModifyingCurrentTransform() ? i.getTransform() : null;
        if (i.save(), i.strokeStyle = n.getPattern(i, this, _t(i), dt.STROKE, t), r) {
          const a = new Path2D();
          a.addPath(e, i.getTransform().invertSelf().multiplySelf(r)), e = a;
        }
        this.rescaleAndStroke(e, !1), i.restore();
      } else
        this.rescaleAndStroke(e, !0);
    this.dependencyTracker?.recordDependencies(t, St.stroke), s && this.consumePath(t, e, this.current.getClippedPathBoundingBox(dt.STROKE, q(this.ctx))), i.globalAlpha = this.current.fillAlpha;
  }
  closeStroke(t, e) {
    this.stroke(t, e);
  }
  fill(t, e, s = !0) {
    const i = this.ctx, n = this.current.fillColor, r = this.current.patternFill;
    let a = !1;
    if (r) {
      const l = n.isModifyingCurrentTransform() ? i.getTransform() : null;
      if (this.dependencyTracker?.save(t), i.save(), i.fillStyle = n.getPattern(i, this, _t(i), dt.FILL, t), l) {
        const h = new Path2D();
        h.addPath(e, i.getTransform().invertSelf().multiplySelf(l)), e = h;
      }
      a = !0;
    }
    const o = this.current.getClippedPathBoundingBox();
    this.contentVisible && o !== null && (this.pendingEOFill ? (i.fill(e, "evenodd"), this.pendingEOFill = !1) : i.fill(e)), this.dependencyTracker?.recordDependencies(t, St.fill), a && (i.restore(), this.dependencyTracker?.restore(t)), s && this.consumePath(t, e, o);
  }
  eoFill(t, e) {
    this.pendingEOFill = !0, this.fill(t, e);
  }
  fillStroke(t, e) {
    this.fill(t, e, !1), this.stroke(t, e, !1), this.consumePath(t, e);
  }
  eoFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  closeFillStroke(t, e) {
    this.fillStroke(t, e);
  }
  closeEOFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  endPath(t, e) {
    this.consumePath(t, e);
  }
  rawFillPath(t, e) {
    this.ctx.fill(e), this.dependencyTracker?.recordDependencies(t, St.rawFillPath).recordOperation(t);
  }
  clip(t) {
    this.dependencyTracker?.recordFutureForcedDependency("clipMode", t), this.pendingClip = jn;
  }
  eoClip(t) {
    this.dependencyTracker?.recordFutureForcedDependency("clipMode", t), this.pendingClip = ni;
  }
  beginText(t) {
    this.current.textMatrix = null, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0, this.dependencyTracker?.recordOpenMarker(t).resetIncrementalData("sameLineText").resetIncrementalData("moveText", t);
  }
  endText(t) {
    const e = this.pendingTextPaths, s = this.ctx;
    if (this.dependencyTracker) {
      const {
        dependencyTracker: i
      } = this;
      e !== void 0 && i.recordFutureForcedDependency("textClip", i.getOpenMarker()).recordFutureForcedDependency("textClip", t), i.recordCloseMarker(t);
    }
    if (e !== void 0) {
      const i = new Path2D(), n = s.getTransform().invertSelf();
      for (const {
        transform: r,
        x: a,
        y: o,
        fontSize: l,
        path: h
      } of e)
        h && i.addPath(h, new DOMMatrix(r).preMultiplySelf(n).translate(a, o).scale(l, -l));
      s.clip(i);
    }
    delete this.pendingTextPaths;
  }
  setCharSpacing(t, e) {
    this.dependencyTracker?.recordSimpleData("charSpacing", t), this.current.charSpacing = e;
  }
  setWordSpacing(t, e) {
    this.dependencyTracker?.recordSimpleData("wordSpacing", t), this.current.wordSpacing = e;
  }
  setHScale(t, e) {
    this.dependencyTracker?.recordSimpleData("hScale", t), this.current.textHScale = e / 100;
  }
  setLeading(t, e) {
    this.dependencyTracker?.recordSimpleData("leading", t), this.current.leading = -e;
  }
  setFont(t, e, s) {
    this.dependencyTracker?.recordSimpleData("font", t).recordSimpleDataFromNamed("fontObj", e, t);
    const i = this.commonObjs.get(e), n = this.current;
    if (!i)
      throw new Error(`Can't find font for ${e}`);
    if (n.fontMatrix = i.fontMatrix || as, (n.fontMatrix[0] === 0 || n.fontMatrix[3] === 0) && R("Invalid font matrix for font " + e), s < 0 ? (s = -s, n.fontDirection = -1) : n.fontDirection = 1, this.current.font = i, this.current.fontSize = s, i.isType3Font)
      return;
    const r = i.loadedName || "sans-serif", a = i.systemFontInfo?.css || `"${r}", ${i.fallbackName}`;
    let o = "normal";
    i.black ? o = "900" : i.bold && (o = "bold");
    const l = i.italic ? "italic" : "normal";
    let h = s;
    s < Qs ? h = Qs : s > Js && (h = Js), this.current.fontSizeScale = s / h, this.ctx.font = `${l} ${o} ${h}px ${a}`;
  }
  setTextRenderingMode(t, e) {
    this.dependencyTracker?.recordSimpleData("textRenderingMode", t), this.current.textRenderingMode = e;
  }
  setTextRise(t, e) {
    this.dependencyTracker?.recordSimpleData("textRise", t), this.current.textRise = e;
  }
  moveText(t, e, s) {
    this.dependencyTracker?.resetIncrementalData("sameLineText").recordIncrementalData("moveText", t), this.current.x = this.current.lineX += e, this.current.y = this.current.lineY += s;
  }
  setLeadingMoveText(t, e, s) {
    this.setLeading(t, -s), this.moveText(t, e, s);
  }
  setTextMatrix(t, e) {
    this.dependencyTracker?.resetIncrementalData("sameLineText").recordSimpleData("textMatrix", t);
    const {
      current: s
    } = this;
    s.textMatrix = e, s.textMatrixScale = Math.hypot(e[0], e[1]), s.x = s.lineX = 0, s.y = s.lineY = 0;
  }
  nextLine(t) {
    this.moveText(t, 0, this.current.leading), this.dependencyTracker?.recordIncrementalData("moveText", this.dependencyTracker.getSimpleIndex("leading") ?? t);
  }
  #i(t, e, s) {
    const i = new Path2D();
    return i.addPath(t, new DOMMatrix(s).invertSelf().multiplySelf(e)), i;
  }
  paintChar(t, e, s, i, n, r) {
    const a = this.ctx, o = this.current, l = o.font, h = o.textRenderingMode, c = o.fontSize / o.fontSizeScale, u = h & rt.FILL_STROKE_MASK, f = !!(h & rt.ADD_TO_PATH_FLAG), g = o.patternFill && !l.missingFile, p = o.patternStroke && !l.missingFile;
    let b;
    if ((l.disableFontFace || f || g || p) && !l.missingFile && (b = l.getPathGenerator(this.commonObjs, e)), b && (l.disableFontFace || g || p)) {
      a.save(), a.translate(s, i), a.scale(c, -c), this.dependencyTracker?.recordCharacterBBox(t, a, l);
      let m;
      if (u === rt.FILL || u === rt.FILL_STROKE)
        if (n) {
          m = a.getTransform(), a.setTransform(...n);
          const y = this.#i(b, m, n);
          a.fill(y);
        } else
          a.fill(b);
      if (u === rt.STROKE || u === rt.FILL_STROKE)
        if (r) {
          m ||= a.getTransform(), a.setTransform(...r);
          const {
            a: y,
            b: A,
            c: v,
            d: w
          } = m, S = T.inverseTransform(r), E = T.transform([y, A, v, w, 0, 0], S);
          T.singularValueDecompose2dScale(E, yt), a.lineWidth *= Math.max(yt[0], yt[1]) / c, a.stroke(this.#i(b, m, r));
        } else
          a.lineWidth /= c, a.stroke(b);
      a.restore();
    } else
      (u === rt.FILL || u === rt.FILL_STROKE) && (a.fillText(e, s, i), this.dependencyTracker?.recordCharacterBBox(t, a, l, c, s, i, () => a.measureText(e))), (u === rt.STROKE || u === rt.FILL_STROKE) && (this.dependencyTracker && this.dependencyTracker?.recordCharacterBBox(t, a, l, c, s, i, () => a.measureText(e)).recordDependencies(t, St.stroke), a.strokeText(e, s, i));
    f && ((this.pendingTextPaths ||= []).push({
      transform: q(a),
      x: s,
      y: i,
      fontSize: c,
      path: b
    }), this.dependencyTracker?.recordCharacterBBox(t, a, l, c, s, i));
  }
  get isFontSubpixelAAEnabled() {
    const {
      context: t
    } = this.cachedCanvases.getCanvas("isFontSubpixelAAEnabled", 10, 10);
    t.scale(1.5, 1), t.fillText("I", 0, 10);
    const e = t.getImageData(0, 0, 10, 10).data;
    let s = !1;
    for (let i = 3; i < e.length; i += 4)
      if (e[i] > 0 && e[i] < 255) {
        s = !0;
        break;
      }
    return I(this, "isFontSubpixelAAEnabled", s);
  }
  showText(t, e) {
    this.dependencyTracker && (this.dependencyTracker.recordDependencies(t, St.showText).resetBBox(t), this.current.textRenderingMode & rt.ADD_TO_PATH_FLAG && this.dependencyTracker.recordFutureForcedDependency("textClip", t).inheritPendingDependenciesAsFutureForcedDependencies());
    const s = this.current, i = s.font;
    if (i.isType3Font) {
      this.showType3Text(t, e), this.dependencyTracker?.recordShowTextOperation(t);
      return;
    }
    const n = s.fontSize;
    if (n === 0) {
      this.dependencyTracker?.recordOperation(t);
      return;
    }
    const r = this.ctx, a = s.fontSizeScale, o = s.charSpacing, l = s.wordSpacing, h = s.fontDirection, c = s.textHScale * h, u = e.length, f = i.vertical, g = f ? 1 : -1, p = i.defaultVMetrics, b = n * s.fontMatrix[0], m = s.textRenderingMode === rt.FILL && !i.disableFontFace && !s.patternFill;
    r.save(), s.textMatrix && r.transform(...s.textMatrix), r.translate(s.x, s.y + s.textRise), h > 0 ? r.scale(c, -1) : r.scale(c, 1);
    let y, A;
    const v = s.textRenderingMode & rt.FILL_STROKE_MASK, w = v === rt.FILL || v === rt.FILL_STROKE, S = v === rt.STROKE || v === rt.FILL_STROKE;
    if (w && s.patternFill) {
      r.save();
      const x = s.fillColor.getPattern(r, this, _t(r), dt.FILL, t);
      y = q(r), r.restore(), r.fillStyle = x;
    }
    if (S && s.patternStroke) {
      r.save();
      const x = s.strokeColor.getPattern(r, this, _t(r), dt.STROKE, t);
      A = q(r), r.restore(), r.strokeStyle = x;
    }
    let E = s.lineWidth;
    const _ = s.textMatrixScale;
    if (_ === 0 || E === 0 ? S && (E = this.getSinglePixelWidth()) : E /= _, a !== 1 && (r.scale(a, a), E /= a), r.lineWidth = E, i.isInvalidPDFjsFont) {
      const x = [];
      let z = 0;
      for (const O of e)
        x.push(O.unicode), z += O.width;
      const W = x.join("");
      if (r.fillText(W, 0, 0), this.dependencyTracker !== null) {
        const O = r.measureText(W);
        this.dependencyTracker.recordBBox(t, this.ctx, -O.actualBoundingBoxLeft, O.actualBoundingBoxRight, -O.actualBoundingBoxAscent, O.actualBoundingBoxDescent).recordShowTextOperation(t);
      }
      s.x += z * b * c, r.restore(), this.compose();
      return;
    }
    let C = 0, k;
    for (k = 0; k < u; ++k) {
      const x = e[k];
      if (typeof x == "number") {
        C += g * x * n / 1e3;
        continue;
      }
      let z = !1;
      const W = (x.isSpace ? l : 0) + o, O = x.fontChar, tt = x.accent;
      let M, L, G = x.width;
      if (f) {
        const et = x.vmetric || p, X = -(x.vmetric ? et[1] : G * 0.5) * b, Y = et[2] * b;
        G = et ? -et[0] : G, M = X / a, L = (C + Y) / a;
      } else
        M = C / a, L = 0;
      let mt;
      if (i.remeasure && G > 0) {
        mt = r.measureText(O);
        const et = mt.width * 1e3 / n * a;
        if (G < et && this.isFontSubpixelAAEnabled) {
          const X = G / et;
          z = !0, r.save(), r.scale(X, 1), M /= X;
        } else G !== et && (M += (G - et) / 2e3 * n / a);
      }
      if (this.contentVisible && (x.isInFont || i.missingFile)) {
        if (m && !tt)
          r.fillText(O, M, L), this.dependencyTracker?.recordCharacterBBox(t, r, mt ? {
            bbox: null
          } : i, n / a, M, L, () => mt ?? r.measureText(O));
        else if (this.paintChar(t, O, M, L, y, A), tt) {
          const et = M + n * tt.offset.x / a, X = L - n * tt.offset.y / a;
          this.paintChar(t, tt.fontChar, et, X, y, A);
        }
      }
      const kt = f ? G * b - W * h : G * b + W * h;
      C += kt, z && r.restore();
    }
    f ? s.y -= C : s.x += C * c, r.restore(), this.compose(), this.dependencyTracker?.recordShowTextOperation(t);
  }
  showType3Text(t, e) {
    const s = this.ctx, i = this.current, n = i.font, r = i.fontSize, a = i.fontDirection, o = n.vertical ? 1 : -1, l = i.charSpacing, h = i.wordSpacing, c = i.textHScale * a, u = i.fontMatrix || as, f = e.length, g = i.textRenderingMode === rt.INVISIBLE;
    let p, b, m, y;
    if (g || r === 0)
      return;
    this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null, s.save(), i.textMatrix && s.transform(...i.textMatrix), s.translate(i.x, i.y + i.textRise), s.scale(c, a);
    const A = this.dependencyTracker;
    for (this.dependencyTracker = A ? new Oe(A, t) : null, p = 0; p < f; ++p) {
      if (b = e[p], typeof b == "number") {
        y = o * b * r / 1e3, this.ctx.translate(y, 0), i.x += y * c;
        continue;
      }
      const v = (b.isSpace ? h : 0) + l, w = n.charProcOperatorList[b.operatorListId];
      w ? this.contentVisible && (this.save(), s.scale(r, r), s.transform(...u), this.executeOperatorList(w), this.restore()) : R(`Type3 character "${b.operatorListId}" is not available.`);
      const S = [b.width, 0];
      T.applyTransform(S, u), m = S[0] * r + v, s.translate(m, 0), i.x += m * c;
    }
    s.restore(), A && (this.dependencyTracker = A);
  }
  setCharWidth(t, e, s) {
  }
  setCharWidthAndBounds(t, e, s, i, n, r, a) {
    const o = new Path2D();
    o.rect(i, n, r - i, a - n), this.ctx.clip(o), this.dependencyTracker?.recordBBox(t, this.ctx, i, r, n, a).recordClipBox(t, this.ctx, i, r, n, a), this.endPath(t);
  }
  getColorN_Pattern(t, e) {
    let s;
    if (e[0] === "TilingPattern") {
      const i = this.baseTransform || q(this.ctx), n = {
        createCanvasGraphics: (r, a) => new Jt(r, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
          optionalContentConfig: this.optionalContentConfig,
          markedContentStack: this.markedContentStack
        }, void 0, void 0, this.dependencyTracker ? new Oe(this.dependencyTracker, a, !0) : null)
      };
      s = new xs(e, this.ctx, n, i);
    } else
      s = this._getPattern(t, e[1], e[2]);
    return s;
  }
  setStrokeColorN(t, ...e) {
    this.dependencyTracker?.recordSimpleData("strokeColor", t), this.current.strokeColor = this.getColorN_Pattern(t, e), this.current.patternStroke = !0;
  }
  setFillColorN(t, ...e) {
    this.dependencyTracker?.recordSimpleData("fillColor", t), this.current.fillColor = this.getColorN_Pattern(t, e), this.current.patternFill = !0;
  }
  setStrokeRGBColor(t, e) {
    this.dependencyTracker?.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = e, this.current.patternStroke = !1;
  }
  setStrokeTransparent(t) {
    this.dependencyTracker?.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = "transparent", this.current.patternStroke = !1;
  }
  setFillRGBColor(t, e) {
    this.dependencyTracker?.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = e, this.current.patternFill = !1;
  }
  setFillTransparent(t) {
    this.dependencyTracker?.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = "transparent", this.current.patternFill = !1;
  }
  _getPattern(t, e, s = null) {
    let i;
    return this.cachedPatterns.has(e) ? i = this.cachedPatterns.get(e) : (i = Fn(this.getObject(t, e)), this.cachedPatterns.set(e, i)), s && (i.matrix = s), i;
  }
  shadingFill(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.ctx;
    this.save(t);
    const i = this._getPattern(t, e);
    s.fillStyle = i.getPattern(s, this, _t(s), dt.SHADING, t);
    const n = _t(s);
    if (n) {
      const {
        width: r,
        height: a
      } = s.canvas, o = Yt.slice();
      T.axialAlignedBoundingBox([0, 0, r, a], n, o);
      const [l, h, c, u] = o;
      this.ctx.fillRect(l, h, c - l, u - h);
    } else
      this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
    this.dependencyTracker?.resetBBox(t).recordFullPageBBox(t).recordDependencies(t, St.transform).recordDependencies(t, St.fill).recordOperation(t), this.compose(this.current.getClippedPathBoundingBox()), this.restore(t);
  }
  beginInlineImage() {
    j("Should not call beginInlineImage");
  }
  beginImageData() {
    j("Should not call beginImageData");
  }
  paintFormXObjectBegin(t, e, s) {
    if (this.contentVisible && (this.save(t), this.baseTransformStack.push(this.baseTransform), e && this.transform(t, ...e), this.baseTransform = q(this.ctx), s)) {
      T.axialAlignedBoundingBox(s, this.baseTransform, this.current.minMax);
      const [i, n, r, a] = s, o = new Path2D();
      o.rect(i, n, r - i, a - n), this.ctx.clip(o), this.dependencyTracker?.recordClipBox(t, this.ctx, i, r, n, a), this.endPath(t);
    }
  }
  paintFormXObjectEnd(t) {
    this.contentVisible && (this.restore(t), this.baseTransform = this.baseTransformStack.pop());
  }
  beginGroup(t, e) {
    if (!this.contentVisible)
      return;
    this.save(t), this.inSMaskMode && (this.endSMaskMode(), this.current.activeSMask = null);
    const s = this.ctx;
    e.isolated || Ue("TODO: Support non-isolated groups."), e.knockout && R("Knockout groups not supported.");
    const i = q(s);
    if (e.matrix && s.transform(...e.matrix), !e.bbox)
      throw new Error("Bounding box is required.");
    let n = Yt.slice();
    T.axialAlignedBoundingBox(e.bbox, q(s), n);
    const r = [0, 0, s.canvas.width, s.canvas.height];
    n = T.intersect(n, r) || [0, 0, 0, 0];
    const a = Math.floor(n[0]), o = Math.floor(n[1]), l = Math.max(Math.ceil(n[2]) - a, 1), h = Math.max(Math.ceil(n[3]) - o, 1);
    this.current.startNewPathAndClipBox([0, 0, l, h]);
    let c = "groupAt" + this.groupLevel;
    e.smask && (c += "_smask_" + this.smaskCounter++ % 2);
    const u = this.cachedCanvases.getCanvas(c, l, h), f = u.context;
    f.translate(-a, -o), f.transform(...i);
    let g = new Path2D();
    const [p, b, m, y] = e.bbox;
    if (g.rect(p, b, m - p, y - b), e.matrix) {
      const A = new Path2D();
      A.addPath(g, new DOMMatrix(e.matrix)), g = A;
    }
    f.clip(g), e.smask && this.smaskStack.push({
      canvas: u.canvas,
      context: f,
      offsetX: a,
      offsetY: o,
      subtype: e.smask.subtype,
      backdrop: e.smask.backdrop,
      transferMap: e.smask.transferMap || null,
      startTransformInverse: null
    }), (!e.smask || this.dependencyTracker) && (s.setTransform(1, 0, 0, 1, 0, 0), s.translate(a, o), s.save()), ae(s, f), this.ctx = f, this.dependencyTracker?.inheritSimpleDataAsFutureForcedDependencies(["fillAlpha", "strokeAlpha", "globalCompositeOperation"]).pushBaseTransform(s), this.setGState(t, [["BM", "source-over"], ["ca", 1], ["CA", 1]]), this.groupStack.push(s), this.groupLevel++;
  }
  endGroup(t, e) {
    if (!this.contentVisible)
      return;
    this.groupLevel--;
    const s = this.ctx, i = this.groupStack.pop();
    if (this.ctx = i, this.ctx.imageSmoothingEnabled = !1, this.dependencyTracker?.popBaseTransform(), e.smask)
      this.tempSMask = this.smaskStack.pop(), this.restore(t), this.dependencyTracker && this.ctx.restore();
    else {
      this.ctx.restore();
      const n = q(this.ctx);
      this.restore(t), this.ctx.save(), this.ctx.setTransform(...n);
      const r = Yt.slice();
      T.axialAlignedBoundingBox([0, 0, s.canvas.width, s.canvas.height], n, r), this.ctx.drawImage(s.canvas, 0, 0), this.ctx.restore(), this.compose(r);
    }
  }
  beginAnnotation(t, e, s, i, n, r) {
    if (this.#t(), De(this.ctx), this.ctx.save(), this.save(t), this.baseTransform && this.ctx.setTransform(...this.baseTransform), s) {
      const a = s[2] - s[0], o = s[3] - s[1];
      if (r && this.annotationCanvasMap) {
        i = i.slice(), i[4] -= s[0], i[5] -= s[1], s = s.slice(), s[0] = s[1] = 0, s[2] = a, s[3] = o, T.singularValueDecompose2dScale(q(this.ctx), yt);
        const {
          viewportScale: l
        } = this, h = Math.ceil(a * this.outputScaleX * l), c = Math.ceil(o * this.outputScaleY * l);
        this.annotationCanvas = this.canvasFactory.create(h, c);
        const {
          canvas: u,
          context: f
        } = this.annotationCanvas;
        this.annotationCanvasMap.set(e, u), this.annotationCanvas.savedCtx = this.ctx, this.ctx = f, this.ctx.save(), this.ctx.setTransform(yt[0], 0, 0, -yt[1], 0, o * yt[1]), De(this.ctx);
      } else {
        De(this.ctx), this.endPath(t);
        const l = new Path2D();
        l.rect(s[0], s[1], a, o), this.ctx.clip(l);
      }
    }
    this.current = new ti(this.ctx.canvas.width, this.ctx.canvas.height), this.transform(t, ...i), this.transform(t, ...n);
  }
  endAnnotation(t) {
    this.annotationCanvas && (this.ctx.restore(), this.#e(), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas);
  }
  paintImageMaskXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = e.count;
    e = this.getObject(t, e.data, e), e.count = s;
    const i = this.ctx, n = this._createMaskCanvas(t, e), r = n.canvas;
    i.save(), i.setTransform(1, 0, 0, 1, 0, 0), i.drawImage(r, n.offsetX, n.offsetY), this.dependencyTracker?.resetBBox(t).recordBBox(t, this.ctx, n.offsetX, n.offsetX + r.width, n.offsetY, n.offsetY + r.height).recordOperation(t), i.restore(), this.compose();
  }
  paintImageMaskXObjectRepeat(t, e, s, i = 0, n = 0, r, a) {
    if (!this.contentVisible)
      return;
    e = this.getObject(t, e.data, e);
    const o = this.ctx;
    o.save();
    const l = q(o);
    o.transform(s, i, n, r, 0, 0);
    const h = this._createMaskCanvas(t, e);
    o.setTransform(1, 0, 0, 1, h.offsetX - l[4], h.offsetY - l[5]), this.dependencyTracker?.resetBBox(t);
    for (let c = 0, u = a.length; c < u; c += 2) {
      const f = T.transform(l, [s, i, n, r, a[c], a[c + 1]]);
      o.drawImage(h.canvas, f[4], f[5]), this.dependencyTracker?.recordBBox(t, this.ctx, f[4], f[4] + h.canvas.width, f[5], f[5] + h.canvas.height);
    }
    o.restore(), this.compose(), this.dependencyTracker?.recordOperation(t);
  }
  paintImageMaskXObjectGroup(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.ctx, i = this.current.fillColor, n = this.current.patternFill;
    this.dependencyTracker?.resetBBox(t).recordDependencies(t, St.transformAndFill);
    for (const r of e) {
      const {
        data: a,
        width: o,
        height: l,
        transform: h
      } = r, c = this.cachedCanvases.getCanvas("maskCanvas", o, l), u = c.context;
      u.save();
      const f = this.getObject(t, a, r);
      si(u, f), u.globalCompositeOperation = "source-in", u.fillStyle = n ? i.getPattern(u, this, _t(s), dt.FILL, t) : i, u.fillRect(0, 0, o, l), u.restore(), s.save(), s.transform(...h), s.scale(1, -1), Me(s, c.canvas, 0, 0, o, l, 0, -1, 1, 1), this.dependencyTracker?.recordBBox(t, s, 0, o, 0, l), s.restore();
    }
    this.compose(), this.dependencyTracker?.recordOperation(t);
  }
  paintImageXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.getObject(t, e);
    if (!s) {
      R("Dependent image isn't ready yet");
      return;
    }
    this.paintInlineImageXObject(t, s);
  }
  paintImageXObjectRepeat(t, e, s, i, n) {
    if (!this.contentVisible)
      return;
    const r = this.getObject(t, e);
    if (!r) {
      R("Dependent image isn't ready yet");
      return;
    }
    const a = r.width, o = r.height, l = [];
    for (let h = 0, c = n.length; h < c; h += 2)
      l.push({
        transform: [s, 0, 0, i, n[h], n[h + 1]],
        x: 0,
        y: 0,
        w: a,
        h: o
      });
    this.paintInlineImageXObjectGroup(t, r, l);
  }
  applyTransferMapsToCanvas(t) {
    return this.current.transferMaps !== "none" && (t.filter = this.current.transferMaps, t.drawImage(t.canvas, 0, 0), t.filter = "none"), t.canvas;
  }
  applyTransferMapsToBitmap(t) {
    if (this.current.transferMaps === "none")
      return t.bitmap;
    const {
      bitmap: e,
      width: s,
      height: i
    } = t, n = this.cachedCanvases.getCanvas("inlineImage", s, i), r = n.context;
    return r.filter = this.current.transferMaps, r.drawImage(e, 0, 0), r.filter = "none", n.canvas;
  }
  paintInlineImageXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = e.width, i = e.height, n = this.ctx;
    this.save(t);
    const {
      filter: r
    } = n;
    r !== "none" && r !== "" && (n.filter = "none"), n.scale(1 / s, -1 / i);
    let a;
    if (e.bitmap)
      a = this.applyTransferMapsToBitmap(e);
    else if (typeof HTMLElement == "function" && e instanceof HTMLElement || !e.data)
      a = e;
    else {
      const h = this.cachedCanvases.getCanvas("inlineImage", s, i).context;
      ei(h, e), a = this.applyTransferMapsToCanvas(h);
    }
    const o = this._scaleImage(a, _t(n));
    n.imageSmoothingEnabled = ii(q(n), e.interpolate), this.dependencyTracker?.resetBBox(t).recordBBox(t, n, 0, s, -i, 0).recordDependencies(t, St.imageXObject).recordOperation(t), Me(n, o.img, 0, 0, o.paintWidth, o.paintHeight, 0, -i, s, i), this.compose(), this.restore(t);
  }
  paintInlineImageXObjectGroup(t, e, s) {
    if (!this.contentVisible)
      return;
    const i = this.ctx;
    let n;
    if (e.bitmap)
      n = e.bitmap;
    else {
      const r = e.width, a = e.height, l = this.cachedCanvases.getCanvas("inlineImage", r, a).context;
      ei(l, e), n = this.applyTransferMapsToCanvas(l);
    }
    this.dependencyTracker?.resetBBox(t);
    for (const r of s)
      i.save(), i.transform(...r.transform), i.scale(1, -1), Me(i, n, r.x, r.y, r.w, r.h, 0, -1, 1, 1), this.dependencyTracker?.recordBBox(t, i, 0, 1, -1, 0), i.restore();
    this.dependencyTracker?.recordOperation(t), this.compose();
  }
  paintSolidColorImageMask(t) {
    this.contentVisible && (this.dependencyTracker?.resetBBox(t).recordBBox(t, this.ctx, 0, 1, 0, 1).recordDependencies(t, St.fill).recordOperation(t), this.ctx.fillRect(0, 0, 1, 1), this.compose());
  }
  markPoint(t, e) {
  }
  markPointProps(t, e, s) {
  }
  beginMarkedContent(t, e) {
    this.dependencyTracker?.beginMarkedContent(t), this.markedContentStack.push({
      visible: !0
    });
  }
  beginMarkedContentProps(t, e, s) {
    this.dependencyTracker?.beginMarkedContent(t), e === "OC" ? this.markedContentStack.push({
      visible: this.optionalContentConfig.isVisible(s)
    }) : this.markedContentStack.push({
      visible: !0
    }), this.contentVisible = this.isContentVisible();
  }
  endMarkedContent(t) {
    this.dependencyTracker?.endMarkedContent(t), this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
  }
  beginCompat(t) {
  }
  endCompat(t) {
  }
  consumePath(t, e, s) {
    const i = this.current.isEmptyClip();
    this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(s);
    const n = this.ctx;
    this.pendingClip ? (i || (this.pendingClip === ni ? n.clip(e, "evenodd") : n.clip(e)), this.pendingClip = null, this.dependencyTracker?.bboxToClipBoxDropOperation(t).recordFutureForcedDependency("clipPath", t)) : this.dependencyTracker?.recordOperation(t), this.current.startNewPathAndClipBox(this.current.clipBox);
  }
  getSinglePixelWidth() {
    if (!this._cachedGetSinglePixelWidth) {
      const t = q(this.ctx);
      if (t[1] === 0 && t[2] === 0)
        this._cachedGetSinglePixelWidth = 1 / Math.min(Math.abs(t[0]), Math.abs(t[3]));
      else {
        const e = Math.abs(t[0] * t[3] - t[2] * t[1]), s = Math.hypot(t[0], t[2]), i = Math.hypot(t[1], t[3]);
        this._cachedGetSinglePixelWidth = Math.max(s, i) / e;
      }
    }
    return this._cachedGetSinglePixelWidth;
  }
  getScaleForStroking() {
    if (this._cachedScaleForStroking[0] === -1) {
      const {
        lineWidth: t
      } = this.current, {
        a: e,
        b: s,
        c: i,
        d: n
      } = this.ctx.getTransform();
      let r, a;
      if (s === 0 && i === 0) {
        const o = Math.abs(e), l = Math.abs(n);
        if (o === l)
          if (t === 0)
            r = a = 1 / o;
          else {
            const h = o * t;
            r = a = h < 1 ? 1 / h : 1;
          }
        else if (t === 0)
          r = 1 / o, a = 1 / l;
        else {
          const h = o * t, c = l * t;
          r = h < 1 ? 1 / h : 1, a = c < 1 ? 1 / c : 1;
        }
      } else {
        const o = Math.abs(e * n - s * i), l = Math.hypot(e, s), h = Math.hypot(i, n);
        if (t === 0)
          r = h / o, a = l / o;
        else {
          const c = t * o;
          r = h > c ? h / c : 1, a = l > c ? l / c : 1;
        }
      }
      this._cachedScaleForStroking[0] = r, this._cachedScaleForStroking[1] = a;
    }
    return this._cachedScaleForStroking;
  }
  rescaleAndStroke(t, e) {
    const {
      ctx: s,
      current: {
        lineWidth: i
      }
    } = this, [n, r] = this.getScaleForStroking();
    if (n === r) {
      s.lineWidth = (i || 1) * n, s.stroke(t);
      return;
    }
    const a = s.getLineDash();
    e && s.save(), s.scale(n, r), is.a = 1 / n, is.d = 1 / r;
    const o = new Path2D();
    if (o.addPath(t, is), a.length > 0) {
      const l = Math.max(n, r);
      s.setLineDash(a.map((h) => h / l)), s.lineDashOffset /= l;
    }
    s.lineWidth = i || 1, s.stroke(o), e && s.restore();
  }
  isContentVisible() {
    for (let t = this.markedContentStack.length - 1; t >= 0; t--)
      if (!this.markedContentStack[t].visible)
        return !1;
    return !0;
  }
}
for (const d in te)
  Jt.prototype[d] !== void 0 && (Jt.prototype[te[d]] = Jt.prototype[d]);
class Zt {
  static #t = null;
  static #e = "";
  static get workerPort() {
    return this.#t;
  }
  static set workerPort(t) {
    if (!(typeof Worker < "u" && t instanceof Worker) && t !== null)
      throw new Error("Invalid `workerPort` type.");
    this.#t = t;
  }
  static get workerSrc() {
    return this.#e;
  }
  static set workerSrc(t) {
    if (typeof t != "string")
      throw new Error("Invalid `workerSrc` type.");
    this.#e = t;
  }
}
class zn {
  #t;
  #e;
  constructor({
    parsedData: t,
    rawData: e
  }) {
    this.#t = t, this.#e = e;
  }
  getRaw() {
    return this.#e;
  }
  get(t) {
    return this.#t.get(t) ?? null;
  }
  [Symbol.iterator]() {
    return this.#t.entries();
  }
}
const Wt = Symbol("INTERNAL");
class Gn {
  #t = !1;
  #e = !1;
  #i = !1;
  #s = !0;
  constructor(t, {
    name: e,
    intent: s,
    usage: i,
    rbGroups: n
  }) {
    this.#t = !!(t & bt.DISPLAY), this.#e = !!(t & bt.PRINT), this.name = e, this.intent = s, this.usage = i, this.rbGroups = n;
  }
  get visible() {
    if (this.#i)
      return this.#s;
    if (!this.#s)
      return !1;
    const {
      print: t,
      view: e
    } = this.usage;
    return this.#t ? e?.viewState !== "OFF" : this.#e ? t?.printState !== "OFF" : !0;
  }
  _setVisible(t, e, s = !1) {
    t !== Wt && j("Internal method `_setVisible` called."), this.#i = s, this.#s = e;
  }
}
class Vn {
  #t = null;
  #e = /* @__PURE__ */ new Map();
  #i = null;
  #s = null;
  constructor(t, e = bt.DISPLAY) {
    if (this.renderingIntent = e, this.name = null, this.creator = null, t !== null) {
      this.name = t.name, this.creator = t.creator, this.#s = t.order;
      for (const s of t.groups)
        this.#e.set(s.id, new Gn(e, s));
      if (t.baseState === "OFF")
        for (const s of this.#e.values())
          s._setVisible(Wt, !1);
      for (const s of t.on)
        this.#e.get(s)._setVisible(Wt, !0);
      for (const s of t.off)
        this.#e.get(s)._setVisible(Wt, !1);
      this.#i = this.getHash();
    }
  }
  #a(t) {
    const e = t.length;
    if (e < 2)
      return !0;
    const s = t[0];
    for (let i = 1; i < e; i++) {
      const n = t[i];
      let r;
      if (Array.isArray(n))
        r = this.#a(n);
      else if (this.#e.has(n))
        r = this.#e.get(n).visible;
      else
        return R(`Optional content group not found: ${n}`), !0;
      switch (s) {
        case "And":
          if (!r)
            return !1;
          break;
        case "Or":
          if (r)
            return !0;
          break;
        case "Not":
          return !r;
        default:
          return !0;
      }
    }
    return s === "And";
  }
  isVisible(t) {
    if (this.#e.size === 0)
      return !0;
    if (!t)
      return Ue("Optional content group not defined."), !0;
    if (t.type === "OCG")
      return this.#e.has(t.id) ? this.#e.get(t.id).visible : (R(`Optional content group not found: ${t.id}`), !0);
    if (t.type === "OCMD") {
      if (t.expression)
        return this.#a(t.expression);
      if (!t.policy || t.policy === "AnyOn") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return R(`Optional content group not found: ${e}`), !0;
          if (this.#e.get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOn") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return R(`Optional content group not found: ${e}`), !0;
          if (!this.#e.get(e).visible)
            return !1;
        }
        return !0;
      } else if (t.policy === "AnyOff") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return R(`Optional content group not found: ${e}`), !0;
          if (!this.#e.get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOff") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return R(`Optional content group not found: ${e}`), !0;
          if (this.#e.get(e).visible)
            return !1;
        }
        return !0;
      }
      return R(`Unknown optional content policy ${t.policy}.`), !0;
    }
    return R(`Unknown group type ${t.type}.`), !0;
  }
  setVisibility(t, e = !0, s = !0) {
    const i = this.#e.get(t);
    if (!i) {
      R(`Optional content group not found: ${t}`);
      return;
    }
    if (s && e && i.rbGroups.length)
      for (const n of i.rbGroups)
        for (const r of n)
          r !== t && this.#e.get(r)?._setVisible(Wt, !1, !0);
    i._setVisible(Wt, !!e, !0), this.#t = null;
  }
  setOCGState({
    state: t,
    preserveRB: e
  }) {
    let s;
    for (const i of t) {
      switch (i) {
        case "ON":
        case "OFF":
        case "Toggle":
          s = i;
          continue;
      }
      const n = this.#e.get(i);
      if (n)
        switch (s) {
          case "ON":
            this.setVisibility(i, !0, e);
            break;
          case "OFF":
            this.setVisibility(i, !1, e);
            break;
          case "Toggle":
            this.setVisibility(i, !n.visible, e);
            break;
        }
    }
    this.#t = null;
  }
  get hasInitialVisibility() {
    return this.#i === null || this.getHash() === this.#i;
  }
  getOrder() {
    return this.#e.size ? this.#s ? this.#s.slice() : [...this.#e.keys()] : null;
  }
  getGroup(t) {
    return this.#e.get(t) || null;
  }
  getHash() {
    if (this.#t !== null)
      return this.#t;
    const t = new vi();
    for (const [e, s] of this.#e)
      t.update(`${e}:${s.visible}`);
    return this.#t = t.hexdigest();
  }
  [Symbol.iterator]() {
    return this.#e.entries();
  }
}
class ze {
  #t = null;
  #e = null;
  _fullReader = null;
  _rangeReaders = /* @__PURE__ */ new Set();
  _source = null;
  constructor(t, e, s) {
    this._source = t, this.#t = e, this.#e = s;
  }
  get _progressiveDataLength() {
    return this._fullReader?._loaded ?? 0;
  }
  getFullReader() {
    return $(!this._fullReader, "BasePDFStream.getFullReader can only be called once."), this._fullReader = new this.#t(this);
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const s = new this.#e(this, t, e);
    return this._rangeReaders.add(s), s;
  }
  cancelAllRequests(t) {
    this._fullReader?.cancel(t);
    for (const e of new Set(this._rangeReaders))
      e.cancel(t);
  }
}
class Ge {
  onProgress = null;
  _contentLength = 0;
  _filename = null;
  _headersCapability = Promise.withResolvers();
  _isRangeSupported = !1;
  _isStreamingSupported = !1;
  _loaded = 0;
  _stream = null;
  constructor(t) {
    this._stream = t;
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  get filename() {
    return this._filename;
  }
  get contentLength() {
    return this._contentLength;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    j("Abstract method `read` called");
  }
  cancel(t) {
    j("Abstract method `cancel` called");
  }
}
class Ve {
  _stream = null;
  constructor(t, e, s) {
    this._stream = t;
  }
  async read() {
    j("Abstract method `read` called");
  }
  cancel(t) {
    j("Abstract method `cancel` called");
  }
}
function ri(d) {
  return d instanceof Uint8Array && d.byteLength === d.buffer.byteLength ? d.buffer : new Uint8Array(d).buffer;
}
class Wn extends ze {
  _progressiveDone = !1;
  _queuedChunks = [];
  constructor(t) {
    super(t, Xn, Yn);
    const {
      pdfDataRangeTransport: e
    } = t, {
      initialData: s,
      progressiveDone: i
    } = e;
    if (s?.length > 0) {
      const n = ri(s);
      this._queuedChunks.push(n);
    }
    this._progressiveDone = i, e.addRangeListener((n, r) => {
      this.#t(n, r);
    }), e.addProgressListener((n, r) => {
      r !== void 0 && this._fullReader?.onProgress?.({
        loaded: n,
        total: r
      });
    }), e.addProgressiveReadListener((n) => {
      this.#t(void 0, n);
    }), e.addProgressiveDoneListener(() => {
      this._fullReader?.progressiveDone(), this._progressiveDone = !0;
    }), e.transportReady();
  }
  #t(t, e) {
    const s = ri(e);
    if (t === void 0)
      this._fullReader ? this._fullReader._enqueue(s) : this._queuedChunks.push(s);
    else {
      const i = this._rangeReaders.keys().find((n) => n._begin === t);
      $(i, "#onReceiveData - no `PDFDataTransportStreamRangeReader` instance found."), i._enqueue(s);
    }
  }
  getFullReader() {
    const t = super.getFullReader();
    return this._queuedChunks = null, t;
  }
  getRangeReader(t, e) {
    const s = super.getRangeReader(t, e);
    return s && (s.onDone = () => this._rangeReaders.delete(s), this._source.pdfDataRangeTransport.requestDataRange(t, e)), s;
  }
  cancelAllRequests(t) {
    super.cancelAllRequests(t), this._source.pdfDataRangeTransport.abort();
  }
}
class Xn extends Ge {
  _done = !1;
  _queuedChunks = null;
  _requests = [];
  constructor(t) {
    super(t);
    const {
      pdfDataRangeTransport: e,
      disableRange: s,
      disableStream: i
    } = t._source, {
      length: n,
      contentDispositionFilename: r
    } = e;
    this._queuedChunks = t._queuedChunks || [];
    for (const a of this._queuedChunks)
      this._loaded += a.byteLength;
    this._done = t._progressiveDone, this._contentLength = n, this._isStreamingSupported = !i, this._isRangeSupported = !s, je(r) && (this._filename = r), this._headersCapability.resolve();
  }
  _enqueue(t) {
    this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._queuedChunks.push(t), this._loaded += t.byteLength);
  }
  async read() {
    if (this._queuedChunks.length > 0)
      return {
        value: this._queuedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0;
  }
  progressiveDone() {
    this._done ||= !0;
  }
}
class Yn extends Ve {
  onDone = null;
  _begin = -1;
  _done = !1;
  _queuedChunk = null;
  _requests = [];
  constructor(t, e, s) {
    super(t, e, s), this._begin = e;
  }
  _enqueue(t) {
    if (!this._done) {
      if (this._requests.length === 0)
        this._queuedChunk = t;
      else {
        this._requests.shift().resolve({
          value: t,
          done: !1
        });
        for (const s of this._requests)
          s.resolve({
            value: void 0,
            done: !0
          });
        this._requests.length = 0;
      }
      this._done = !0, this.onDone?.();
    }
  }
  async read() {
    if (this._queuedChunk) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this.onDone?.();
  }
}
function qn(d) {
  let t = !0, e = s("filename\\*", "i").exec(d);
  if (e) {
    e = e[1];
    let h = a(e);
    return h = unescape(h), h = o(h), h = l(h), n(h);
  }
  if (e = r(d), e) {
    const h = l(e);
    return n(h);
  }
  if (e = s("filename", "i").exec(d), e) {
    e = e[1];
    let h = a(e);
    return h = l(h), n(h);
  }
  function s(h, c) {
    return new RegExp("(?:^|;)\\s*" + h + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', c);
  }
  function i(h, c) {
    if (h) {
      if (!/^[\x00-\xFF]+$/.test(c))
        return c;
      try {
        const u = new TextDecoder(h, {
          fatal: !0
        }), f = He(c);
        c = u.decode(f), t = !1;
      } catch {
      }
    }
    return c;
  }
  function n(h) {
    return t && /[\x80-\xff]/.test(h) && (h = i("utf-8", h), t && (h = i("iso-8859-1", h))), h;
  }
  function r(h) {
    const c = [];
    let u;
    const f = s("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
    for (; (u = f.exec(h)) !== null; ) {
      let [, p, b, m] = u;
      if (p = parseInt(p, 10), p in c) {
        if (p === 0)
          break;
        continue;
      }
      c[p] = [b, m];
    }
    const g = [];
    for (let p = 0; p < c.length && p in c; ++p) {
      let [b, m] = c[p];
      m = a(m), b && (m = unescape(m), p === 0 && (m = o(m))), g.push(m);
    }
    return g.join("");
  }
  function a(h) {
    if (h.startsWith('"')) {
      const c = h.slice(1).split('\\"');
      for (let u = 0; u < c.length; ++u) {
        const f = c[u].indexOf('"');
        f !== -1 && (c[u] = c[u].slice(0, f), c.length = u + 1), c[u] = c[u].replaceAll(/\\(.)/g, "$1");
      }
      h = c.join('"');
    }
    return h;
  }
  function o(h) {
    const c = h.indexOf("'");
    if (c === -1)
      return h;
    const u = h.slice(0, c), g = h.slice(c + 1).replace(/^[^']*'/, "");
    return i(u, g);
  }
  function l(h) {
    return !h.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(h) ? h : h.replaceAll(/=\?([\w-]*)\?([QqBb])\?((?:[^?]|\?(?!=))*)\?=/g, function(c, u, f, g) {
      if (f === "q" || f === "Q")
        return g = g.replaceAll("_", " "), g = g.replaceAll(/=([0-9a-fA-F]{2})/g, function(p, b) {
          return String.fromCharCode(parseInt(b, 16));
        }), i(u, g);
      try {
        g = atob(g);
      } catch {
      }
      return i(u, g);
    });
  }
  return "";
}
function ki(d, t) {
  const e = new Headers();
  if (!d || !t || typeof t != "object")
    return e;
  for (const s in t) {
    const i = t[s];
    i !== void 0 && e.append(s, i);
  }
  return e;
}
function We(d) {
  return URL.parse(d)?.origin ?? null;
}
function Mi({
  responseHeaders: d,
  isHttp: t,
  rangeChunkSize: e,
  disableRange: s
}) {
  const i = {
    allowRangeRequests: !1,
    suggestedLength: void 0
  }, n = parseInt(d.get("Content-Length"), 10);
  return !Number.isInteger(n) || (i.suggestedLength = n, n <= 2 * e) || s || !t || d.get("Accept-Ranges") !== "bytes" || (d.get("Content-Encoding") || "identity") !== "identity" || (i.allowRangeRequests = !0), i;
}
function Di(d) {
  const t = d.get("Content-Disposition");
  if (t) {
    let e = qn(t);
    if (e.includes("%"))
      try {
        e = decodeURIComponent(e);
      } catch {
      }
    if (je(e))
      return e;
  }
  return null;
}
function Xe(d, t) {
  return new ge(`Unexpected server response (${d}) while retrieving PDF "${t}".`, d, d === 404 || d === 0 && t.startsWith("file:"));
}
function Li(d, t) {
  if (d !== t)
    throw new Error(`Expected range response-origin "${d}" to match "${t}".`);
}
function Ii(d, t, e, s) {
  return fetch(d, {
    method: "GET",
    headers: t,
    signal: s.signal,
    mode: "cors",
    credentials: e ? "include" : "same-origin",
    redirect: "follow"
  });
}
function Ri(d, t) {
  if (d !== 200 && d !== 206)
    throw Xe(d, t);
}
function Fi(d) {
  return d instanceof Uint8Array ? d.buffer : d instanceof ArrayBuffer ? d : (R(`getArrayBuffer - unexpected data format: ${d}`), new Uint8Array(d).buffer);
}
class Kn extends ze {
  _responseOrigin = null;
  constructor(t) {
    super(t, Qn, Jn), this.isHttp = /^https?:/i.test(t.url), this.headers = ki(this.isHttp, t.httpHeaders);
  }
}
class Qn extends Ge {
  _abortController = new AbortController();
  _reader = null;
  constructor(t) {
    super(t);
    const {
      disableRange: e,
      disableStream: s,
      length: i,
      rangeChunkSize: n,
      url: r,
      withCredentials: a
    } = t._source;
    this._contentLength = i, this._isStreamingSupported = !s, this._isRangeSupported = !e;
    const o = new Headers(t.headers);
    Ii(r, o, a, this._abortController).then((l) => {
      t._responseOrigin = We(l.url), Ri(l.status, r), this._reader = l.body.getReader();
      const h = l.headers, {
        allowRangeRequests: c,
        suggestedLength: u
      } = Mi({
        responseHeaders: h,
        isHttp: t.isHttp,
        rangeChunkSize: n,
        disableRange: e
      });
      this._isRangeSupported = c, this._contentLength = u || this._contentLength, this._filename = Di(h), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new Lt("Streaming is disabled.")), this._headersCapability.resolve();
    }).catch(this._headersCapability.reject);
  }
  async read() {
    await this._headersCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.byteLength, this.onProgress?.({
      loaded: this._loaded,
      total: this._contentLength
    }), {
      value: Fi(t),
      done: !1
    });
  }
  cancel(t) {
    this._reader?.cancel(t), this._abortController.abort();
  }
}
class Jn extends Ve {
  _abortController = new AbortController();
  _readCapability = Promise.withResolvers();
  _reader = null;
  constructor(t, e, s) {
    super(t, e, s);
    const {
      url: i,
      withCredentials: n
    } = t._source, r = new Headers(t.headers);
    r.append("Range", `bytes=${e}-${s - 1}`), Ii(i, r, n, this._abortController).then((a) => {
      const o = We(a.url);
      Li(o, t._responseOrigin), Ri(a.status, i), this._reader = a.body.getReader(), this._readCapability.resolve();
    }).catch(this._readCapability.reject);
  }
  async read() {
    await this._readCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : {
      value: Fi(t),
      done: !1
    };
  }
  cancel(t) {
    this._reader?.cancel(t), this._abortController.abort();
  }
}
const ns = 200, ai = 206;
function Zn(d) {
  return typeof d != "string" ? d : He(d).buffer;
}
class tr extends ze {
  #t = /* @__PURE__ */ new WeakMap();
  _responseOrigin = null;
  constructor(t) {
    super(t, er, sr), this.url = t.url, this.isHttp = /^https?:/i.test(this.url), this.headers = ki(this.isHttp, t.httpHeaders);
  }
  _request(t) {
    const e = new XMLHttpRequest(), s = {
      validateStatus: null,
      onHeadersReceived: t.onHeadersReceived,
      onDone: t.onDone,
      onError: t.onError,
      onProgress: t.onProgress
    };
    this.#t.set(e, s), e.open("GET", this.url), e.withCredentials = this._source.withCredentials;
    for (const [i, n] of this.headers)
      e.setRequestHeader(i, n);
    return this.isHttp && "begin" in t && "end" in t ? (e.setRequestHeader("Range", `bytes=${t.begin}-${t.end - 1}`), s.validateStatus = (i) => i === ai || i === ns) : s.validateStatus = (i) => i === ns, e.responseType = "arraybuffer", $(t.onError, "Expected `onError` callback to be provided."), e.onerror = () => t.onError(e.status), e.onreadystatechange = this.#i.bind(this, e), e.onprogress = this.#e.bind(this, e), e.send(null), e;
  }
  #e(t, e) {
    this.#t.get(t)?.onProgress?.(e);
  }
  #i(t, e) {
    const s = this.#t.get(t);
    if (!s || (t.readyState >= 2 && s.onHeadersReceived && (s.onHeadersReceived(), delete s.onHeadersReceived), t.readyState !== 4) || !this.#t.has(t))
      return;
    if (this.#t.delete(t), t.status === 0 && this.isHttp) {
      s.onError(t.status);
      return;
    }
    const i = t.status || ns;
    if (!s.validateStatus(i)) {
      s.onError(t.status);
      return;
    }
    const n = Zn(t.response);
    if (i === ai) {
      const r = t.getResponseHeader("Content-Range");
      /bytes (\d+)-(\d+)\/(\d+)/.test(r) ? s.onDone(n) : (R('Missing or invalid "Content-Range" header.'), s.onError(0));
    } else n ? s.onDone(n) : s.onError(t.status);
  }
  _abortRequest(t) {
    this.#t.has(t) && (this.#t.delete(t), t.abort());
  }
  getRangeReader(t, e) {
    const s = super.getRangeReader(t, e);
    return s && (s.onClosed = () => this._rangeReaders.delete(s)), s;
  }
}
class er extends Ge {
  _cachedChunks = [];
  _done = !1;
  _requests = [];
  _storedError = null;
  constructor(t) {
    super(t);
    const {
      length: e
    } = t._source;
    this._contentLength = e, this._fullRequestXhr = t._request({
      onHeadersReceived: this.#t.bind(this),
      onDone: this.#e.bind(this),
      onError: this.#i.bind(this),
      onProgress: this.#s.bind(this)
    });
  }
  #t() {
    const t = this._stream, {
      disableRange: e,
      rangeChunkSize: s
    } = t._source, i = this._fullRequestXhr;
    t._responseOrigin = We(i.responseURL);
    const n = i.getAllResponseHeaders(), r = new Headers(n ? n.trimStart().replace(/[^\S ]+$/, "").split(/[\r\n]+/).map((l) => {
      const [h, ...c] = l.split(": ");
      return [h, c.join(": ")];
    }) : []), {
      allowRangeRequests: a,
      suggestedLength: o
    } = Mi({
      responseHeaders: r,
      isHttp: t.isHttp,
      rangeChunkSize: s,
      disableRange: e
    });
    a && (this._isRangeSupported = !0), this._contentLength = o || this._contentLength, this._filename = Di(r), this._isRangeSupported && t._abortRequest(i), this._headersCapability.resolve();
  }
  #e(t) {
    if (this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._cachedChunks.push(t), this._done = !0, !(this._cachedChunks.length > 0)) {
      for (const e of this._requests)
        e.resolve({
          value: void 0,
          done: !0
        });
      this._requests.length = 0;
    }
  }
  #i(t) {
    this._storedError = Xe(t, this._stream.url), this._headersCapability.reject(this._storedError);
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._cachedChunks.length = 0;
  }
  #s(t) {
    this.onProgress?.({
      loaded: t.loaded,
      total: t.lengthComputable ? t.total : this._contentLength
    });
  }
  async read() {
    if (await this._headersCapability.promise, this._storedError)
      throw this._storedError;
    if (this._cachedChunks.length > 0)
      return {
        value: this._cachedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this._headersCapability.reject(t);
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._stream._abortRequest(this._fullRequestXhr), this._fullRequestXhr = null;
  }
}
class sr extends Ve {
  onClosed = null;
  _done = !1;
  _queuedChunk = null;
  _requests = [];
  _storedError = null;
  constructor(t, e, s) {
    super(t, e, s), this._requestXhr = t._request({
      begin: e,
      end: s,
      onHeadersReceived: this.#t.bind(this),
      onDone: this.#e.bind(this),
      onError: this.#i.bind(this),
      onProgress: null
    });
  }
  #t() {
    const t = We(this._requestXhr?.responseURL);
    try {
      Li(t, this._stream._responseOrigin);
    } catch (e) {
      this._storedError = e, this.#i(0);
    }
  }
  #e(t) {
    this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._queuedChunk = t, this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this.onClosed?.();
  }
  #i(t) {
    this._storedError ??= Xe(t, this._stream.url);
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._queuedChunk = null;
  }
  async read() {
    if (this._storedError)
      throw this._storedError;
    if (this._queuedChunk !== null) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._stream._abortRequest(this._requestXhr), this.onClosed?.();
  }
}
const ir = /^[a-z][a-z0-9\-+.]+:/i;
function nr(d) {
  if (ir.test(d))
    return new URL(d);
  const t = process.getBuiltinModule("url");
  return new URL(t.pathToFileURL(d));
}
function Ni(d) {
  const {
    Readable: t
  } = process.getBuiltinModule("stream");
  return typeof t.toWeb == "function" ? t.toWeb(d) : process.getBuiltinModule("module").createRequire(import.meta.url)("node-readable-to-web-readable-stream").makeDefaultReadableStreamFromNodeReadable(d);
}
function Oi(d) {
  return d instanceof Uint8Array ? d.buffer : d instanceof ArrayBuffer ? d : (R(`getArrayBuffer - unexpected data format: ${d}`), new Uint8Array(d).buffer);
}
class rr extends ze {
  constructor(t) {
    super(t, ar, or), this.url = nr(t.url), $(this.url.protocol === "file:", "PDFNodeStream only supports file:// URLs.");
  }
}
class ar extends Ge {
  _reader = null;
  constructor(t) {
    super(t);
    const {
      disableRange: e,
      disableStream: s,
      length: i,
      rangeChunkSize: n
    } = t._source;
    this._contentLength = i, this._isStreamingSupported = !s, this._isRangeSupported = !e;
    const r = t.url, a = process.getBuiltinModule("fs");
    a.promises.lstat(r).then((o) => {
      const l = a.createReadStream(r), h = Ni(l);
      this._reader = h.getReader();
      const {
        size: c
      } = o;
      c <= 2 * n && (this._isRangeSupported = !1), this._contentLength = c, !this._isStreamingSupported && this._isRangeSupported && this.cancel(new Lt("Streaming is disabled.")), this._headersCapability.resolve();
    }).catch((o) => {
      o.code === "ENOENT" && (o = Xe(0, r.href)), this._headersCapability.reject(o);
    });
  }
  async read() {
    await this._headersCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.length, this.onProgress?.({
      loaded: this._loaded,
      total: this._contentLength
    }), {
      value: Oi(t),
      done: !1
    });
  }
  cancel(t) {
    this._reader?.cancel(t);
  }
}
class or extends Ve {
  _readCapability = Promise.withResolvers();
  _reader = null;
  constructor(t, e, s) {
    super(t, e, s);
    const i = t.url, n = process.getBuiltinModule("fs");
    try {
      const r = n.createReadStream(i, {
        start: e,
        end: s - 1
      }), a = Ni(r);
      this._reader = a.getReader(), this._readCapability.resolve();
    } catch (r) {
      this._readCapability.reject(r);
    }
  }
  async read() {
    await this._readCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : {
      value: Oi(t),
      done: !1
    };
  }
  cancel(t) {
    this._reader?.cancel(t);
  }
}
const oe = Symbol("INITIAL_DATA");
class Bi {
  #t = /* @__PURE__ */ Object.create(null);
  #e(t) {
    return this.#t[t] ||= {
      ...Promise.withResolvers(),
      data: oe
    };
  }
  get(t, e = null) {
    if (e) {
      const i = this.#e(t);
      return i.promise.then(() => e(i.data)), null;
    }
    const s = this.#t[t];
    if (!s || s.data === oe)
      throw new Error(`Requesting object that isn't resolved yet ${t}.`);
    return s.data;
  }
  has(t) {
    const e = this.#t[t];
    return !!e && e.data !== oe;
  }
  delete(t) {
    const e = this.#t[t];
    return !e || e.data === oe ? !1 : (delete this.#t[t], !0);
  }
  resolve(t, e = null) {
    const s = this.#e(t);
    s.data = e, s.resolve();
  }
  clear() {
    for (const t in this.#t) {
      const {
        data: e
      } = this.#t[t];
      e?.bitmap?.close();
    }
    this.#t = /* @__PURE__ */ Object.create(null);
  }
  *[Symbol.iterator]() {
    for (const t in this.#t) {
      const {
        data: e
      } = this.#t[t];
      e !== oe && (yield [t, e]);
    }
  }
}
const lr = 1e5, oi = 30;
class gt {
  #t = Promise.withResolvers();
  #e = null;
  #i = !1;
  #s = !!globalThis.FontInspector?.enabled;
  #a = null;
  #r = null;
  #n = 0;
  #o = 0;
  #h = null;
  #l = null;
  #u = 0;
  #d = 0;
  #f = /* @__PURE__ */ Object.create(null);
  #m = [];
  #g = null;
  #c = [];
  #p = /* @__PURE__ */ new WeakMap();
  #b = null;
  static #y = /* @__PURE__ */ new Map();
  static #A = /* @__PURE__ */ new Map();
  static #C = /* @__PURE__ */ new WeakMap();
  static #E = null;
  static #v = /* @__PURE__ */ new Set();
  constructor({
    textContentSource: t,
    container: e,
    viewport: s
  }) {
    if (t instanceof ReadableStream)
      this.#g = t;
    else if (typeof t == "object")
      this.#g = new ReadableStream({
        start(o) {
          o.enqueue(t), o.close();
        }
      });
    else
      throw new Error('No "textContentSource" parameter specified.');
    this.#e = this.#l = e, this.#d = s.scale * Et.pixelRatio, this.#u = s.rotation, this.#r = {
      div: null,
      properties: null,
      ctx: null
    };
    const {
      pageWidth: i,
      pageHeight: n,
      pageX: r,
      pageY: a
    } = s.rawDims;
    this.#b = [1, 0, 0, -1, -r, a + n], this.#o = i, this.#n = n, gt.#k(), e.style.setProperty("--min-font-size", gt.#E), Nt(e, s), this.#t.promise.finally(() => {
      gt.#v.delete(this), this.#r = null, this.#f = null;
    }).catch(() => {
    });
  }
  static get fontFamilyMap() {
    const {
      isWindows: t,
      isFirefox: e
    } = nt.platform;
    return I(this, "fontFamilyMap", /* @__PURE__ */ new Map([["sans-serif", `${t && e ? "Calibri, " : ""}sans-serif`], ["monospace", `${t && e ? "Lucida Console, " : ""}monospace`]]));
  }
  render() {
    const t = () => {
      this.#h.read().then(({
        value: e,
        done: s
      }) => {
        if (s) {
          this.#t.resolve();
          return;
        }
        this.#a ??= e.lang, Object.assign(this.#f, e.styles), this.#x(e.items), t();
      }, this.#t.reject);
    };
    return this.#h = this.#g.getReader(), gt.#v.add(this), t(), this.#t.promise;
  }
  update({
    viewport: t,
    onBefore: e = null
  }) {
    const s = t.scale * Et.pixelRatio, i = t.rotation;
    if (i !== this.#u && (e?.(), this.#u = i, Nt(this.#l, {
      rotation: i
    })), s !== this.#d) {
      e?.(), this.#d = s;
      const n = {
        div: null,
        properties: null,
        ctx: gt.#M(this.#a)
      };
      for (const r of this.#c)
        n.properties = this.#p.get(r), n.div = r, this.#_(n);
    }
  }
  cancel() {
    const t = new Lt("TextLayer task cancelled.");
    this.#h?.cancel(t).catch(() => {
    }), this.#h = null, this.#t.reject(t);
  }
  get textDivs() {
    return this.#c;
  }
  get textContentItemsStr() {
    return this.#m;
  }
  #x(t) {
    if (this.#i)
      return;
    this.#r.ctx ??= gt.#M(this.#a);
    const e = this.#c, s = this.#m;
    for (const i of t) {
      if (e.length > lr) {
        R("Ignoring additional textDivs for performance reasons."), this.#i = !0;
        return;
      }
      if (i.str === void 0) {
        if (i.type === "beginMarkedContentProps" || i.type === "beginMarkedContent") {
          const n = this.#e;
          this.#e = document.createElement("span"), this.#e.classList.add("markedContent"), i.id && this.#e.setAttribute("id", `${i.id}`), i.tag === "Artifact" && (this.#e.ariaHidden = !0), n.append(this.#e);
        } else i.type === "endMarkedContent" && (this.#e = this.#e.parentNode);
        continue;
      }
      s.push(i.str), this.#w(i);
    }
  }
  #w(t) {
    const e = document.createElement("span"), s = {
      angle: 0,
      canvasWidth: 0,
      hasText: t.str !== "",
      hasEOL: t.hasEOL,
      fontSize: 0
    };
    this.#c.push(e);
    const i = T.transform(this.#b, t.transform);
    let n = Math.atan2(i[1], i[0]);
    const r = this.#f[t.fontName];
    r.vertical && (n += Math.PI / 2);
    let a = this.#s && r.fontSubstitution || r.fontFamily;
    a = gt.fontFamilyMap.get(a) || a;
    const o = Math.hypot(i[2], i[3]), l = o * gt.#O(a, r, this.#a);
    let h, c;
    n === 0 ? (h = i[4], c = i[5] - l) : (h = i[4] + l * Math.sin(n), c = i[5] - l * Math.cos(n));
    const u = e.style;
    u.left = `${(100 * h / this.#o).toFixed(2)}%`, u.top = `${(100 * c / this.#n).toFixed(2)}%`, u.setProperty("--font-height", `${o.toFixed(2)}px`), u.fontFamily = a, s.fontSize = o, e.setAttribute("role", "presentation"), e.textContent = t.str, e.dir = t.dir, this.#s && (e.dataset.fontName = r.fontSubstitutionLoadedName || t.fontName), n !== 0 && (s.angle = n * (180 / Math.PI));
    let f = !1;
    if (t.str.length > 1)
      f = !0;
    else if (t.str !== " " && t.transform[0] !== t.transform[3]) {
      const g = Math.abs(t.transform[0]), p = Math.abs(t.transform[3]);
      g !== p && Math.max(g, p) / Math.min(g, p) > 1.5 && (f = !0);
    }
    if (f && (s.canvasWidth = r.vertical ? t.height : t.width), this.#p.set(e, s), this.#r.div = e, this.#r.properties = s, this.#_(this.#r), s.hasText && this.#e.append(e), s.hasEOL) {
      const g = document.createElement("br");
      g.setAttribute("role", "presentation"), this.#e.append(g);
    }
  }
  #_(t) {
    const {
      div: e,
      properties: s,
      ctx: i
    } = t, {
      style: n
    } = e;
    if (s.canvasWidth !== 0 && s.hasText) {
      const {
        fontFamily: r
      } = n, {
        canvasWidth: a,
        fontSize: o
      } = s;
      gt.#P(i, o * this.#d, r);
      const {
        width: l
      } = i.measureText(e.textContent);
      l > 0 && n.setProperty("--scale-x", a * this.#d / l);
    }
    s.angle !== 0 && n.setProperty("--rotate", `${s.angle}deg`);
  }
  static cleanup() {
    if (!(this.#v.size > 0)) {
      this.#y.clear();
      for (const {
        canvas: t
      } of this.#A.values())
        t.remove();
      this.#A.clear();
    }
  }
  static #M(t = null) {
    let e = this.#A.get(t ||= "");
    if (!e) {
      const s = document.createElement("canvas");
      s.className = "hiddenCanvasElement", s.lang = t, document.body.append(s), e = s.getContext("2d", {
        alpha: !1,
        willReadFrequently: !0
      }), this.#A.set(t, e), this.#C.set(e, {
        size: 0,
        family: ""
      });
    }
    return e;
  }
  static #P(t, e, s) {
    const i = this.#C.get(t);
    e === i.size && s === i.family || (t.font = `${e}px ${s}`, i.size = e, i.family = s);
  }
  static #k() {
    if (this.#E !== null)
      return;
    const t = document.createElement("div");
    t.style.opacity = 0, t.style.lineHeight = 1, t.style.fontSize = "1px", t.style.position = "absolute", t.textContent = "X", document.body.append(t), this.#E = t.getBoundingClientRect().height, t.remove();
  }
  static #O(t, e, s) {
    const i = this.#y.get(t);
    if (i)
      return i;
    const n = this.#M(s);
    n.canvas.width = n.canvas.height = oi, this.#P(n, oi, t);
    const r = n.measureText(""), a = r.fontBoundingBoxAscent, o = Math.abs(r.fontBoundingBoxDescent);
    n.canvas.width = n.canvas.height = 0;
    let l = 0.8;
    return a ? l = a / (a + o) : (nt.platform.isFirefox && R("Enable the `dom.textMetrics.fontBoundingBox.enabled` preference in `about:config` to improve TextLayer rendering."), e.ascent ? l = e.ascent : e.descent && (l = 1 + e.descent)), this.#y.set(t, l), l;
  }
}
const hr = 100;
function Ui(d = {}) {
  typeof d == "string" || d instanceof URL ? d = {
    url: d
  } : (d instanceof ArrayBuffer || ArrayBuffer.isView(d)) && (d = {
    data: d
  });
  const t = new Ps(), {
    docId: e
  } = t, s = d.url ? An(d.url) : null, i = d.data ? yn(d.data) : null, n = d.httpHeaders || null, r = d.withCredentials === !0, a = d.password ?? null, o = d.range instanceof ks ? d.range : null, l = Number.isInteger(d.rangeChunkSize) && d.rangeChunkSize > 0 ? d.rangeChunkSize : 2 ** 16;
  let h = d.worker instanceof ht ? d.worker : null;
  const c = d.verbosity, u = typeof d.docBaseUrl == "string" && !ve(d.docBaseUrl) ? d.docBaseUrl : null, f = Te(d.cMapUrl), g = d.cMapPacked !== !1, p = d.CMapReaderFactory || (ut ? Tn : Vs), b = Te(d.iccUrl), m = Te(d.standardFontDataUrl), y = d.StandardFontDataFactory || (ut ? xn : Ws), A = Te(d.wasmUrl), v = d.WasmFactory || (ut ? Pn : Xs), w = d.stopAtErrors !== !0, S = Number.isInteger(d.maxImageSize) && d.maxImageSize > -1 ? d.maxImageSize : -1, E = d.isEvalSupported !== !1, _ = typeof d.isOffscreenCanvasSupported == "boolean" ? d.isOffscreenCanvasSupported : !ut, C = typeof d.isImageDecoderSupported == "boolean" ? d.isImageDecoderSupported : !ut && (nt.platform.isFirefox || !globalThis.chrome), k = Number.isInteger(d.canvasMaxAreaInBytes) ? d.canvasMaxAreaInBytes : -1, x = typeof d.disableFontFace == "boolean" ? d.disableFontFace : ut, z = d.fontExtraProperties === !0, W = d.enableXfa === !0, O = d.ownerDocument || globalThis.document, tt = d.disableRange === !0, M = d.disableStream === !0, L = d.disableAutoFetch === !0, G = d.pdfBug === !0, mt = d.CanvasFactory || (ut ? Cn : Sn), kt = d.FilterFactory || (ut ? _n : En), et = d.enableHWA === !0, X = d.useWasm !== !1, Y = o ? o.length : d.length ?? NaN, Ot = typeof d.useSystemFonts == "boolean" ? d.useSystemFonts : !ut && !x, Rt = typeof d.useWorkerFetch == "boolean" ? d.useWorkerFetch : !!(p === Vs && y === Ws && v === Xs && f && m && A && ce(f, document.baseURI) && ce(m, document.baseURI) && ce(A, document.baseURI)), Ft = null;
  Qi(c);
  const st = {
    canvasFactory: new mt({
      ownerDocument: O,
      enableHWA: et
    }),
    filterFactory: new kt({
      docId: e,
      ownerDocument: O
    }),
    cMapReaderFactory: Rt ? null : new p({
      baseUrl: f,
      isCompressed: g
    }),
    standardFontDataFactory: Rt ? null : new y({
      baseUrl: m
    }),
    wasmFactory: Rt ? null : new v({
      baseUrl: A
    })
  };
  h || (h = ht.create({
    verbosity: c,
    port: Zt.workerPort
  }), t._worker = h);
  const ie = {
    docId: e,
    apiVersion: "5.4.624",
    data: i,
    password: a,
    disableAutoFetch: L,
    rangeChunkSize: l,
    length: Y,
    docBaseUrl: u,
    enableXfa: W,
    evaluatorOptions: {
      maxImageSize: S,
      disableFontFace: x,
      ignoreErrors: w,
      isEvalSupported: E,
      isOffscreenCanvasSupported: _,
      isImageDecoderSupported: C,
      canvasMaxAreaInBytes: k,
      fontExtraProperties: z,
      useSystemFonts: Ot,
      useWasm: X,
      useWorkerFetch: Rt,
      cMapUrl: f,
      iccUrl: b,
      standardFontDataUrl: m,
      wasmUrl: A
    }
  }, ne = {
    ownerDocument: O,
    pdfBug: G,
    styleElement: Ft,
    enableHWA: et,
    loadingParams: {
      disableAutoFetch: L,
      enableXfa: W
    }
  };
  return h.promise.then(function() {
    if (t.destroyed)
      throw new Error("Loading aborted");
    if (h.destroyed)
      throw new Error("Worker was destroyed");
    const qi = h.messageHandler.sendWithPromise("GetDocRequest", ie, i ? [i.buffer] : null);
    let Ke;
    if (o)
      Ke = new Wn({
        pdfDataRangeTransport: o,
        disableRange: tt,
        disableStream: M
      });
    else if (!i) {
      if (!s)
        throw new Error("getDocument - no `url` parameter provided.");
      const Qe = ce(s) ? Kn : ut ? rr : tr;
      Ke = new Qe({
        url: s,
        length: Y,
        httpHeaders: n,
        withCredentials: r,
        rangeChunkSize: l,
        disableRange: tt,
        disableStream: M
      });
    }
    return qi.then((Qe) => {
      if (t.destroyed)
        throw new Error("Loading aborted");
      if (h.destroyed)
        throw new Error("Worker was destroyed");
      const Fs = new de(e, Qe, h.port), Ki = new ur(Fs, t, Ke, ne, st);
      t._transport = Ki, Fs.send("Ready", null);
    });
  }).catch(t._capability.reject), t;
}
class Ps {
  static #t = 0;
  _capability = Promise.withResolvers();
  _transport = null;
  _worker = null;
  docId = `d${Ps.#t++}`;
  destroyed = !1;
  onPassword = null;
  onProgress = null;
  get promise() {
    return this._capability.promise;
  }
  async destroy() {
    this.destroyed = !0;
    try {
      this._worker?.port && (this._worker._pendingDestroy = !0), await this._transport?.destroy();
    } catch (t) {
      throw this._worker?.port && delete this._worker._pendingDestroy, t;
    }
    this._transport = null, this._worker?.destroy(), this._worker = null;
  }
  async getData() {
    return this._transport.getData();
  }
}
class ks {
  #t = Promise.withResolvers();
  #e = [];
  #i = [];
  #s = [];
  #a = [];
  constructor(t, e, s = !1, i = null) {
    this.length = t, this.initialData = e, this.progressiveDone = s, this.contentDispositionFilename = i;
  }
  addRangeListener(t) {
    this.#a.push(t);
  }
  addProgressListener(t) {
    this.#s.push(t);
  }
  addProgressiveReadListener(t) {
    this.#i.push(t);
  }
  addProgressiveDoneListener(t) {
    this.#e.push(t);
  }
  onDataRange(t, e) {
    for (const s of this.#a)
      s(t, e);
  }
  onDataProgress(t, e) {
    this.#t.promise.then(() => {
      for (const s of this.#s)
        s(t, e);
    });
  }
  onDataProgressiveRead(t) {
    this.#t.promise.then(() => {
      for (const e of this.#i)
        e(t);
    });
  }
  onDataProgressiveDone() {
    this.#t.promise.then(() => {
      for (const t of this.#e)
        t();
    });
  }
  transportReady() {
    this.#t.resolve();
  }
  requestDataRange(t, e) {
    j("Abstract method PDFDataRangeTransport.requestDataRange");
  }
  abort() {
  }
}
class cr {
  constructor(t, e) {
    this._pdfInfo = t, this._transport = e;
  }
  get annotationStorage() {
    return this._transport.annotationStorage;
  }
  get canvasFactory() {
    return this._transport.canvasFactory;
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get numPages() {
    return this._pdfInfo.numPages;
  }
  get fingerprints() {
    return this._pdfInfo.fingerprints;
  }
  get isPureXfa() {
    return I(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  get allXfaHtml() {
    return this._transport._htmlForXfa;
  }
  getPage(t) {
    return this._transport.getPage(t);
  }
  getPageIndex(t) {
    return this._transport.getPageIndex(t);
  }
  getDestinations() {
    return this._transport.getDestinations();
  }
  getDestination(t) {
    return this._transport.getDestination(t);
  }
  getPageLabels() {
    return this._transport.getPageLabels();
  }
  getPageLayout() {
    return this._transport.getPageLayout();
  }
  getPageMode() {
    return this._transport.getPageMode();
  }
  getViewerPreferences() {
    return this._transport.getViewerPreferences();
  }
  getOpenAction() {
    return this._transport.getOpenAction();
  }
  getAttachments() {
    return this._transport.getAttachments();
  }
  getAnnotationsByType(t, e) {
    return this._transport.getAnnotationsByType(t, e);
  }
  getJSActions() {
    return this._transport.getDocJSActions();
  }
  getOutline() {
    return this._transport.getOutline();
  }
  getOptionalContentConfig({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getOptionalContentConfig(e);
  }
  getPermissions() {
    return this._transport.getPermissions();
  }
  getMetadata() {
    return this._transport.getMetadata();
  }
  getMarkInfo() {
    return this._transport.getMarkInfo();
  }
  getData() {
    return this._transport.getData();
  }
  saveDocument() {
    return this._transport.saveDocument();
  }
  extractPages(t) {
    return this._transport.extractPages(t);
  }
  getDownloadInfo() {
    return this._transport.downloadInfoCapability.promise;
  }
  cleanup(t = !1) {
    return this._transport.startCleanup(t || this.isPureXfa);
  }
  destroy() {
    return this.loadingTask.destroy();
  }
  cachedPageNumber(t) {
    return this._transport.cachedPageNumber(t);
  }
  get loadingParams() {
    return this._transport.loadingParams;
  }
  get loadingTask() {
    return this._transport.loadingTask;
  }
  getFieldObjects() {
    return this._transport.getFieldObjects();
  }
  hasJSActions() {
    return this._transport.hasJSActions();
  }
  getCalculationOrderIds() {
    return this._transport.getCalculationOrderIds();
  }
}
class dr {
  #t = !1;
  #e = B.instance;
  constructor(t, e, s, i = !1) {
    this._pageIndex = t, this._pageInfo = e, this._transport = s, this._stats = i ? new Bs() : null, this._pdfBug = i, this.commonObjs = s.commonObjs, this.objs = new Bi(), this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1, this.recordedBBoxes = null;
  }
  get pageNumber() {
    return this._pageIndex + 1;
  }
  set pageNumber(t) {
    this._pageIndex = t - 1;
  }
  get rotate() {
    return this._pageInfo.rotate;
  }
  get ref() {
    return this._pageInfo.ref;
  }
  get userUnit() {
    return this._pageInfo.userUnit;
  }
  get view() {
    return this._pageInfo.view;
  }
  getViewport({
    scale: t,
    rotation: e = this.rotate,
    offsetX: s = 0,
    offsetY: i = 0,
    dontFlip: n = !1
  } = {}) {
    return new we({
      viewBox: this.view,
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: i,
      dontFlip: n
    });
  }
  getAnnotations({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getAnnotations(this._pageIndex, e);
  }
  getJSActions() {
    return this._transport.getPageJSActions(this._pageIndex);
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get isPureXfa() {
    return I(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  async getXfa() {
    return this._transport._htmlForXfa?.children[this._pageIndex] || null;
  }
  render({
    canvasContext: t,
    canvas: e = t.canvas,
    viewport: s,
    intent: i = "display",
    annotationMode: n = Dt.ENABLE,
    transform: r = null,
    background: a = null,
    optionalContentConfigPromise: o = null,
    annotationCanvasMap: l = null,
    pageColors: h = null,
    printAnnotationStorage: c = null,
    isEditing: u = !1,
    recordOperations: f = !1,
    operationsFilter: g = null
  }) {
    this._stats?.time("Overall");
    const p = this._transport.getRenderingIntent(i, n, c, u), {
      renderingIntent: b,
      cacheKey: m
    } = p;
    this.#t = !1, o ||= this._transport.getOptionalContentConfig(b);
    let y = this._intentStates.get(m);
    y || (y = /* @__PURE__ */ Object.create(null), this._intentStates.set(m, y)), y.streamReaderCancelTimeout && (clearTimeout(y.streamReaderCancelTimeout), y.streamReaderCancelTimeout = null);
    const A = !!(b & bt.PRINT);
    y.displayReadyCapability || (y.displayReadyCapability = Promise.withResolvers(), y.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, this._stats?.time("Page Request"), this._pumpOperatorList(p));
    const v = !!(this._pdfBug && globalThis.StepperManager?.enabled), w = !this.recordedBBoxes && (f || v), S = (C) => {
      if (y.renderTasks.delete(E), w) {
        const k = E.gfx?.dependencyTracker.take();
        k && (E.stepper && E.stepper.setOperatorBBoxes(k, E.gfx.dependencyTracker.takeDebugMetadata()), f && (this.recordedBBoxes = k));
      }
      A && (this.#t = !0), this.#i(), C ? (E.capability.reject(C), this._abortOperatorList({
        intentState: y,
        reason: C instanceof Error ? C : new Error(C)
      })) : E.capability.resolve(), this._stats && (this._stats.timeEnd("Rendering"), this._stats.timeEnd("Overall"), globalThis.Stats?.enabled && globalThis.Stats.add(this.pageNumber, this._stats));
    }, E = new qt({
      callback: S,
      params: {
        canvas: e,
        canvasContext: t,
        dependencyTracker: w ? new Mn(e, y.operatorList.length, v) : null,
        viewport: s,
        transform: r,
        background: a
      },
      objs: this.objs,
      commonObjs: this.commonObjs,
      annotationCanvasMap: l,
      operatorList: y.operatorList,
      pageIndex: this._pageIndex,
      canvasFactory: this._transport.canvasFactory,
      filterFactory: this._transport.filterFactory,
      useRequestAnimationFrame: !A,
      pdfBug: this._pdfBug,
      pageColors: h,
      enableHWA: this._transport.enableHWA,
      operationsFilter: g
    });
    (y.renderTasks ||= /* @__PURE__ */ new Set()).add(E);
    const _ = E.task;
    return Promise.all([y.displayReadyCapability.promise, o]).then(([C, k]) => {
      if (this.destroyed) {
        S();
        return;
      }
      if (this._stats?.time("Rendering"), !(k.renderingIntent & b))
        throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");
      E.initializeGraphics({
        transparency: C,
        optionalContentConfig: k
      }), E.operatorListChanged();
    }).catch(S), _;
  }
  getOperatorList({
    intent: t = "display",
    annotationMode: e = Dt.ENABLE,
    printAnnotationStorage: s = null,
    isEditing: i = !1
  } = {}) {
    function n() {
      a.operatorList.lastChunk && (a.opListReadCapability.resolve(a.operatorList), a.renderTasks.delete(o));
    }
    const r = this._transport.getRenderingIntent(t, e, s, i, !0);
    let a = this._intentStates.get(r.cacheKey);
    a || (a = /* @__PURE__ */ Object.create(null), this._intentStates.set(r.cacheKey, a));
    let o;
    return a.opListReadCapability || (o = /* @__PURE__ */ Object.create(null), o.operatorListChanged = n, a.opListReadCapability = Promise.withResolvers(), (a.renderTasks ||= /* @__PURE__ */ new Set()).add(o), a.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, this._stats?.time("Page Request"), this._pumpOperatorList(r)), a.opListReadCapability.promise;
  }
  streamTextContent({
    includeMarkedContent: t = !1,
    disableNormalization: e = !1
  } = {}) {
    return this._transport.messageHandler.sendWithStream("GetTextContent", {
      pageId: this.#e.getPageId(this._pageIndex + 1) - 1,
      pageIndex: this._pageIndex,
      includeMarkedContent: t === !0,
      disableNormalization: e === !0
    }, {
      highWaterMark: 100,
      size(i) {
        return i.items.length;
      }
    });
  }
  getTextContent(t = {}) {
    if (this._transport._htmlForXfa)
      return this.getXfa().then((s) => me.textContent(s));
    const e = this.streamTextContent(t);
    return new Promise(function(s, i) {
      function n() {
        r.read().then(function({
          value: o,
          done: l
        }) {
          if (l) {
            s(a);
            return;
          }
          a.lang ??= o.lang, Object.assign(a.styles, o.styles), a.items.push(...o.items), n();
        }, i);
      }
      const r = e.getReader(), a = {
        items: [],
        styles: /* @__PURE__ */ Object.create(null),
        lang: null
      };
      n();
    });
  }
  getStructTree() {
    return this._transport.getStructTree(this._pageIndex);
  }
  _destroy() {
    this.destroyed = !0;
    const t = [];
    for (const e of this._intentStates.values())
      if (this._abortOperatorList({
        intentState: e,
        reason: new Error("Page was destroyed."),
        force: !0
      }), !e.opListReadCapability)
        for (const s of e.renderTasks)
          t.push(s.completed), s.cancel();
    return this.objs.clear(), this.#t = !1, Promise.all(t);
  }
  cleanup(t = !1) {
    this.#t = !0;
    const e = this.#i();
    return t && e && (this._stats &&= new Bs()), e;
  }
  #i() {
    if (!this.#t || this.destroyed)
      return !1;
    for (const {
      renderTasks: t,
      operatorList: e
    } of this._intentStates.values())
      if (t.size > 0 || !e.lastChunk)
        return !1;
    return this._intentStates.clear(), this.objs.clear(), this.#t = !1, !0;
  }
  _startRenderPage(t, e) {
    const s = this._intentStates.get(e);
    s && (this._stats?.timeEnd("Page Request"), s.displayReadyCapability?.resolve(t));
  }
  _renderPageChunk(t, e) {
    for (let s = 0, i = t.length; s < i; s++)
      e.operatorList.fnArray.push(t.fnArray[s]), e.operatorList.argsArray.push(t.argsArray[s]);
    e.operatorList.lastChunk = t.lastChunk, e.operatorList.separateAnnots = t.separateAnnots;
    for (const s of e.renderTasks)
      s.operatorListChanged();
    t.lastChunk && this.#i();
  }
  _pumpOperatorList({
    renderingIntent: t,
    cacheKey: e,
    annotationStorageSerializable: s,
    modifiedIds: i
  }) {
    const {
      map: n,
      transfer: r
    } = s, o = this._transport.messageHandler.sendWithStream("GetOperatorList", {
      pageId: this.#e.getPageId(this._pageIndex + 1) - 1,
      pageIndex: this._pageIndex,
      intent: t,
      cacheKey: e,
      annotationStorage: n,
      modifiedIds: i
    }, r).getReader(), l = this._intentStates.get(e);
    l.streamReader = o;
    const h = () => {
      o.read().then(({
        value: c,
        done: u
      }) => {
        if (u) {
          l.streamReader = null;
          return;
        }
        this._transport.destroyed || (this._renderPageChunk(c, l), h());
      }, (c) => {
        if (l.streamReader = null, !this._transport.destroyed) {
          if (l.operatorList) {
            l.operatorList.lastChunk = !0;
            for (const u of l.renderTasks)
              u.operatorListChanged();
            this.#i();
          }
          if (l.displayReadyCapability)
            l.displayReadyCapability.reject(c);
          else if (l.opListReadCapability)
            l.opListReadCapability.reject(c);
          else
            throw c;
        }
      });
    };
    h();
  }
  _abortOperatorList({
    intentState: t,
    reason: e,
    force: s = !1
  }) {
    if (t.streamReader) {
      if (t.streamReaderCancelTimeout && (clearTimeout(t.streamReaderCancelTimeout), t.streamReaderCancelTimeout = null), !s) {
        if (t.renderTasks.size > 0)
          return;
        if (e instanceof $e) {
          let i = hr;
          e.extraDelay > 0 && e.extraDelay < 1e3 && (i += e.extraDelay), t.streamReaderCancelTimeout = setTimeout(() => {
            t.streamReaderCancelTimeout = null, this._abortOperatorList({
              intentState: t,
              reason: e,
              force: !0
            });
          }, i);
          return;
        }
      }
      if (t.streamReader.cancel(new Lt(e.message)).catch(() => {
      }), t.streamReader = null, !this._transport.destroyed) {
        for (const [i, n] of this._intentStates)
          if (n === t) {
            this._intentStates.delete(i);
            break;
          }
        this.cleanup();
      }
    }
  }
  get stats() {
    return this._stats;
  }
}
class ht {
  #t = Promise.withResolvers();
  #e = null;
  #i = null;
  #s = null;
  static #a = 0;
  static #r = !1;
  static #n = /* @__PURE__ */ new WeakMap();
  static {
    ut && (this.#r = !0, Zt.workerSrc ||= "./pdf.worker.mjs"), this._isSameOrigin = (t, e) => {
      const s = URL.parse(t);
      if (!s?.origin || s.origin === "null")
        return !1;
      const i = new URL(e, s);
      return s.origin === i.origin;
    }, this._createCDNWrapper = (t) => {
      const e = `await import("${t}");`;
      return URL.createObjectURL(new Blob([e], {
        type: "text/javascript"
      }));
    }, this.fromPort = (t) => {
      if (ln("`PDFWorker.fromPort` - please use `PDFWorker.create` instead."), !t?.port)
        throw new Error("PDFWorker.fromPort - invalid method signature.");
      return this.create(t);
    };
  }
  constructor({
    name: t = null,
    port: e = null,
    verbosity: s = Ji()
  } = {}) {
    if (this.name = t, this.destroyed = !1, this.verbosity = s, e) {
      if (ht.#n.has(e))
        throw new Error("Cannot use more than one PDFWorker per port.");
      ht.#n.set(e, this), this.#h(e);
    } else
      this.#l();
  }
  get promise() {
    return this.#t.promise;
  }
  #o() {
    this.#t.resolve(), this.#e.send("configure", {
      verbosity: this.verbosity
    });
  }
  get port() {
    return this.#i;
  }
  get messageHandler() {
    return this.#e;
  }
  #h(t) {
    this.#i = t, this.#e = new de("main", "worker", t), this.#e.on("ready", () => {
    }), this.#o();
  }
  #l() {
    if (ht.#r || ht.#d) {
      this.#u();
      return;
    }
    let {
      workerSrc: t
    } = ht;
    try {
      ht._isSameOrigin(window.location, t) || (t = ht._createCDNWrapper(new URL(t, window.location).href));
      const e = new Worker(t, {
        type: "module"
      }), s = new de("main", "worker", e), i = () => {
        n.abort(), s.destroy(), e.terminate(), this.destroyed ? this.#t.reject(new Error("Worker was destroyed")) : this.#u();
      }, n = new AbortController();
      e.addEventListener("error", () => {
        this.#s || i();
      }, {
        signal: n.signal
      }), s.on("test", (a) => {
        if (n.abort(), this.destroyed || !a) {
          i();
          return;
        }
        this.#e = s, this.#i = e, this.#s = e, this.#o();
      }), s.on("ready", (a) => {
        if (n.abort(), this.destroyed) {
          i();
          return;
        }
        try {
          r();
        } catch {
          this.#u();
        }
      });
      const r = () => {
        const a = new Uint8Array();
        s.send("test", a, [a.buffer]);
      };
      r();
      return;
    } catch {
      Ue("The worker has been disabled.");
    }
    this.#u();
  }
  #u() {
    ht.#r || (R("Setting up fake worker."), ht.#r = !0), ht._setupFakeWorkerGlobal.then((t) => {
      if (this.destroyed) {
        this.#t.reject(new Error("Worker was destroyed"));
        return;
      }
      const e = new vn();
      this.#i = e;
      const s = `fake${ht.#a++}`, i = new de(s + "_worker", s, e);
      t.setup(i, e), this.#e = new de(s, s + "_worker", e), this.#o();
    }).catch((t) => {
      this.#t.reject(new Error(`Setting up fake worker failed: "${t.message}".`));
    });
  }
  destroy() {
    this.destroyed = !0, this.#s?.terminate(), this.#s = null, ht.#n.delete(this.#i), this.#i = null, this.#e?.destroy(), this.#e = null;
  }
  static create(t) {
    const e = this.#n.get(t?.port);
    if (e) {
      if (e._pendingDestroy)
        throw new Error("PDFWorker.create - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
      return e;
    }
    return new ht(t);
  }
  static get workerSrc() {
    if (Zt.workerSrc)
      return Zt.workerSrc;
    throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
  }
  static get #d() {
    try {
      return globalThis.pdfjsWorker?.WorkerMessageHandler || null;
    } catch {
      return null;
    }
  }
  static get _setupFakeWorkerGlobal() {
    return I(this, "_setupFakeWorkerGlobal", (async () => this.#d ? this.#d : (await import(
      /*webpackIgnore: true*/
      /*@vite-ignore*/
      this.workerSrc
    )).WorkerMessageHandler)());
  }
}
class ur {
  downloadInfoCapability = Promise.withResolvers();
  #t = null;
  #e = /* @__PURE__ */ new Map();
  #i = null;
  #s = /* @__PURE__ */ new Map();
  #a = /* @__PURE__ */ new Map();
  #r = /* @__PURE__ */ new Map();
  #n = null;
  #o = B.instance;
  constructor(t, e, s, i, n) {
    this.messageHandler = t, this.loadingTask = e, this.#i = s, this.commonObjs = new Bi(), this.fontLoader = new gn({
      ownerDocument: i.ownerDocument,
      styleElement: i.styleElement
    }), this.enableHWA = i.enableHWA, this.loadingParams = i.loadingParams, this._params = i, this.canvasFactory = n.canvasFactory, this.filterFactory = n.filterFactory, this.cMapReaderFactory = n.cMapReaderFactory, this.standardFontDataFactory = n.standardFontDataFactory, this.wasmFactory = n.wasmFactory, this.destroyed = !1, this.destroyCapability = null, this.setupMessageHandler(), this.#o.addListener(this.#h.bind(this));
  }
  #h() {
    const t = /* @__PURE__ */ new Map(), e = /* @__PURE__ */ new Map();
    for (let s = 0, i = this.#o.pagesNumber; s < i; s++) {
      const n = this.#o.getPrevPageNumber(s + 1) - 1, r = this.#s.get(n);
      r && t.set(s, r);
      const a = this.#a.get(n);
      a && e.set(s, a);
    }
    this.#s = t, this.#a = e;
  }
  #l(t, e = null) {
    const s = this.#e.get(t);
    if (s)
      return s;
    const i = this.messageHandler.sendWithPromise(t, e);
    return this.#e.set(t, i), i;
  }
  #u({
    loaded: t,
    total: e
  }) {
    this.loadingTask.onProgress?.({
      loaded: t,
      total: e,
      percent: ct(Math.round(t / e * 100), 0, 100)
    });
  }
  get annotationStorage() {
    return I(this, "annotationStorage", new _s());
  }
  getRenderingIntent(t, e = Dt.ENABLE, s = null, i = !1, n = !1) {
    let r = bt.DISPLAY, a = hs;
    switch (t) {
      case "any":
        r = bt.ANY;
        break;
      case "display":
        break;
      case "print":
        r = bt.PRINT;
        break;
      default:
        R(`getRenderingIntent - invalid intent: ${t}`);
    }
    const o = r & bt.PRINT && s instanceof Si ? s : this.annotationStorage;
    switch (e) {
      case Dt.DISABLE:
        r += bt.ANNOTATIONS_DISABLE;
        break;
      case Dt.ENABLE:
        break;
      case Dt.ENABLE_FORMS:
        r += bt.ANNOTATIONS_FORMS;
        break;
      case Dt.ENABLE_STORAGE:
        r += bt.ANNOTATIONS_STORAGE, a = o.serializable;
        break;
      default:
        R(`getRenderingIntent - invalid annotationMode: ${e}`);
    }
    i && (r += bt.IS_EDITING), n && (r += bt.OPLIST);
    const {
      ids: l,
      hash: h
    } = o.modifiedIds, c = [r, a.hash, h];
    return {
      renderingIntent: r,
      cacheKey: c.join("_"),
      annotationStorageSerializable: a,
      modifiedIds: l
    };
  }
  destroy() {
    if (this.destroyCapability)
      return this.destroyCapability.promise;
    this.destroyed = !0, this.destroyCapability = Promise.withResolvers(), this.#n?.reject(new Error("Worker was destroyed during onPassword callback"));
    const t = [];
    for (const s of this.#s.values())
      t.push(s._destroy());
    this.#s.clear(), this.#a.clear(), this.#r.clear(), this.hasOwnProperty("annotationStorage") && this.annotationStorage.resetModified();
    const e = this.messageHandler.sendWithPromise("Terminate", null);
    return t.push(e), Promise.all(t).then(() => {
      this.commonObjs.clear(), this.fontLoader.clear(), this.#e.clear(), this.filterFactory.destroy(), gt.cleanup(), this.#i?.cancelAllRequests(new Lt("Worker was terminated.")), this.messageHandler?.destroy(), this.messageHandler = null, this.destroyCapability.resolve();
    }, this.destroyCapability.reject), this.destroyCapability.promise;
  }
  setupMessageHandler() {
    const {
      messageHandler: t,
      loadingTask: e
    } = this;
    t.on("GetReader", (s, i) => {
      $(this.#i, "GetReader - no `BasePDFStream` instance available."), this.#t = this.#i.getFullReader(), this.#t.onProgress = (n) => this.#u(n), i.onPull = () => {
        this.#t.read().then(function({
          value: n,
          done: r
        }) {
          if (r) {
            i.close();
            return;
          }
          $(n instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), i.enqueue(new Uint8Array(n), 1, [n]);
        }).catch((n) => {
          i.error(n);
        });
      }, i.onCancel = (n) => {
        this.#t.cancel(n), i.ready.catch((r) => {
          if (!this.destroyed)
            throw r;
        });
      };
    }), t.on("ReaderHeadersReady", async (s) => {
      await this.#t.headersReady;
      const {
        isStreamingSupported: i,
        isRangeSupported: n,
        contentLength: r
      } = this.#t;
      return i && n && (this.#t.onProgress = null), {
        isStreamingSupported: i,
        isRangeSupported: n,
        contentLength: r
      };
    }), t.on("GetRangeReader", (s, i) => {
      $(this.#i, "GetRangeReader - no `BasePDFStream` instance available.");
      const n = this.#i.getRangeReader(s.begin, s.end);
      if (!n) {
        i.close();
        return;
      }
      i.onPull = () => {
        n.read().then(function({
          value: r,
          done: a
        }) {
          if (a) {
            i.close();
            return;
          }
          $(r instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), i.enqueue(new Uint8Array(r), 1, [r]);
        }).catch((r) => {
          i.error(r);
        });
      }, i.onCancel = (r) => {
        n.cancel(r), i.ready.catch((a) => {
          if (!this.destroyed)
            throw a;
        });
      };
    }), t.on("GetDoc", ({
      pdfInfo: s
    }) => {
      this.#o.pagesNumber = s.numPages, this._numPages = s.numPages, this._htmlForXfa = s.htmlForXfa, delete s.htmlForXfa, e._capability.resolve(new cr(s, this));
    }), t.on("DocException", (s) => {
      e._capability.reject(ft(s));
    }), t.on("PasswordRequest", (s) => {
      this.#n = Promise.withResolvers();
      try {
        if (!e.onPassword)
          throw ft(s);
        const i = (n) => {
          n instanceof Error ? this.#n.reject(n) : this.#n.resolve({
            password: n
          });
        };
        e.onPassword(i, s.code);
      } catch (i) {
        this.#n.reject(i);
      }
      return this.#n.promise;
    }), t.on("DataLoaded", (s) => {
      this.#u({
        loaded: s.length,
        total: s.length
      }), this.downloadInfoCapability.resolve(s);
    }), t.on("StartRenderPage", (s) => {
      if (this.destroyed)
        return;
      this.#s.get(s.pageIndex)._startRenderPage(s.transparency, s.cacheKey);
    }), t.on("commonobj", ([s, i, n]) => {
      if (this.destroyed || this.commonObjs.has(s))
        return null;
      switch (i) {
        case "Font":
          if ("error" in n) {
            const c = n.error;
            R(`Error during font loading: ${c}`), this.commonObjs.resolve(s, c);
            break;
          }
          const r = new V(n), a = this._params.pdfBug && globalThis.FontInspector?.enabled ? (c, u) => globalThis.FontInspector.fontAdded(c, u) : null, o = new mn(r, a, n.extra, n.charProcOperatorList);
          this.fontLoader.bind(o).catch(() => t.sendWithPromise("FontFallback", {
            id: s
          })).finally(() => {
            !o.fontExtraProperties && o.data && o.clearData(), this.commonObjs.resolve(s, o);
          });
          break;
        case "CopyLocalImage":
          const {
            imageRef: l
          } = n;
          $(l, "The imageRef must be defined.");
          for (const c of this.#s.values())
            for (const [, u] of c.objs)
              if (u?.ref === l)
                return u.dataLen ? (this.commonObjs.resolve(s, structuredClone(u)), u.dataLen) : null;
          break;
        case "FontPath":
          this.commonObjs.resolve(s, new bn(n));
          break;
        case "Image":
          this.commonObjs.resolve(s, n);
          break;
        case "Pattern":
          const h = new at(n);
          this.commonObjs.resolve(s, h.getIR());
          break;
        default:
          throw new Error(`Got unknown common object type ${i}`);
      }
      return null;
    }), t.on("obj", ([s, i, n, r]) => {
      if (this.destroyed)
        return;
      const a = this.#s.get(i);
      if (!a.objs.has(s)) {
        if (a._intentStates.size === 0) {
          r?.bitmap?.close();
          return;
        }
        switch (n) {
          case "Image":
          case "Pattern":
            a.objs.resolve(s, r);
            break;
          default:
            throw new Error(`Got unknown object type ${n}`);
        }
      }
    }), t.on("DocProgress", (s) => {
      this.destroyed || this.#u(s);
    }), t.on("FetchBinaryData", async (s) => {
      if (this.destroyed)
        throw new Error("Worker was destroyed.");
      const i = this[s.type];
      if (!i)
        throw new Error(`${s.type} not initialized, see the \`useWorkerFetch\` parameter.`);
      return i.fetch(s);
    });
  }
  getData() {
    return this.messageHandler.sendWithPromise("GetData", null);
  }
  saveDocument() {
    this.annotationStorage.size <= 0 && R("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
    const {
      map: t,
      transfer: e
    } = this.annotationStorage.serializable;
    return this.messageHandler.sendWithPromise("SaveDocument", {
      isPureXfa: !!this._htmlForXfa,
      numPages: this._numPages,
      annotationStorage: t,
      filename: this.#t?.filename ?? null
    }, e).finally(() => {
      this.annotationStorage.resetModified();
    });
  }
  extractPages(t) {
    return this.messageHandler.sendWithPromise("ExtractPages", {
      pageInfos: t
    });
  }
  getPage(t) {
    if (!Number.isInteger(t) || t <= 0 || t > this.#o.pagesNumber)
      return Promise.reject(new Error("Invalid page request."));
    const e = t - 1, s = this.#o.getPageId(t) - 1, i = this.#a.get(e);
    if (i)
      return i;
    const n = this.messageHandler.sendWithPromise("GetPage", {
      pageIndex: s
    }).then((r) => {
      if (this.destroyed)
        throw new Error("Transport destroyed");
      r.refStr && this.#r.set(r.refStr, s);
      const a = new dr(e, r, this, this._params.pdfBug);
      return this.#s.set(e, a), a;
    });
    return this.#a.set(e, n), n;
  }
  async getPageIndex(t) {
    if (!cs(t))
      throw new Error("Invalid pageIndex request.");
    const e = await this.messageHandler.sendWithPromise("GetPageIndex", {
      num: t.num,
      gen: t.gen
    });
    return this.#o.getPageNumber(e + 1) - 1;
  }
  getAnnotations(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotations", {
      pageIndex: this.#o.getPageId(t + 1) - 1,
      intent: e
    });
  }
  getFieldObjects() {
    return this.#l("GetFieldObjects");
  }
  hasJSActions() {
    return this.#l("HasJSActions");
  }
  getCalculationOrderIds() {
    return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
  }
  getDestinations() {
    return this.messageHandler.sendWithPromise("GetDestinations", null);
  }
  getDestination(t) {
    return typeof t != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
      id: t
    });
  }
  getPageLabels() {
    return this.messageHandler.sendWithPromise("GetPageLabels", null);
  }
  getPageLayout() {
    return this.messageHandler.sendWithPromise("GetPageLayout", null);
  }
  getPageMode() {
    return this.messageHandler.sendWithPromise("GetPageMode", null);
  }
  getViewerPreferences() {
    return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
  }
  getOpenAction() {
    return this.messageHandler.sendWithPromise("GetOpenAction", null);
  }
  getAttachments() {
    return this.messageHandler.sendWithPromise("GetAttachments", null);
  }
  getAnnotationsByType(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotationsByType", {
      types: t,
      pageIndexesToSkip: e
    });
  }
  getDocJSActions() {
    return this.#l("GetDocJSActions");
  }
  getPageJSActions(t) {
    return this.messageHandler.sendWithPromise("GetPageJSActions", {
      pageIndex: this.#o.getPageId(t + 1) - 1
    });
  }
  getStructTree(t) {
    return this.messageHandler.sendWithPromise("GetStructTree", {
      pageIndex: this.#o.getPageId(t + 1) - 1
    });
  }
  getOutline() {
    return this.messageHandler.sendWithPromise("GetOutline", null);
  }
  getOptionalContentConfig(t) {
    return this.#l("GetOptionalContentConfig").then((e) => new Vn(e, t));
  }
  getPermissions() {
    return this.messageHandler.sendWithPromise("GetPermissions", null);
  }
  getMetadata() {
    const t = "GetMetadata", e = this.#e.get(t);
    if (e)
      return e;
    const s = this.messageHandler.sendWithPromise(t, null).then((i) => ({
      info: i[0],
      metadata: i[1] ? new zn(i[1]) : null,
      contentDispositionFilename: this.#t?.filename ?? null,
      contentLength: this.#t?.contentLength ?? null,
      hasStructTree: i[2]
    }));
    return this.#e.set(t, s), s;
  }
  getMarkInfo() {
    return this.messageHandler.sendWithPromise("GetMarkInfo", null);
  }
  async startCleanup(t = !1) {
    if (!this.destroyed) {
      await this.messageHandler.sendWithPromise("Cleanup", null);
      for (const e of this.#s.values())
        if (!e.cleanup())
          throw new Error(`startCleanup: Page ${e.pageNumber} is currently rendering.`);
      this.commonObjs.clear(), t || this.fontLoader.clear(), this.#e.clear(), this.filterFactory.destroy(!0), gt.cleanup();
    }
  }
  cachedPageNumber(t) {
    if (!cs(t))
      return null;
    const e = t.gen === 0 ? `${t.num}R` : `${t.num}R${t.gen}`, s = this.#r.get(e);
    return s >= 0 ? this.#o.getPageNumber(s + 1) : null;
  }
}
class fr {
  _internalRenderTask = null;
  onContinue = null;
  onError = null;
  constructor(t) {
    this._internalRenderTask = t;
  }
  get promise() {
    return this._internalRenderTask.capability.promise;
  }
  cancel(t = 0) {
    this._internalRenderTask.cancel(null, t);
  }
  get separateAnnots() {
    const {
      separateAnnots: t
    } = this._internalRenderTask.operatorList;
    if (!t)
      return !1;
    const {
      annotationCanvasMap: e
    } = this._internalRenderTask;
    return t.form || t.canvas && e?.size > 0;
  }
}
class qt {
  #t = null;
  static #e = /* @__PURE__ */ new WeakSet();
  constructor({
    callback: t,
    params: e,
    objs: s,
    commonObjs: i,
    annotationCanvasMap: n,
    operatorList: r,
    pageIndex: a,
    canvasFactory: o,
    filterFactory: l,
    useRequestAnimationFrame: h = !1,
    pdfBug: c = !1,
    pageColors: u = null,
    enableHWA: f = !1,
    operationsFilter: g = null
  }) {
    this.callback = t, this.params = e, this.objs = s, this.commonObjs = i, this.annotationCanvasMap = n, this.operatorListIdx = null, this.operatorList = r, this._pageIndex = a, this.canvasFactory = o, this.filterFactory = l, this._pdfBug = c, this.pageColors = u, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = h === !0 && typeof window < "u", this.cancelled = !1, this.capability = Promise.withResolvers(), this.task = new fr(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = e.canvas, this._canvasContext = e.canvas ? null : e.canvasContext, this._enableHWA = f, this._dependencyTracker = e.dependencyTracker, this._operationsFilter = g;
  }
  get completed() {
    return this.capability.promise.catch(function() {
    });
  }
  initializeGraphics({
    transparency: t = !1,
    optionalContentConfig: e
  }) {
    if (this.cancelled)
      return;
    if (this._canvas) {
      if (qt.#e.has(this._canvas))
        throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
      qt.#e.add(this._canvas);
    }
    this._pdfBug && globalThis.StepperManager?.enabled && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint());
    const {
      viewport: s,
      transform: i,
      background: n,
      dependencyTracker: r
    } = this.params, a = this._canvasContext || this._canvas.getContext("2d", {
      alpha: !1,
      willReadFrequently: !this._enableHWA
    });
    this.gfx = new Jt(a, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
      optionalContentConfig: e
    }, this.annotationCanvasMap, this.pageColors, r), this.gfx.beginDrawing({
      transform: i,
      viewport: s,
      transparency: t,
      background: n
    }), this.operatorListIdx = 0, this.graphicsReady = !0, this.graphicsReadyCallback?.();
  }
  cancel(t = null, e = 0) {
    this.running = !1, this.cancelled = !0, this.gfx?.endDrawing(), this.#t && (window.cancelAnimationFrame(this.#t), this.#t = null), qt.#e.delete(this._canvas), t ||= new $e(`Rendering cancelled, page ${this._pageIndex + 1}`, e), this.callback(t), this.task.onError?.(t);
  }
  operatorListChanged() {
    if (!this.graphicsReady) {
      this.graphicsReadyCallback ||= this._continueBound;
      return;
    }
    this.gfx.dependencyTracker?.growOperationsCount(this.operatorList.fnArray.length), this.stepper?.updateOperatorList(this.operatorList), !this.running && this._continue();
  }
  _continue() {
    this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
  }
  _scheduleNext() {
    this._useRequestAnimationFrame ? this.#t = window.requestAnimationFrame(() => {
      this.#t = null, this._nextBound().catch(this._cancelBound);
    }) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
  }
  async _next() {
    this.cancelled || (this.operatorListIdx = this.gfx.executeOperatorList(this.operatorList, this.operatorListIdx, this._continueBound, this.stepper, this._operationsFilter), this.operatorListIdx === this.operatorList.argsArray.length && (this.running = !1, this.operatorList.lastChunk && (this.gfx.endDrawing(), qt.#e.delete(this._canvas), this.callback())));
  }
}
const Hi = "5.4.624", $i = "384c6208b";
class At {
  #t = null;
  #e = null;
  #i;
  #s = null;
  #a = !1;
  #r = !1;
  #n = null;
  #o;
  #h = null;
  #l = null;
  static #u = null;
  static get _keyboardManager() {
    return I(this, "_keyboardManager", new Se([[["Escape", "mac+Escape"], At.prototype._hideDropdownFromKeyboard], [[" ", "mac+ "], At.prototype._colorSelectFromKeyboard], [["ArrowDown", "ArrowRight", "mac+ArrowDown", "mac+ArrowRight"], At.prototype._moveToNext], [["ArrowUp", "ArrowLeft", "mac+ArrowUp", "mac+ArrowLeft"], At.prototype._moveToPrevious], [["Home", "mac+Home"], At.prototype._moveToBeginning], [["End", "mac+End"], At.prototype._moveToEnd]]));
  }
  constructor({
    editor: t = null,
    uiManager: e = null
  }) {
    t ? (this.#r = !1, this.#n = t) : this.#r = !0, this.#l = t?._uiManager || e, this.#o = this.#l._eventBus, this.#i = t?.color?.toUpperCase() || this.#l?.highlightColors.values().next().value || "#FFFF98", At.#u ||= Object.freeze({
      blue: "pdfjs-editor-colorpicker-blue",
      green: "pdfjs-editor-colorpicker-green",
      pink: "pdfjs-editor-colorpicker-pink",
      red: "pdfjs-editor-colorpicker-red",
      yellow: "pdfjs-editor-colorpicker-yellow"
    });
  }
  renderButton() {
    const t = this.#t = document.createElement("button");
    t.className = "colorPicker", t.tabIndex = "0", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-button"), t.ariaHasPopup = "true", this.#n && (t.ariaControls = `${this.#n.id}_colorpicker_dropdown`);
    const e = this.#l._signal;
    t.addEventListener("click", this.#g.bind(this), {
      signal: e
    }), t.addEventListener("keydown", this.#m.bind(this), {
      signal: e
    });
    const s = this.#e = document.createElement("span");
    return s.className = "swatch", s.ariaHidden = "true", s.style.backgroundColor = this.#i, t.append(s), t;
  }
  renderMainDropdown() {
    const t = this.#s = this.#d();
    return t.ariaOrientation = "horizontal", t.ariaLabelledBy = "highlightColorPickerLabel", t;
  }
  #d() {
    const t = document.createElement("div"), e = this.#l._signal;
    t.addEventListener("contextmenu", wt, {
      signal: e
    }), t.className = "dropdown", t.role = "listbox", t.ariaMultiSelectable = "false", t.ariaOrientation = "vertical", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-dropdown"), this.#n && (t.id = `${this.#n.id}_colorpicker_dropdown`);
    for (const [s, i] of this.#l.highlightColors) {
      const n = document.createElement("button");
      n.tabIndex = "0", n.role = "option", n.setAttribute("data-color", i), n.title = s, n.setAttribute("data-l10n-id", At.#u[s]);
      const r = document.createElement("span");
      n.append(r), r.className = "swatch", r.style.backgroundColor = i, n.ariaSelected = i === this.#i, n.addEventListener("click", this.#f.bind(this, i), {
        signal: e
      }), t.append(n);
    }
    return t.addEventListener("keydown", this.#m.bind(this), {
      signal: e
    }), t;
  }
  #f(t, e) {
    e.stopPropagation(), this.#o.dispatch("switchannotationeditorparams", {
      source: this,
      type: N.HIGHLIGHT_COLOR,
      value: t
    }), this.updateColor(t);
  }
  _colorSelectFromKeyboard(t) {
    if (t.target === this.#t) {
      this.#g(t);
      return;
    }
    const e = t.target.getAttribute("data-color");
    e && this.#f(e, t);
  }
  _moveToNext(t) {
    if (!this.#p) {
      this.#g(t);
      return;
    }
    if (t.target === this.#t) {
      this.#s.firstElementChild?.focus();
      return;
    }
    t.target.nextSibling?.focus();
  }
  _moveToPrevious(t) {
    if (t.target === this.#s?.firstElementChild || t.target === this.#t) {
      this.#p && this._hideDropdownFromKeyboard();
      return;
    }
    this.#p || this.#g(t), t.target.previousSibling?.focus();
  }
  _moveToBeginning(t) {
    if (!this.#p) {
      this.#g(t);
      return;
    }
    this.#s.firstElementChild?.focus();
  }
  _moveToEnd(t) {
    if (!this.#p) {
      this.#g(t);
      return;
    }
    this.#s.lastElementChild?.focus();
  }
  #m(t) {
    At._keyboardManager.exec(this, t);
  }
  #g(t) {
    if (this.#p) {
      this.hideDropdown();
      return;
    }
    if (this.#a = t.detail === 0, this.#h || (this.#h = new AbortController(), window.addEventListener("pointerdown", this.#c.bind(this), {
      signal: this.#l.combinedSignal(this.#h)
    })), this.#t.ariaExpanded = "true", this.#s) {
      this.#s.classList.remove("hidden");
      return;
    }
    const e = this.#s = this.#d();
    this.#t.append(e);
  }
  #c(t) {
    this.#s?.contains(t.target) || this.hideDropdown();
  }
  hideDropdown() {
    this.#s?.classList.add("hidden"), this.#t.ariaExpanded = "false", this.#h?.abort(), this.#h = null;
  }
  get #p() {
    return this.#s && !this.#s.classList.contains("hidden");
  }
  _hideDropdownFromKeyboard() {
    if (!this.#r) {
      if (!this.#p) {
        this.#n?.unselect();
        return;
      }
      this.hideDropdown(), this.#t.focus({
        preventScroll: !0,
        focusVisible: this.#a
      });
    }
  }
  updateColor(t) {
    if (this.#e && (this.#e.style.backgroundColor = t), !this.#s)
      return;
    const e = this.#l.highlightColors.values();
    for (const s of this.#s.children)
      s.ariaSelected = e.next().value === t.toUpperCase();
  }
  destroy() {
    this.#t?.remove(), this.#t = null, this.#e = null, this.#s?.remove(), this.#s = null;
  }
}
class be {
  #t = null;
  #e = null;
  #i = null;
  static #s = null;
  constructor(t) {
    this.#e = t, this.#i = t._uiManager, be.#s ||= Object.freeze({
      freetext: "pdfjs-editor-color-picker-free-text-input",
      ink: "pdfjs-editor-color-picker-ink-input"
    });
  }
  renderButton() {
    if (this.#t)
      return this.#t;
    const {
      editorType: t,
      colorType: e,
      color: s
    } = this.#e, i = this.#t = document.createElement("input");
    return i.type = "color", i.value = s || "#000000", i.className = "basicColorPicker", i.tabIndex = 0, i.setAttribute("data-l10n-id", be.#s[t]), i.addEventListener("input", () => {
      this.#i.updateParams(e, i.value);
    }, {
      signal: this.#i._signal
    }), i;
  }
  update(t) {
    this.#t && (this.#t.value = t);
  }
  destroy() {
    this.#t?.remove(), this.#t = null;
  }
  hideDropdown() {
  }
}
function li(d) {
  return Math.floor(Math.max(0, Math.min(1, d)) * 255).toString(16).padStart(2, "0");
}
function le(d) {
  return Math.max(0, Math.min(255, 255 * d));
}
class hi {
  static CMYK_G([t, e, s, i]) {
    return ["G", 1 - Math.min(1, 0.3 * t + 0.59 * s + 0.11 * e + i)];
  }
  static G_CMYK([t]) {
    return ["CMYK", 0, 0, 0, 1 - t];
  }
  static G_RGB([t]) {
    return ["RGB", t, t, t];
  }
  static G_rgb([t]) {
    return t = le(t), [t, t, t];
  }
  static G_HTML([t]) {
    const e = li(t);
    return `#${e}${e}${e}`;
  }
  static RGB_G([t, e, s]) {
    return ["G", 0.3 * t + 0.59 * e + 0.11 * s];
  }
  static RGB_rgb(t) {
    return t.map(le);
  }
  static RGB_HTML(t) {
    return `#${t.map(li).join("")}`;
  }
  static T_HTML() {
    return "#00000000";
  }
  static T_rgb() {
    return [null];
  }
  static CMYK_RGB([t, e, s, i]) {
    return ["RGB", 1 - Math.min(1, t + i), 1 - Math.min(1, s + i), 1 - Math.min(1, e + i)];
  }
  static CMYK_rgb([t, e, s, i]) {
    return [le(1 - Math.min(1, t + i)), le(1 - Math.min(1, s + i)), le(1 - Math.min(1, e + i))];
  }
  static CMYK_HTML(t) {
    const e = this.CMYK_RGB(t).slice(1);
    return this.RGB_HTML(e);
  }
  static RGB_CMYK([t, e, s]) {
    const i = 1 - t, n = 1 - e, r = 1 - s, a = Math.min(i, n, r);
    return ["CMYK", i, n, r, a];
  }
}
class pr {
  create(t, e, s = !1) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid SVG dimensions");
    const i = this._createSVG("svg:svg");
    return i.setAttribute("version", "1.1"), s || (i.setAttribute("width", `${t}px`), i.setAttribute("height", `${e}px`)), i.setAttribute("preserveAspectRatio", "none"), i.setAttribute("viewBox", `0 0 ${t} ${e}`), i;
  }
  createElement(t) {
    if (typeof t != "string")
      throw new Error("Invalid SVG element type");
    return this._createSVG(t);
  }
  _createSVG(t) {
    j("Abstract method `_createSVG` called.");
  }
}
class Ae extends pr {
  _createSVG(t) {
    return document.createElementNS(Mt, t);
  }
}
const gr = 9, $t = /* @__PURE__ */ new WeakSet(), mr = (/* @__PURE__ */ new Date()).getTimezoneOffset() * 60 * 1e3;
class rs {
  static create(t) {
    switch (t.data.annotationType) {
      case J.LINK:
        return new Ms(t);
      case J.TEXT:
        return new Ar(t);
      case J.WIDGET:
        switch (t.data.fieldType) {
          case "Tx":
            return new yr(t);
          case "Btn":
            return t.data.radioButton ? new ji(t) : t.data.checkBox ? new vr(t) : new Sr(t);
          case "Ch":
            return new Er(t);
          case "Sig":
            return new wr(t);
        }
        return new zt(t);
      case J.POPUP:
        return new fs(t);
      case J.FREETEXT:
        return new zi(t);
      case J.LINE:
        return new Cr(t);
      case J.SQUARE:
        return new Tr(t);
      case J.CIRCLE:
        return new xr(t);
      case J.POLYLINE:
        return new Gi(t);
      case J.CARET:
        return new kr(t);
      case J.INK:
        return new Ds(t);
      case J.POLYGON:
        return new Pr(t);
      case J.HIGHLIGHT:
        return new Vi(t);
      case J.UNDERLINE:
        return new Mr(t);
      case J.SQUIGGLY:
        return new Dr(t);
      case J.STRIKEOUT:
        return new Lr(t);
      case J.STAMP:
        return new Wi(t);
      case J.FILEATTACHMENT:
        return new Ir(t);
      default:
        return new Q(t);
    }
  }
}
class Q {
  #t = null;
  #e = !1;
  #i = null;
  constructor(t, {
    isRenderable: e = !1,
    ignoreBorder: s = !1,
    createQuadrilaterals: i = !1
  } = {}) {
    this.isRenderable = e, this.data = t.data, this.layer = t.layer, this.linkService = t.linkService, this.downloadManager = t.downloadManager, this.imageResourcesPath = t.imageResourcesPath, this.renderForms = t.renderForms, this.svgFactory = t.svgFactory, this.annotationStorage = t.annotationStorage, this.enableComment = t.enableComment, this.enableScripting = t.enableScripting, this.hasJSActions = t.hasJSActions, this._fieldObjects = t.fieldObjects, this.parent = t.parent, this.hasOwnCommentButton = !1, e && (this.contentElement = this.container = this._createContainer(s)), i && this._createQuadrilaterals();
  }
  static _hasPopupData({
    contentsObj: t,
    richText: e
  }) {
    return !!(t?.str || e?.str);
  }
  get _isEditable() {
    return this.data.isEditable;
  }
  get hasPopupData() {
    return Q._hasPopupData(this.data) || this.enableComment && !!this.commentText;
  }
  get commentData() {
    const {
      data: t
    } = this, e = this.annotationStorage?.getEditor(t.id);
    return e ? e.getData() : t;
  }
  get hasCommentButton() {
    return this.enableComment && this.hasPopupElement;
  }
  get commentButtonPosition() {
    const t = this.annotationStorage?.getEditor(this.data.id);
    if (t)
      return t.commentButtonPositionInPage;
    const {
      quadPoints: e,
      inkLists: s,
      rect: i
    } = this.data;
    let n = -1 / 0, r = -1 / 0;
    if (e?.length >= 8) {
      for (let a = 0; a < e.length; a += 8)
        e[a + 1] > r ? (r = e[a + 1], n = e[a + 2]) : e[a + 1] === r && (n = Math.max(n, e[a + 2]));
      return [n, r];
    }
    if (s?.length >= 1) {
      for (const a of s)
        for (let o = 0, l = a.length; o < l; o += 2)
          a[o + 1] > r ? (r = a[o + 1], n = a[o]) : a[o + 1] === r && (n = Math.max(n, a[o]));
      if (n !== 1 / 0)
        return [n, r];
    }
    return i ? [i[2], i[3]] : null;
  }
  _normalizePoint(t) {
    const {
      page: {
        view: e
      },
      viewport: {
        rawDims: {
          pageWidth: s,
          pageHeight: i,
          pageX: n,
          pageY: r
        }
      }
    } = this.parent;
    return t[1] = e[3] - t[1] + e[1], t[0] = 100 * (t[0] - n) / s, t[1] = 100 * (t[1] - r) / i, t;
  }
  get commentText() {
    const {
      data: t
    } = this;
    return this.annotationStorage.getRawValue(`${pe}${t.id}`)?.popup?.contents || t.contentsObj?.str || "";
  }
  set commentText(t) {
    const {
      data: e
    } = this, s = {
      deleted: !t,
      contents: t || ""
    };
    this.annotationStorage.updateEditor(e.id, {
      popup: s
    }) || this.annotationStorage.setValue(`${pe}${e.id}`, {
      id: e.id,
      annotationType: e.annotationType,
      page: this.parent.page,
      popup: s,
      popupRef: e.popupRef,
      modificationDate: /* @__PURE__ */ new Date()
    }), t || this.removePopup();
  }
  removePopup() {
    (this.#i?.popup || this.popup)?.remove(), this.#i = this.popup = null;
  }
  updateEdited(t) {
    if (!this.container)
      return;
    t.rect && (this.#t ||= {
      rect: this.data.rect.slice(0)
    });
    const {
      rect: e,
      popup: s
    } = t;
    e && this.#s(e);
    let i = this.#i?.popup || this.popup;
    !i && s?.text && (this._createPopup(s), i = this.#i.popup), i && (i.updateEdited(t), s?.deleted && (i.remove(), this.#i = null, this.popup = null));
  }
  resetEdited() {
    this.#t && (this.#s(this.#t.rect), this.#i?.popup.resetEdited(), this.#t = null);
  }
  #s(t) {
    const {
      container: {
        style: e
      },
      data: {
        rect: s,
        rotation: i
      },
      parent: {
        viewport: {
          rawDims: {
            pageWidth: n,
            pageHeight: r,
            pageX: a,
            pageY: o
          }
        }
      }
    } = this;
    s?.splice(0, 4, ...t), e.left = `${100 * (t[0] - a) / n}%`, e.top = `${100 * (r - t[3] + o) / r}%`, i === 0 ? (e.width = `${100 * (t[2] - t[0]) / n}%`, e.height = `${100 * (t[3] - t[1]) / r}%`) : this.setRotation(i);
  }
  _createContainer(t) {
    const {
      data: e,
      parent: {
        page: s,
        viewport: i
      }
    } = this, n = document.createElement("section");
    n.setAttribute("data-annotation-id", e.id), !(this instanceof zt) && !(this instanceof Ms) && (n.tabIndex = 0);
    const {
      style: r
    } = n;
    if (r.zIndex = this.parent.zIndex, this.parent.zIndex += 2, e.alternativeText && (n.title = e.alternativeText), e.noRotate && n.classList.add("norotate"), !e.rect || this instanceof fs) {
      const {
        rotation: p
      } = e;
      return !e.hasOwnCanvas && p !== 0 && this.setRotation(p, n), n;
    }
    const {
      width: a,
      height: o
    } = this;
    if (!t && e.borderStyle.width > 0) {
      r.borderWidth = `${e.borderStyle.width}px`;
      const p = e.borderStyle.horizontalCornerRadius, b = e.borderStyle.verticalCornerRadius;
      if (p > 0 || b > 0) {
        const y = `calc(${p}px * var(--total-scale-factor)) / calc(${b}px * var(--total-scale-factor))`;
        r.borderRadius = y;
      } else if (this instanceof ji) {
        const y = `calc(${a}px * var(--total-scale-factor)) / calc(${o}px * var(--total-scale-factor))`;
        r.borderRadius = y;
      }
      switch (e.borderStyle.style) {
        case Vt.SOLID:
          r.borderStyle = "solid";
          break;
        case Vt.DASHED:
          r.borderStyle = "dashed";
          break;
        case Vt.BEVELED:
          R("Unimplemented border style: beveled");
          break;
        case Vt.INSET:
          R("Unimplemented border style: inset");
          break;
        case Vt.UNDERLINE:
          r.borderBottomStyle = "solid";
          break;
      }
      const m = e.borderColor || null;
      m ? (this.#e = !0, r.borderColor = T.makeHexColor(m[0] | 0, m[1] | 0, m[2] | 0)) : r.borderWidth = 0;
    }
    const l = T.normalizeRect([e.rect[0], s.view[3] - e.rect[1] + s.view[1], e.rect[2], s.view[3] - e.rect[3] + s.view[1]]), {
      pageWidth: h,
      pageHeight: c,
      pageX: u,
      pageY: f
    } = i.rawDims;
    r.left = `${100 * (l[0] - u) / h}%`, r.top = `${100 * (l[1] - f) / c}%`;
    const {
      rotation: g
    } = e;
    return e.hasOwnCanvas || g === 0 ? (r.width = `${100 * a / h}%`, r.height = `${100 * o / c}%`) : this.setRotation(g, n), n;
  }
  setRotation(t, e = this.container) {
    if (!this.data.rect)
      return;
    const {
      pageWidth: s,
      pageHeight: i
    } = this.parent.viewport.rawDims;
    let {
      width: n,
      height: r
    } = this;
    t % 180 !== 0 && ([n, r] = [r, n]), e.style.width = `${100 * n / s}%`, e.style.height = `${100 * r / i}%`, e.setAttribute("data-main-rotation", (360 - t) % 360);
  }
  get _commonActions() {
    const t = (e, s, i) => {
      const n = i.detail[e], r = n[0], a = n.slice(1);
      i.target.style[s] = hi[`${r}_HTML`](a), this.annotationStorage.setValue(this.data.id, {
        [s]: hi[`${r}_rgb`](a)
      });
    };
    return I(this, "_commonActions", {
      display: (e) => {
        const {
          display: s
        } = e.detail, i = s % 2 === 1;
        this.container.style.visibility = i ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noView: i,
          noPrint: s === 1 || s === 2
        });
      },
      print: (e) => {
        this.annotationStorage.setValue(this.data.id, {
          noPrint: !e.detail.print
        });
      },
      hidden: (e) => {
        const {
          hidden: s
        } = e.detail;
        this.container.style.visibility = s ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noPrint: s,
          noView: s
        });
      },
      focus: (e) => {
        setTimeout(() => e.target.focus({
          preventScroll: !1
        }), 0);
      },
      userName: (e) => {
        e.target.title = e.detail.userName;
      },
      readonly: (e) => {
        e.target.disabled = e.detail.readonly;
      },
      required: (e) => {
        this._setRequired(e.target, e.detail.required);
      },
      bgColor: (e) => {
        t("bgColor", "backgroundColor", e);
      },
      fillColor: (e) => {
        t("fillColor", "backgroundColor", e);
      },
      fgColor: (e) => {
        t("fgColor", "color", e);
      },
      textColor: (e) => {
        t("textColor", "color", e);
      },
      borderColor: (e) => {
        t("borderColor", "borderColor", e);
      },
      strokeColor: (e) => {
        t("strokeColor", "borderColor", e);
      },
      rotation: (e) => {
        const s = e.detail.rotation;
        this.setRotation(s), this.annotationStorage.setValue(this.data.id, {
          rotation: s
        });
      }
    });
  }
  _dispatchEventFromSandbox(t, e) {
    const s = this._commonActions;
    for (const i of Object.keys(e.detail))
      (t[i] || s[i])?.(e);
  }
  _setDefaultPropertiesFromJS(t) {
    if (!this.enableScripting)
      return;
    const e = this.annotationStorage.getRawValue(this.data.id);
    if (!e)
      return;
    const s = this._commonActions;
    for (const [i, n] of Object.entries(e)) {
      const r = s[i];
      if (r) {
        const a = {
          detail: {
            [i]: n
          },
          target: t
        };
        r(a), delete e[i];
      }
    }
  }
  _createQuadrilaterals() {
    if (!this.container)
      return;
    const {
      quadPoints: t
    } = this.data;
    if (!t)
      return;
    const [e, s, i, n] = this.data.rect.map((p) => Math.fround(p));
    if (t.length === 8) {
      const [p, b, m, y] = t.subarray(2, 6);
      if (i === p && n === b && e === m && s === y)
        return;
    }
    const {
      style: r
    } = this.container;
    let a;
    if (this.#e) {
      const {
        borderColor: p,
        borderWidth: b
      } = r;
      r.borderWidth = 0, a = ["url('data:image/svg+xml;utf8,", '<svg xmlns="http://www.w3.org/2000/svg"', ' preserveAspectRatio="none" viewBox="0 0 1 1">', `<g fill="transparent" stroke="${p}" stroke-width="${b}">`], this.container.classList.add("hasBorder");
    }
    const o = i - e, l = n - s, {
      svgFactory: h
    } = this, c = h.createElement("svg");
    c.classList.add("quadrilateralsContainer"), c.setAttribute("width", 0), c.setAttribute("height", 0), c.role = "none";
    const u = h.createElement("defs");
    c.append(u);
    const f = h.createElement("clipPath"), g = `clippath_${this.data.id}`;
    f.setAttribute("id", g), f.setAttribute("clipPathUnits", "objectBoundingBox"), u.append(f);
    for (let p = 2, b = t.length; p < b; p += 8) {
      const m = t[p], y = t[p + 1], A = t[p + 2], v = t[p + 3], w = h.createElement("rect"), S = (A - e) / o, E = (n - y) / l, _ = (m - A) / o, C = (y - v) / l;
      w.setAttribute("x", S), w.setAttribute("y", E), w.setAttribute("width", _), w.setAttribute("height", C), f.append(w), a?.push(`<rect vector-effect="non-scaling-stroke" x="${S}" y="${E}" width="${_}" height="${C}"/>`);
    }
    this.#e && (a.push("</g></svg>')"), r.backgroundImage = a.join("")), this.container.append(c), this.container.style.clipPath = `url(#${g})`;
  }
  _createPopup(t = null) {
    const {
      data: e
    } = this;
    let s, i;
    t ? (s = {
      str: t.text
    }, i = t.date) : (s = e.contentsObj, i = e.modificationDate), this.#i = new fs({
      data: {
        color: e.color,
        titleObj: e.titleObj,
        modificationDate: i,
        contentsObj: s,
        richText: e.richText,
        parentRect: e.rect,
        borderStyle: 0,
        id: `popup_${e.id}`,
        rotation: e.rotation,
        noRotate: !0
      },
      linkService: this.linkService,
      parent: this.parent,
      elements: [this]
    });
  }
  get hasPopupElement() {
    return !!(this.#i || this.popup || this.data.popupRef);
  }
  get extraPopupElement() {
    return this.#i;
  }
  render() {
    j("Abstract method `AnnotationElement.render` called");
  }
  _getElementsByName(t, e = null) {
    const s = [];
    if (this._fieldObjects) {
      const i = this._fieldObjects[t];
      if (i)
        for (const {
          page: n,
          id: r,
          exportValues: a
        } of i) {
          if (n === -1 || r === e)
            continue;
          const o = typeof a == "string" ? a : null, l = document.querySelector(`[data-element-id="${r}"]`);
          if (l && !$t.has(l)) {
            R(`_getElementsByName - element not allowed: ${r}`);
            continue;
          }
          s.push({
            id: r,
            exportValue: o,
            domElement: l
          });
        }
      return s;
    }
    for (const i of document.getElementsByName(t)) {
      const {
        exportValue: n
      } = i, r = i.getAttribute("data-element-id");
      r !== e && $t.has(i) && s.push({
        id: r,
        exportValue: n,
        domElement: i
      });
    }
    return s;
  }
  show() {
    this.container && (this.container.hidden = !1), this.popup?.maybeShow();
  }
  hide() {
    this.container && (this.container.hidden = !0), this.popup?.forceHide();
  }
  getElementsToTriggerPopup() {
    return this.container;
  }
  addHighlightArea() {
    const t = this.getElementsToTriggerPopup();
    if (Array.isArray(t))
      for (const e of t)
        e.classList.add("highlightArea");
    else
      t.classList.add("highlightArea");
  }
  _editOnDoubleClick() {
    if (!this._isEditable)
      return;
    const {
      annotationEditorType: t,
      data: {
        id: e
      }
    } = this;
    this.container.addEventListener("dblclick", () => {
      this.linkService.eventBus?.dispatch("switchannotationeditormode", {
        source: this,
        mode: t,
        editId: e,
        mustEnterInEditMode: !0
      });
    });
  }
  get width() {
    return this.data.rect[2] - this.data.rect[0];
  }
  get height() {
    return this.data.rect[3] - this.data.rect[1];
  }
}
class br extends Q {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.editor = t.editor;
  }
  render() {
    return this.container.className = "editorAnnotation", this.container;
  }
  createOrUpdatePopup() {
    const {
      editor: t
    } = this;
    t.hasComment && this._createPopup(t.comment);
  }
  get hasCommentButton() {
    return this.enableComment && this.editor.hasComment;
  }
  get commentButtonPosition() {
    return this.editor.commentButtonPositionInPage;
  }
  get commentText() {
    return this.editor.comment.text;
  }
  set commentText(t) {
    this.editor.comment = t, t || this.removePopup();
  }
  get commentData() {
    return this.editor.getData();
  }
  remove() {
    this.parent.removeAnnotation(this.data.id), this.container.remove(), this.container = null, this.removePopup();
  }
}
class Ms extends Q {
  constructor(t, e = null) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !!e?.ignoreBorder,
      createQuadrilaterals: !0
    }), this.isTooltipOnly = t.data.isTooltipOnly;
  }
  render() {
    const {
      data: t,
      linkService: e
    } = this, s = document.createElement("a");
    s.setAttribute("data-element-id", t.id);
    let i = !1;
    return t.url ? (e.addLinkAttributes(s, t.url, t.newWindow), i = !0) : t.action ? (this._bindNamedAction(s, t.action, t.overlaidText), i = !0) : t.attachment ? (this.#e(s, t.attachment, t.overlaidText, t.attachmentDest), i = !0) : t.setOCGState ? (this.#i(s, t.setOCGState, t.overlaidText), i = !0) : t.dest ? (this._bindLink(s, t.dest, t.overlaidText), i = !0) : (t.actions && (t.actions.Action || t.actions["Mouse Up"] || t.actions["Mouse Down"]) && this.enableScripting && this.hasJSActions && (this._bindJSAction(s, t), i = !0), t.resetForm ? (this._bindResetFormAction(s, t.resetForm), i = !0) : this.isTooltipOnly && !i && (this._bindLink(s, ""), i = !0)), this.container.classList.add("linkAnnotation"), i && (this.contentElement = s, this.container.append(s)), this.container;
  }
  #t() {
    this.container.setAttribute("data-internal-link", "");
  }
  _bindLink(t, e, s = "") {
    t.href = this.linkService.getDestinationHash(e), t.onclick = () => (e && this.linkService.goToDestination(e), !1), (e || e === "") && this.#t(), s && (t.title = s);
  }
  _bindNamedAction(t, e, s = "") {
    t.href = this.linkService.getAnchorUrl(""), t.onclick = () => (this.linkService.executeNamedAction(e), !1), s && (t.title = s), this.#t();
  }
  #e(t, e, s = "", i = null) {
    t.href = this.linkService.getAnchorUrl(""), e.description ? t.title = e.description : s && (t.title = s), t.onclick = () => (this.downloadManager?.openOrDownloadData(e.content, e.filename, i), !1), this.#t();
  }
  #i(t, e, s = "") {
    t.href = this.linkService.getAnchorUrl(""), t.onclick = () => (this.linkService.executeSetOCGState(e), !1), s && (t.title = s), this.#t();
  }
  _bindJSAction(t, e) {
    t.href = this.linkService.getAnchorUrl("");
    const s = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
    for (const i of Object.keys(e.actions)) {
      const n = s.get(i);
      n && (t[n] = () => (this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: e.id,
          name: i
        }
      }), !1));
    }
    e.overlaidText && (t.title = e.overlaidText), t.onclick || (t.onclick = () => !1), this.#t();
  }
  _bindResetFormAction(t, e) {
    const s = t.onclick;
    if (s || (t.href = this.linkService.getAnchorUrl("")), this.#t(), !this._fieldObjects) {
      R('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), s || (t.onclick = () => !1);
      return;
    }
    t.onclick = () => {
      s?.();
      const {
        fields: i,
        refs: n,
        include: r
      } = e, a = [];
      if (i.length !== 0 || n.length !== 0) {
        const h = new Set(n);
        for (const c of i) {
          const u = this._fieldObjects[c] || [];
          for (const {
            id: f
          } of u)
            h.add(f);
        }
        for (const c of Object.values(this._fieldObjects))
          for (const u of c)
            h.has(u.id) === r && a.push(u);
      } else
        for (const h of Object.values(this._fieldObjects))
          a.push(...h);
      const o = this.annotationStorage, l = [];
      for (const h of a) {
        const {
          id: c
        } = h;
        switch (l.push(c), h.type) {
          case "text": {
            const f = h.defaultValue || "";
            o.setValue(c, {
              value: f
            });
            break;
          }
          case "checkbox":
          case "radiobutton": {
            const f = h.defaultValue === h.exportValues;
            o.setValue(c, {
              value: f
            });
            break;
          }
          case "combobox":
          case "listbox": {
            const f = h.defaultValue || "";
            o.setValue(c, {
              value: f
            });
            break;
          }
          default:
            continue;
        }
        const u = document.querySelector(`[data-element-id="${c}"]`);
        if (u) {
          if (!$t.has(u)) {
            R(`_bindResetFormAction - element not allowed: ${c}`);
            continue;
          }
        } else continue;
        u.dispatchEvent(new Event("resetform"));
      }
      return this.enableScripting && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: "app",
          ids: l,
          name: "ResetForm"
        }
      }), !1;
    };
  }
}
class Ar extends Q {
  constructor(t) {
    super(t, {
      isRenderable: !0
    });
  }
  render() {
    this.container.classList.add("textAnnotation");
    const t = document.createElement("img");
    return t.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", t.setAttribute("data-l10n-id", "pdfjs-text-annotation-type"), t.setAttribute("data-l10n-args", JSON.stringify({
      type: this.data.name
    })), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.append(t), this.container;
  }
}
class zt extends Q {
  render() {
    return this.container;
  }
  showElementAndHideCanvas(t) {
    this.data.hasOwnCanvas && (t.previousSibling?.nodeName === "CANVAS" && (t.previousSibling.hidden = !0), t.hidden = !1);
  }
  _getKeyModifier(t) {
    return nt.platform.isMac ? t.metaKey : t.ctrlKey;
  }
  _setEventListener(t, e, s, i, n) {
    s.includes("mouse") ? t.addEventListener(s, (r) => {
      this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: i,
          value: n(r),
          shift: r.shiftKey,
          modifier: this._getKeyModifier(r)
        }
      });
    }) : t.addEventListener(s, (r) => {
      if (s === "blur") {
        if (!e.focused || !r.relatedTarget)
          return;
        e.focused = !1;
      } else if (s === "focus") {
        if (e.focused)
          return;
        e.focused = !0;
      }
      n && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: i,
          value: n(r)
        }
      });
    });
  }
  _setEventListeners(t, e, s, i) {
    for (const [n, r] of s)
      (r === "Action" || this.data.actions?.[r]) && ((r === "Focus" || r === "Blur") && (e ||= {
        focused: !1
      }), this._setEventListener(t, e, n, r, i), r === "Focus" && !this.data.actions?.Blur ? this._setEventListener(t, e, "blur", "Blur", null) : r === "Blur" && !this.data.actions?.Focus && this._setEventListener(t, e, "focus", "Focus", null));
  }
  _setBackgroundColor(t) {
    const e = this.data.backgroundColor || null;
    t.style.backgroundColor = e === null ? "transparent" : T.makeHexColor(e[0], e[1], e[2]);
  }
  _setTextStyle(t) {
    const e = ["left", "center", "right"], {
      fontColor: s
    } = this.data.defaultAppearanceData, i = this.data.defaultAppearanceData.fontSize || gr, n = t.style;
    let r;
    const a = 2, o = (l) => Math.round(10 * l) / 10;
    if (this.data.multiLine) {
      const l = Math.abs(this.data.rect[3] - this.data.rect[1] - a), h = Math.round(l / (Je * i)) || 1, c = l / h;
      r = Math.min(i, o(c / Je));
    } else {
      const l = Math.abs(this.data.rect[3] - this.data.rect[1] - a);
      r = Math.min(i, o(l / Je));
    }
    n.fontSize = `calc(${r}px * var(--total-scale-factor))`, n.color = T.makeHexColor(s[0], s[1], s[2]), this.data.textAlignment !== null && (n.textAlign = e[this.data.textAlignment]);
  }
  _setRequired(t, e) {
    e ? t.setAttribute("required", !0) : t.removeAttribute("required"), t.setAttribute("aria-required", e);
  }
}
class yr extends zt {
  constructor(t) {
    const e = t.renderForms || t.data.hasOwnCanvas || !t.data.hasAppearance && !!t.data.fieldValue;
    super(t, {
      isRenderable: e
    });
  }
  setPropertyOnSiblings(t, e, s, i) {
    const n = this.annotationStorage;
    for (const r of this._getElementsByName(t.name, t.id))
      r.domElement && (r.domElement[e] = s), n.setValue(r.id, {
        [i]: s
      });
  }
  render() {
    const t = this.annotationStorage, e = this.data.id;
    this.container.classList.add("textWidgetAnnotation");
    let s = null;
    if (this.renderForms) {
      const i = t.getValue(e, {
        value: this.data.fieldValue
      });
      let n = i.value || "";
      const r = t.getValue(e, {
        charLimit: this.data.maxLen
      }).charLimit;
      r && n.length > r && (n = n.slice(0, r));
      let a = i.formattedValue || this.data.textContent?.join(`
`) || null;
      a && this.data.comb && (a = a.replaceAll(/\s+/g, ""));
      const o = {
        userValue: n,
        formattedValue: a,
        lastCommittedValue: null,
        commitKey: 1,
        focused: !1
      };
      this.data.multiLine ? (s = document.createElement("textarea"), s.textContent = a ?? n, this.data.doNotScroll && (s.style.overflowY = "hidden")) : (s = document.createElement("input"), s.type = this.data.password ? "password" : "text", s.setAttribute("value", a ?? n), this.data.doNotScroll && (s.style.overflowX = "hidden")), this.data.hasOwnCanvas && (s.hidden = !0), $t.add(s), this.contentElement = s, s.setAttribute("data-element-id", e), s.disabled = this.data.readOnly, s.name = this.data.fieldName, s.tabIndex = 0;
      const {
        datetimeFormat: l,
        datetimeType: h,
        timeStep: c
      } = this.data, u = !!h && this.enableScripting;
      l && (s.title = l), this._setRequired(s, this.data.required), r && (s.maxLength = r), s.addEventListener("input", (g) => {
        t.setValue(e, {
          value: g.target.value
        }), this.setPropertyOnSiblings(s, "value", g.target.value, "value"), o.formattedValue = null;
      }), s.addEventListener("resetform", (g) => {
        const p = this.data.defaultFieldValue ?? "";
        s.value = o.userValue = p, o.formattedValue = null;
      });
      let f = (g) => {
        const {
          formattedValue: p
        } = o;
        p != null && (g.target.value = p), g.target.scrollLeft = 0;
      };
      if (this.enableScripting && this.hasJSActions) {
        s.addEventListener("focus", (p) => {
          if (o.focused)
            return;
          const {
            target: b
          } = p;
          if (u && (b.type = h, c && (b.step = c)), o.userValue) {
            const m = o.userValue;
            if (u)
              if (h === "time") {
                const y = new Date(m), A = [y.getHours(), y.getMinutes(), y.getSeconds()];
                b.value = A.map((v) => v.toString().padStart(2, "0")).join(":");
              } else
                b.value = new Date(m - mr).toISOString().split(h === "date" ? "T" : ".", 1)[0];
            else
              b.value = m;
          }
          o.lastCommittedValue = b.value, o.commitKey = 1, this.data.actions?.Focus || (o.focused = !0);
        }), s.addEventListener("updatefromsandbox", (p) => {
          this.showElementAndHideCanvas(p.target);
          const b = {
            value(m) {
              o.userValue = m.detail.value ?? "", u || t.setValue(e, {
                value: o.userValue.toString()
              }), m.target.value = o.userValue;
            },
            formattedValue(m) {
              const {
                formattedValue: y
              } = m.detail;
              o.formattedValue = y, y != null && m.target !== document.activeElement && (m.target.value = y);
              const A = {
                formattedValue: y
              };
              u && (A.value = y), t.setValue(e, A);
            },
            selRange(m) {
              m.target.setSelectionRange(...m.detail.selRange);
            },
            charLimit: (m) => {
              const {
                charLimit: y
              } = m.detail, {
                target: A
              } = m;
              if (y === 0) {
                A.removeAttribute("maxLength");
                return;
              }
              A.setAttribute("maxLength", y);
              let v = o.userValue;
              !v || v.length <= y || (v = v.slice(0, y), A.value = o.userValue = v, t.setValue(e, {
                value: v
              }), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                source: this,
                detail: {
                  id: e,
                  name: "Keystroke",
                  value: v,
                  willCommit: !0,
                  commitKey: 1,
                  selStart: A.selectionStart,
                  selEnd: A.selectionEnd
                }
              }));
            }
          };
          this._dispatchEventFromSandbox(b, p);
        }), s.addEventListener("keydown", (p) => {
          o.commitKey = 1;
          let b = -1;
          if (p.key === "Escape" ? b = 0 : p.key === "Enter" && !this.data.multiLine ? b = 2 : p.key === "Tab" && (o.commitKey = 3), b === -1)
            return;
          const {
            value: m
          } = p.target;
          o.lastCommittedValue !== m && (o.lastCommittedValue = m, o.userValue = m, this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: m,
              willCommit: !0,
              commitKey: b,
              selStart: p.target.selectionStart,
              selEnd: p.target.selectionEnd
            }
          }));
        });
        const g = f;
        f = null, s.addEventListener("blur", (p) => {
          if (!o.focused || !p.relatedTarget)
            return;
          this.data.actions?.Blur || (o.focused = !1);
          const {
            target: b
          } = p;
          let {
            value: m
          } = b;
          if (u) {
            if (m && h === "time") {
              const y = m.split(":").map((A) => parseInt(A, 10));
              m = new Date(2e3, 0, 1, y[0], y[1], y[2] || 0).valueOf(), b.step = "";
            } else
              m.includes("T") || (m = `${m}T00:00`), m = new Date(m).valueOf();
            b.type = "text";
          }
          o.userValue = m, o.lastCommittedValue !== m && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: m,
              willCommit: !0,
              commitKey: o.commitKey,
              selStart: p.target.selectionStart,
              selEnd: p.target.selectionEnd
            }
          }), g(p);
        }), this.data.actions?.Keystroke && s.addEventListener("beforeinput", (p) => {
          o.lastCommittedValue = null;
          const {
            data: b,
            target: m
          } = p, {
            value: y,
            selectionStart: A,
            selectionEnd: v
          } = m;
          let w = A, S = v;
          switch (p.inputType) {
            case "deleteWordBackward": {
              const E = y.substring(0, A).match(/\w*[^\w]*$/);
              E && (w -= E[0].length);
              break;
            }
            case "deleteWordForward": {
              const E = y.substring(A).match(/^[^\w]*\w*/);
              E && (S += E[0].length);
              break;
            }
            case "deleteContentBackward":
              A === v && (w -= 1);
              break;
            case "deleteContentForward":
              A === v && (S += 1);
              break;
          }
          p.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: y,
              change: b || "",
              willCommit: !1,
              selStart: w,
              selEnd: S
            }
          });
        }), this._setEventListeners(s, o, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (p) => p.target.value);
      }
      if (f && s.addEventListener("blur", f), this.data.comb) {
        const p = (this.data.rect[2] - this.data.rect[0]) / r;
        s.classList.add("comb"), s.style.letterSpacing = `calc(${p}px * var(--total-scale-factor) - 1ch)`;
      }
    } else
      s = document.createElement("div"), s.textContent = this.data.fieldValue, s.style.verticalAlign = "middle", s.style.display = "table-cell", this.data.hasOwnCanvas && (s.hidden = !0);
    return this._setTextStyle(s), this._setBackgroundColor(s), this._setDefaultPropertiesFromJS(s), this.container.append(s), this.container;
  }
}
class wr extends zt {
  constructor(t) {
    super(t, {
      isRenderable: !!t.data.hasOwnCanvas
    });
  }
}
class vr extends zt {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    const t = this.annotationStorage, e = this.data, s = e.id;
    let i = t.getValue(s, {
      value: e.exportValue === e.fieldValue
    }).value;
    typeof i == "string" && (i = i !== "Off", t.setValue(s, {
      value: i
    })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
    const n = document.createElement("input");
    return $t.add(n), n.setAttribute("data-element-id", s), n.disabled = e.readOnly, this._setRequired(n, this.data.required), n.type = "checkbox", n.name = e.fieldName, i && n.setAttribute("checked", !0), n.setAttribute("exportValue", e.exportValue), n.tabIndex = 0, n.addEventListener("change", (r) => {
      const {
        name: a,
        checked: o
      } = r.target;
      for (const l of this._getElementsByName(a, s)) {
        const h = o && l.exportValue === e.exportValue;
        l.domElement && (l.domElement.checked = h), t.setValue(l.id, {
          value: h
        });
      }
      t.setValue(s, {
        value: o
      });
    }), n.addEventListener("resetform", (r) => {
      const a = e.defaultFieldValue || "Off";
      r.target.checked = a === e.exportValue;
    }), this.enableScripting && this.hasJSActions && (n.addEventListener("updatefromsandbox", (r) => {
      const a = {
        value(o) {
          o.target.checked = o.detail.value !== "Off", t.setValue(s, {
            value: o.target.checked
          });
        }
      };
      this._dispatchEventFromSandbox(a, r);
    }), this._setEventListeners(n, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (r) => r.target.checked)), this._setBackgroundColor(n), this._setDefaultPropertiesFromJS(n), this.container.append(n), this.container;
  }
}
class ji extends zt {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("buttonWidgetAnnotation", "radioButton");
    const t = this.annotationStorage, e = this.data, s = e.id;
    let i = t.getValue(s, {
      value: e.fieldValue === e.buttonValue
    }).value;
    if (typeof i == "string" && (i = i !== e.buttonValue, t.setValue(s, {
      value: i
    })), i)
      for (const r of this._getElementsByName(e.fieldName, s))
        t.setValue(r.id, {
          value: !1
        });
    const n = document.createElement("input");
    if ($t.add(n), n.setAttribute("data-element-id", s), n.disabled = e.readOnly, this._setRequired(n, this.data.required), n.type = "radio", n.name = e.fieldName, i && n.setAttribute("checked", !0), n.tabIndex = 0, n.addEventListener("change", (r) => {
      const {
        name: a,
        checked: o
      } = r.target;
      for (const l of this._getElementsByName(a, s))
        t.setValue(l.id, {
          value: !1
        });
      t.setValue(s, {
        value: o
      });
    }), n.addEventListener("resetform", (r) => {
      const a = e.defaultFieldValue;
      r.target.checked = a != null && a === e.buttonValue;
    }), this.enableScripting && this.hasJSActions) {
      const r = e.buttonValue;
      n.addEventListener("updatefromsandbox", (a) => {
        const o = {
          value: (l) => {
            const h = r === l.detail.value;
            for (const c of this._getElementsByName(l.target.name)) {
              const u = h && c.id === s;
              c.domElement && (c.domElement.checked = u), t.setValue(c.id, {
                value: u
              });
            }
          }
        };
        this._dispatchEventFromSandbox(o, a);
      }), this._setEventListeners(n, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (a) => a.target.checked);
    }
    return this._setBackgroundColor(n), this._setDefaultPropertiesFromJS(n), this.container.append(n), this.container;
  }
}
class Sr extends Ms {
  constructor(t) {
    super(t, {
      ignoreBorder: t.data.hasAppearance
    });
  }
  render() {
    const t = super.render();
    t.classList.add("buttonWidgetAnnotation", "pushButton");
    const e = t.lastChild;
    return this.enableScripting && this.hasJSActions && e && (this._setDefaultPropertiesFromJS(e), e.addEventListener("updatefromsandbox", (s) => {
      this._dispatchEventFromSandbox({}, s);
    })), t;
  }
}
class Er extends zt {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("choiceWidgetAnnotation");
    const t = this.annotationStorage, e = this.data.id, s = t.getValue(e, {
      value: this.data.fieldValue
    }), i = document.createElement("select");
    $t.add(i), i.setAttribute("data-element-id", e), i.disabled = this.data.readOnly, this._setRequired(i, this.data.required), i.name = this.data.fieldName, i.tabIndex = 0;
    let n = this.data.combo && this.data.options.length > 0;
    this.data.combo || (i.size = this.data.options.length, this.data.multiSelect && (i.multiple = !0)), i.addEventListener("resetform", (h) => {
      const c = this.data.defaultFieldValue;
      for (const u of i.options)
        u.selected = u.value === c;
    });
    for (const h of this.data.options) {
      const c = document.createElement("option");
      c.textContent = h.displayValue, c.value = h.exportValue, s.value.includes(h.exportValue) && (c.setAttribute("selected", !0), n = !1), i.append(c);
    }
    let r = null;
    if (n) {
      const h = document.createElement("option");
      h.value = " ", h.setAttribute("hidden", !0), h.setAttribute("selected", !0), i.prepend(h), r = () => {
        h.remove(), i.removeEventListener("input", r), r = null;
      }, i.addEventListener("input", r);
    }
    const a = (h) => {
      const c = h ? "value" : "textContent", {
        options: u,
        multiple: f
      } = i;
      return f ? Array.prototype.filter.call(u, (g) => g.selected).map((g) => g[c]) : u.selectedIndex === -1 ? null : u[u.selectedIndex][c];
    };
    let o = a(!1);
    const l = (h) => {
      const c = h.target.options;
      return Array.prototype.map.call(c, (u) => ({
        displayValue: u.textContent,
        exportValue: u.value
      }));
    };
    return this.enableScripting && this.hasJSActions ? (i.addEventListener("updatefromsandbox", (h) => {
      const c = {
        value(u) {
          r?.();
          const f = u.detail.value, g = new Set(Array.isArray(f) ? f : [f]);
          for (const p of i.options)
            p.selected = g.has(p.value);
          t.setValue(e, {
            value: a(!0)
          }), o = a(!1);
        },
        multipleSelection(u) {
          i.multiple = !0;
        },
        remove(u) {
          const f = i.options, g = u.detail.remove;
          f[g].selected = !1, i.remove(g), f.length > 0 && Array.prototype.findIndex.call(f, (b) => b.selected) === -1 && (f[0].selected = !0), t.setValue(e, {
            value: a(!0),
            items: l(u)
          }), o = a(!1);
        },
        clear(u) {
          for (; i.length !== 0; )
            i.remove(0);
          t.setValue(e, {
            value: null,
            items: []
          }), o = a(!1);
        },
        insert(u) {
          const {
            index: f,
            displayValue: g,
            exportValue: p
          } = u.detail.insert, b = i.children[f], m = document.createElement("option");
          m.textContent = g, m.value = p, b ? b.before(m) : i.append(m), t.setValue(e, {
            value: a(!0),
            items: l(u)
          }), o = a(!1);
        },
        items(u) {
          const {
            items: f
          } = u.detail;
          for (; i.length !== 0; )
            i.remove(0);
          for (const g of f) {
            const {
              displayValue: p,
              exportValue: b
            } = g, m = document.createElement("option");
            m.textContent = p, m.value = b, i.append(m);
          }
          i.options.length > 0 && (i.options[0].selected = !0), t.setValue(e, {
            value: a(!0),
            items: l(u)
          }), o = a(!1);
        },
        indices(u) {
          const f = new Set(u.detail.indices);
          for (const g of u.target.options)
            g.selected = f.has(g.index);
          t.setValue(e, {
            value: a(!0)
          }), o = a(!1);
        },
        editable(u) {
          u.target.disabled = !u.detail.editable;
        }
      };
      this._dispatchEventFromSandbox(c, h);
    }), i.addEventListener("input", (h) => {
      const c = a(!0), u = a(!1);
      t.setValue(e, {
        value: c
      }), h.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: e,
          name: "Keystroke",
          value: o,
          change: u,
          changeEx: c,
          willCommit: !1,
          commitKey: 1,
          keyDown: !1
        }
      });
    }), this._setEventListeners(i, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (h) => h.target.value)) : i.addEventListener("input", function(h) {
      t.setValue(e, {
        value: a(!0)
      });
    }), this.data.combo && this._setTextStyle(i), this._setBackgroundColor(i), this._setDefaultPropertiesFromJS(i), this.container.append(i), this.container;
  }
}
class fs extends Q {
  constructor(t) {
    const {
      data: e,
      elements: s,
      parent: i
    } = t, n = !!i._commentManager;
    if (super(t, {
      isRenderable: !n && Q._hasPopupData(e)
    }), this.elements = s, n && Q._hasPopupData(e)) {
      const r = this.popup = this.#t();
      for (const a of s)
        a.popup = r;
    } else
      this.popup = null;
  }
  #t() {
    return new _r({
      container: this.container,
      color: this.data.color,
      titleObj: this.data.titleObj,
      modificationDate: this.data.modificationDate || this.data.creationDate,
      contentsObj: this.data.contentsObj,
      richText: this.data.richText,
      rect: this.data.rect,
      parentRect: this.data.parentRect || null,
      parent: this.parent,
      elements: this.elements,
      open: this.data.open,
      commentManager: this.parent._commentManager
    });
  }
  render() {
    const {
      container: t
    } = this;
    t.classList.add("popupAnnotation"), t.role = "comment";
    const e = this.popup = this.#t(), s = [];
    for (const i of this.elements)
      i.popup = e, i.container.ariaHasPopup = "dialog", s.push(i.data.id), i.addHighlightArea();
    return this.container.setAttribute("aria-controls", s.map((i) => `${Xt}${i}`).join(",")), this.container;
  }
}
class _r {
  #t = null;
  #e = this.#G.bind(this);
  #i = this.#U.bind(this);
  #s = this.#I.bind(this);
  #a = this.#S.bind(this);
  #r = null;
  #n = null;
  #o = null;
  #h = null;
  #l = null;
  #u = null;
  #d = null;
  #f = !1;
  #m = null;
  #g = null;
  #c = null;
  #p = null;
  #b = null;
  #y = null;
  #A = null;
  #C = null;
  #E = null;
  #v = null;
  #x = !1;
  #w = null;
  #_ = null;
  constructor({
    container: t,
    color: e,
    elements: s,
    titleObj: i,
    modificationDate: n,
    contentsObj: r,
    richText: a,
    parent: o,
    rect: l,
    parentRect: h,
    open: c,
    commentManager: u = null
  }) {
    this.#n = t, this.#E = i, this.#o = r, this.#C = a, this.#u = o, this.#r = e, this.#A = l, this.#d = h, this.#l = s, this.#t = u, this.#w = s[0], this.#h = Fe.toDateObject(n), this.trigger = s.flatMap((f) => f.getElementsToTriggerPopup()), u || (this.#M(), this.#n.hidden = !0, c && this.#S());
  }
  #M() {
    if (this.#g)
      return;
    this.#g = new AbortController();
    const {
      signal: t
    } = this.#g;
    for (const e of this.trigger)
      e.addEventListener("click", this.#a, {
        signal: t
      }), e.addEventListener("pointerenter", this.#s, {
        signal: t
      }), e.addEventListener("pointerleave", this.#i, {
        signal: t
      }), e.classList.add("popupTriggerArea");
    for (const e of this.#l)
      e.container?.addEventListener("keydown", this.#e, {
        signal: t
      });
  }
  #P() {
    const t = this.#l.find((e) => e.hasCommentButton);
    t && (this.#b = t._normalizePoint(t.commentButtonPosition));
  }
  renderCommentButton() {
    if (this.#p) {
      this.#p.parentNode || this.#w.container.after(this.#p);
      return;
    }
    if (this.#b || this.#P(), !this.#b)
      return;
    const {
      signal: t
    } = this.#g = new AbortController(), e = this.#w.hasOwnCommentButton, s = () => {
      this.#t.toggleCommentPopup(this, !0, void 0, !e);
    }, i = () => {
      this.#t.toggleCommentPopup(this, !1, !0, !e);
    }, n = () => {
      this.#t.toggleCommentPopup(this, !1, !1);
    };
    if (e) {
      this.#p = this.#w.container;
      for (const r of this.trigger)
        r.ariaHasPopup = "dialog", r.ariaControls = "commentPopup", r.addEventListener("keydown", this.#e, {
          signal: t
        }), r.addEventListener("click", s, {
          signal: t
        }), r.addEventListener("pointerenter", i, {
          signal: t
        }), r.addEventListener("pointerleave", n, {
          signal: t
        }), r.classList.add("popupTriggerArea");
    } else {
      const r = this.#p = document.createElement("button");
      r.className = "annotationCommentButton";
      const a = this.#w.container;
      r.style.zIndex = a.style.zIndex + 1, r.tabIndex = 0, r.ariaHasPopup = "dialog", r.ariaControls = "commentPopup", r.setAttribute("data-l10n-id", "pdfjs-show-comment-button"), this.#O(), this.#k(), r.addEventListener("keydown", this.#e, {
        signal: t
      }), r.addEventListener("click", s, {
        signal: t
      }), r.addEventListener("pointerenter", i, {
        signal: t
      }), r.addEventListener("pointerleave", n, {
        signal: t
      }), a.after(r);
    }
  }
  #k() {
    if (this.#w.extraPopupElement && !this.#w.editor)
      return;
    this.#p || this.renderCommentButton();
    const [t, e] = this.#b, {
      style: s
    } = this.#p;
    s.left = `calc(${t}%)`, s.top = `calc(${e}% - var(--comment-button-dim))`;
  }
  #O() {
    this.#w.extraPopupElement || (this.#p || this.renderCommentButton(), this.#p.style.backgroundColor = this.commentButtonColor || "");
  }
  get commentButtonColor() {
    const {
      color: t,
      opacity: e
    } = this.#w.commentData;
    return t ? this.#u._commentManager.makeCommentColor(t, e) : null;
  }
  focusCommentButton() {
    setTimeout(() => {
      this.#p?.focus();
    }, 0);
  }
  getData() {
    const {
      richText: t,
      color: e,
      opacity: s,
      creationDate: i,
      modificationDate: n
    } = this.#w.commentData;
    return {
      contentsObj: {
        str: this.comment
      },
      richText: t,
      color: e,
      opacity: s,
      creationDate: i,
      modificationDate: n
    };
  }
  get elementBeforePopup() {
    return this.#p;
  }
  get comment() {
    return this.#_ ||= this.#w.commentText, this.#_;
  }
  set comment(t) {
    t !== this.comment && (this.#w.commentText = this.#_ = t);
  }
  focus() {
    this.#w.container?.focus();
  }
  get parentBoundingClientRect() {
    return this.#w.layer.getBoundingClientRect();
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    this.#p && (this.#p.classList.toggle("selected", t), this.#p.ariaExpanded = e);
  }
  setSelectedCommentButton(t) {
    this.#p.classList.toggle("selected", t);
  }
  get commentPopupPosition() {
    if (this.#y)
      return this.#y;
    const {
      x: t,
      y: e,
      height: s
    } = this.#p.getBoundingClientRect(), {
      x: i,
      y: n,
      width: r,
      height: a
    } = this.#w.layer.getBoundingClientRect();
    return [(t - i) / r, (e + s - n) / a];
  }
  set commentPopupPosition(t) {
    this.#y = t;
  }
  hasDefaultPopupPosition() {
    return this.#y === null;
  }
  get commentButtonPosition() {
    return this.#b;
  }
  get commentButtonWidth() {
    return this.#p.getBoundingClientRect().width / this.parentBoundingClientRect.width;
  }
  editComment(t) {
    const [e, s] = this.#y || this.commentButtonPosition.map((l) => l / 100), i = this.parentBoundingClientRect, {
      x: n,
      y: r,
      width: a,
      height: o
    } = i;
    this.#t.showDialog(null, this, n + e * a, r + s * o, {
      ...t,
      parentDimensions: i
    });
  }
  render() {
    if (this.#m)
      return;
    const t = this.#m = document.createElement("div");
    if (t.className = "popup", this.#r) {
      const s = t.style.outlineColor = T.makeHexColor(...this.#r);
      t.style.backgroundColor = `color-mix(in srgb, ${s} 30%, white)`;
    }
    const e = document.createElement("span");
    if (e.className = "header", this.#E?.str) {
      const s = document.createElement("span");
      s.className = "title", e.append(s), {
        dir: s.dir,
        str: s.textContent
      } = this.#E;
    }
    if (t.append(e), this.#h) {
      const s = document.createElement("time");
      s.className = "popupDate", s.setAttribute("data-l10n-id", "pdfjs-annotation-date-time-string"), s.setAttribute("data-l10n-args", JSON.stringify({
        dateObj: this.#h.valueOf()
      })), s.dateTime = this.#h.toISOString(), e.append(s);
    }
    vs({
      html: this.#L || this.#o.str,
      dir: this.#o?.dir,
      className: "popupContent"
    }, t), this.#n.append(t);
  }
  get #L() {
    const t = this.#C, e = this.#o;
    return t?.str && (!e?.str || e.str === t.str) && this.#C.html || null;
  }
  get #R() {
    return this.#L?.attributes?.style?.fontSize || 0;
  }
  get #B() {
    return this.#L?.attributes?.style?.color || null;
  }
  #F(t) {
    const e = [], s = {
      str: t,
      html: {
        name: "div",
        attributes: {
          dir: "auto"
        },
        children: [{
          name: "p",
          children: e
        }]
      }
    }, i = {
      style: {
        color: this.#B,
        fontSize: this.#R ? `calc(${this.#R}px * var(--total-scale-factor))` : ""
      }
    };
    for (const n of t.split(`
`))
      e.push({
        name: "span",
        value: n,
        attributes: i
      });
    return s;
  }
  #G(t) {
    t.altKey || t.shiftKey || t.ctrlKey || t.metaKey || (t.key === "Enter" || t.key === "Escape" && this.#f) && this.#S();
  }
  updateEdited({
    rect: t,
    popup: e,
    deleted: s
  }) {
    if (this.#t) {
      s ? (this.remove(), this.#_ = null) : e && (e.deleted ? this.remove() : (this.#O(), this.#_ = e.text)), t && (this.#b = null, this.#P(), this.#k());
      return;
    }
    if (s || e?.deleted) {
      this.remove();
      return;
    }
    this.#M(), this.#v ||= {
      contentsObj: this.#o,
      richText: this.#C
    }, t && (this.#c = null), e && e.text && (this.#C = this.#F(e.text), this.#h = Fe.toDateObject(e.date), this.#o = null), this.#m?.remove(), this.#m = null;
  }
  resetEdited() {
    this.#v && ({
      contentsObj: this.#o,
      richText: this.#C
    } = this.#v, this.#v = null, this.#m?.remove(), this.#m = null, this.#c = null);
  }
  remove() {
    if (this.#g?.abort(), this.#g = null, this.#m?.remove(), this.#m = null, this.#x = !1, this.#f = !1, this.#p?.remove(), this.#p = null, this.trigger)
      for (const t of this.trigger)
        t.classList.remove("popupTriggerArea");
  }
  #T() {
    if (this.#c !== null)
      return;
    const {
      page: {
        view: t
      },
      viewport: {
        rawDims: {
          pageWidth: e,
          pageHeight: s,
          pageX: i,
          pageY: n
        }
      }
    } = this.#u;
    let r = !!this.#d, a = r ? this.#d : this.#A;
    for (const g of this.#l)
      if (!a || T.intersect(g.data.rect, a) !== null) {
        a = g.data.rect, r = !0;
        break;
      }
    const o = T.normalizeRect([a[0], t[3] - a[1] + t[1], a[2], t[3] - a[3] + t[1]]), h = r ? a[2] - a[0] + 5 : 0, c = o[0] + h, u = o[1];
    this.#c = [100 * (c - i) / e, 100 * (u - n) / s];
    const {
      style: f
    } = this.#n;
    f.left = `${this.#c[0]}%`, f.top = `${this.#c[1]}%`;
  }
  #S() {
    if (this.#t) {
      this.#t.toggleCommentPopup(this, !1);
      return;
    }
    this.#f = !this.#f, this.#f ? (this.#I(), this.#n.addEventListener("click", this.#a), this.#n.addEventListener("keydown", this.#e)) : (this.#U(), this.#n.removeEventListener("click", this.#a), this.#n.removeEventListener("keydown", this.#e));
  }
  #I() {
    this.#m || this.render(), this.isVisible ? this.#f && this.#n.classList.add("focused") : (this.#T(), this.#n.hidden = !1, this.#n.style.zIndex = parseInt(this.#n.style.zIndex) + 1e3);
  }
  #U() {
    this.#n.classList.remove("focused"), !(this.#f || !this.isVisible) && (this.#n.hidden = !0, this.#n.style.zIndex = parseInt(this.#n.style.zIndex) - 1e3);
  }
  forceHide() {
    this.#x = this.isVisible, this.#x && (this.#n.hidden = !0);
  }
  maybeShow() {
    this.#t || (this.#M(), this.#x && (this.#m || this.#I(), this.#x = !1, this.#n.hidden = !1));
  }
  get isVisible() {
    return this.#t ? !1 : this.#n.hidden === !1;
  }
}
class zi extends Q {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.textContent = t.data.textContent, this.textPosition = t.data.textPosition, this.annotationEditorType = F.FREETEXT;
  }
  render() {
    if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
      const t = this.contentElement = document.createElement("div");
      t.classList.add("annotationTextContent"), t.setAttribute("role", "comment");
      for (const e of this.textContent) {
        const s = document.createElement("span");
        s.textContent = e, t.append(s);
      }
      this.container.append(t);
    }
    return !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this._editOnDoubleClick(), this.container;
  }
}
class Cr extends Q {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    this.container.classList.add("lineAnnotation");
    const {
      data: t,
      width: e,
      height: s
    } = this, i = this.svgFactory.create(e, s, !0), n = this.#t = this.svgFactory.createElement("svg:line");
    return n.setAttribute("x1", t.rect[2] - t.lineCoordinates[0]), n.setAttribute("y1", t.rect[3] - t.lineCoordinates[1]), n.setAttribute("x2", t.rect[2] - t.lineCoordinates[2]), n.setAttribute("y2", t.rect[3] - t.lineCoordinates[3]), n.setAttribute("stroke-width", t.borderStyle.width || 1), n.setAttribute("stroke", "transparent"), n.setAttribute("fill", "transparent"), i.append(n), this.container.append(i), !t.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class Tr extends Q {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    this.container.classList.add("squareAnnotation");
    const {
      data: t,
      width: e,
      height: s
    } = this, i = this.svgFactory.create(e, s, !0), n = t.borderStyle.width, r = this.#t = this.svgFactory.createElement("svg:rect");
    return r.setAttribute("x", n / 2), r.setAttribute("y", n / 2), r.setAttribute("width", e - n), r.setAttribute("height", s - n), r.setAttribute("stroke-width", n || 1), r.setAttribute("stroke", "transparent"), r.setAttribute("fill", "transparent"), i.append(r), this.container.append(i), !t.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class xr extends Q {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    this.container.classList.add("circleAnnotation");
    const {
      data: t,
      width: e,
      height: s
    } = this, i = this.svgFactory.create(e, s, !0), n = t.borderStyle.width, r = this.#t = this.svgFactory.createElement("svg:ellipse");
    return r.setAttribute("cx", e / 2), r.setAttribute("cy", s / 2), r.setAttribute("rx", e / 2 - n / 2), r.setAttribute("ry", s / 2 - n / 2), r.setAttribute("stroke-width", n || 1), r.setAttribute("stroke", "transparent"), r.setAttribute("fill", "transparent"), i.append(r), this.container.append(i), !t.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class Gi extends Q {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: t,
        vertices: e,
        borderStyle: s,
        popupRef: i
      },
      width: n,
      height: r
    } = this;
    if (!e)
      return this.container;
    const a = this.svgFactory.create(n, r, !0);
    let o = [];
    for (let h = 0, c = e.length; h < c; h += 2) {
      const u = e[h] - t[0], f = t[3] - e[h + 1];
      o.push(`${u},${f}`);
    }
    o = o.join(" ");
    const l = this.#t = this.svgFactory.createElement(this.svgElementName);
    return l.setAttribute("points", o), l.setAttribute("stroke-width", s.width || 1), l.setAttribute("stroke", "transparent"), l.setAttribute("fill", "transparent"), a.append(l), this.container.append(a), !i && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class Pr extends Gi {
  constructor(t) {
    super(t), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
  }
}
class kr extends Q {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
}
class Ds extends Q {
  #t = null;
  #e = [];
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = this.data.it === "InkHighlight" ? F.HIGHLIGHT : F.INK;
  }
  #i(t, e) {
    switch (t) {
      case 90:
        return {
          transform: `rotate(90) translate(${-e[0]},${e[1]}) scale(1,-1)`,
          width: e[3] - e[1],
          height: e[2] - e[0]
        };
      case 180:
        return {
          transform: `rotate(180) translate(${-e[2]},${e[1]}) scale(1,-1)`,
          width: e[2] - e[0],
          height: e[3] - e[1]
        };
      case 270:
        return {
          transform: `rotate(270) translate(${-e[2]},${e[3]}) scale(1,-1)`,
          width: e[3] - e[1],
          height: e[2] - e[0]
        };
      default:
        return {
          transform: `translate(${-e[0]},${e[3]}) scale(1,-1)`,
          width: e[2] - e[0],
          height: e[3] - e[1]
        };
    }
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: t,
        rotation: e,
        inkLists: s,
        borderStyle: i,
        popupRef: n
      }
    } = this, {
      transform: r,
      width: a,
      height: o
    } = this.#i(e, t), l = this.svgFactory.create(a, o, !0), h = this.#t = this.svgFactory.createElement("svg:g");
    l.append(h), h.setAttribute("stroke-width", i.width || 1), h.setAttribute("stroke-linecap", "round"), h.setAttribute("stroke-linejoin", "round"), h.setAttribute("stroke-miterlimit", 10), h.setAttribute("stroke", "transparent"), h.setAttribute("fill", "transparent"), h.setAttribute("transform", r);
    for (let c = 0, u = s.length; c < u; c++) {
      const f = this.svgFactory.createElement(this.svgElementName);
      this.#e.push(f), f.setAttribute("points", s[c].join(",")), h.append(f);
    }
    return !n && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.append(l), this._editOnDoubleClick(), this.container;
  }
  updateEdited(t) {
    super.updateEdited(t);
    const {
      thickness: e,
      points: s,
      rect: i
    } = t, n = this.#t;
    if (e >= 0 && n.setAttribute("stroke-width", e || 1), s)
      for (let r = 0, a = this.#e.length; r < a; r++)
        this.#e[r].setAttribute("points", s[r].join(","));
    if (i) {
      const {
        transform: r,
        width: a,
        height: o
      } = this.#i(this.data.rotation, i);
      n.parentElement.setAttribute("viewBox", `0 0 ${a} ${o}`), n.setAttribute("transform", r);
    }
  }
  getElementsToTriggerPopup() {
    return this.#e;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class Vi extends Q {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    }), this.annotationEditorType = F.HIGHLIGHT;
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("highlightAnnotation"), this._editOnDoubleClick(), t) {
      const s = document.createElement("mark");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class Mr extends Q {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("underlineAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class Dr extends Q {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("squigglyAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class Lr extends Q {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("strikeoutAnnotation"), t) {
      const s = document.createElement("s");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class Wi extends Q {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.annotationEditorType = F.STAMP;
  }
  render() {
    return this.container.classList.add("stampAnnotation"), this.container.setAttribute("role", "img"), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this._editOnDoubleClick(), this.container;
  }
}
class Ir extends Q {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0
    });
    const {
      file: e
    } = this.data;
    this.filename = e.filename, this.content = e.content, this.linkService.eventBus?.dispatch("fileattachmentannotation", {
      source: this,
      ...e
    });
  }
  render() {
    this.container.classList.add("fileAttachmentAnnotation");
    const {
      container: t,
      data: e
    } = this;
    let s;
    e.hasAppearance || e.fillAlpha === 0 ? s = document.createElement("div") : (s = document.createElement("img"), s.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(e.name) ? "paperclip" : "pushpin"}.svg`, e.fillAlpha && e.fillAlpha < 1 && (s.style = `filter: opacity(${Math.round(e.fillAlpha * 100)}%);`)), s.addEventListener("dblclick", this.#e.bind(this)), this.#t = s;
    const {
      isMac: i
    } = nt.platform;
    return t.addEventListener("keydown", (n) => {
      n.key === "Enter" && (i ? n.metaKey : n.ctrlKey) && this.#e();
    }), !e.popupRef && this.hasPopupData ? (this.hasOwnCommentButton = !0, this._createPopup()) : s.classList.add("popupTriggerArea"), t.append(s), t;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
  #e() {
    this.downloadManager?.openOrDownloadData(this.content, this.filename);
  }
}
class Ye {
  #t = null;
  #e = null;
  #i = null;
  #s = /* @__PURE__ */ new Map();
  #a = null;
  #r = null;
  #n = [];
  #o = !1;
  constructor({
    div: t,
    accessibilityManager: e,
    annotationCanvasMap: s,
    annotationEditorUIManager: i,
    page: n,
    viewport: r,
    structTreeLayer: a,
    commentManager: o,
    linkService: l,
    annotationStorage: h
  }) {
    this.div = t, this.#t = e, this.#e = s, this.#a = a || null, this.#r = l || null, this.#i = h || new _s(), this.page = n, this.viewport = r, this.zIndex = 0, this._annotationEditorUIManager = i, this._commentManager = o || null;
  }
  hasEditableAnnotations() {
    return this.#s.size > 0;
  }
  async render(t) {
    const {
      annotations: e
    } = t, s = this.div;
    Nt(s, this.viewport);
    const i = /* @__PURE__ */ new Map(), n = [], r = {
      data: null,
      layer: s,
      linkService: this.#r,
      downloadManager: t.downloadManager,
      imageResourcesPath: t.imageResourcesPath || "",
      renderForms: t.renderForms !== !1,
      svgFactory: new Ae(),
      annotationStorage: this.#i,
      enableComment: t.enableComment === !0,
      enableScripting: t.enableScripting === !0,
      hasJSActions: t.hasJSActions,
      fieldObjects: t.fieldObjects,
      parent: this,
      elements: null
    };
    for (const a of e) {
      if (a.noHTML)
        continue;
      const o = a.annotationType === J.POPUP;
      if (o) {
        const c = i.get(a.id);
        if (!c)
          continue;
        if (!this._commentManager) {
          n.push(a);
          continue;
        }
        r.elements = c;
      } else if (a.rect[2] === a.rect[0] || a.rect[3] === a.rect[1])
        continue;
      r.data = a;
      const l = rs.create(r);
      if (!l.isRenderable)
        continue;
      if (!o && (this.#n.push(l), a.popupRef)) {
        const c = i.get(a.popupRef);
        c ? c.push(l) : i.set(a.popupRef, [l]);
      }
      const h = l.render();
      a.hidden && (h.style.visibility = "hidden"), l._isEditable && (this.#s.set(l.data.id, l), this._annotationEditorUIManager?.renderAnnotationElement(l));
    }
    await this.#h();
    for (const a of n) {
      const o = r.elements = i.get(a.id);
      r.data = a;
      const l = rs.create(r);
      if (!l.isRenderable)
        continue;
      const h = l.render();
      l.contentElement.id = `${Xt}${a.id}`, a.hidden && (h.style.visibility = "hidden"), o.at(-1).container.after(h);
    }
    this.#l();
  }
  async #h() {
    if (this.#n.length === 0)
      return;
    this.div.replaceChildren();
    const t = [];
    if (!this.#o) {
      this.#o = !0;
      for (const {
        contentElement: s,
        data: {
          id: i
        }
      } of this.#n) {
        const n = s.id = `${Xt}${i}`;
        t.push(this.#a?.getAriaAttributes(n).then((r) => {
          if (r)
            for (const [a, o] of r)
              s.setAttribute(a, o);
        }));
      }
    }
    this.#n.sort(({
      data: {
        rect: [s, i, n, r]
      }
    }, {
      data: {
        rect: [a, o, l, h]
      }
    }) => {
      if (s === n && i === r)
        return 1;
      if (a === l && o === h)
        return -1;
      const c = r, u = i, f = (i + r) / 2, g = h, p = o, b = (o + h) / 2;
      if (f >= g && b <= u)
        return -1;
      if (b >= c && f <= p)
        return 1;
      const m = (s + n) / 2, y = (a + l) / 2;
      return m - y;
    });
    const e = document.createDocumentFragment();
    for (const s of this.#n)
      e.append(s.container), this._commentManager ? (s.extraPopupElement?.popup || s.popup)?.renderCommentButton() : s.extraPopupElement && e.append(s.extraPopupElement.render());
    if (this.div.append(e), await Promise.all(t), this.#t)
      for (const s of this.#n)
        this.#t.addPointerInTextLayer(s.contentElement, !1);
  }
  async addLinkAnnotations(t) {
    const e = {
      data: null,
      layer: this.div,
      linkService: this.#r,
      svgFactory: new Ae(),
      parent: this
    };
    for (const s of t) {
      s.borderStyle ||= Ye._defaultBorderStyle, e.data = s;
      const i = rs.create(e);
      i.isRenderable && (i.render(), i.contentElement.id = `${Xt}${s.id}`, this.#n.push(i));
    }
    await this.#h();
  }
  update({
    viewport: t
  }) {
    const e = this.div;
    this.viewport = t, Nt(e, {
      rotation: t.rotation
    }), this.#l(), e.hidden = !1;
  }
  #l() {
    if (!this.#e)
      return;
    const t = this.div;
    for (const [e, s] of this.#e) {
      const i = t.querySelector(`[data-annotation-id="${e}"]`);
      if (!i)
        continue;
      s.className = "annotationContent";
      const {
        firstChild: n
      } = i;
      n ? n.nodeName === "CANVAS" ? n.replaceWith(s) : n.classList.contains("annotationContent") ? n.after(s) : n.before(s) : i.append(s);
      const r = this.#s.get(e);
      r && (r._hasNoCanvas ? (this._annotationEditorUIManager?.setMissingCanvas(e, i.id, s), r._hasNoCanvas = !1) : r.canvas = s);
    }
    this.#e.clear();
  }
  getEditableAnnotations() {
    return Array.from(this.#s.values());
  }
  getEditableAnnotation(t) {
    return this.#s.get(t);
  }
  addFakeAnnotation(t) {
    const {
      div: e
    } = this, {
      id: s,
      rotation: i
    } = t, n = new br({
      data: {
        id: s,
        rect: t.getPDFRect(),
        rotation: i
      },
      editor: t,
      layer: e,
      parent: this,
      enableComment: !!this._commentManager,
      linkService: this.#r,
      annotationStorage: this.#i
    });
    return n.render(), n.contentElement.id = `${Xt}${s}`, n.createOrUpdatePopup(), this.#n.push(n), n;
  }
  removeAnnotation(t) {
    const e = this.#n.findIndex((i) => i.data.id === t);
    if (e < 0)
      return;
    const [s] = this.#n.splice(e, 1);
    this.#t?.removePointerInTextLayer(s.contentElement);
  }
  updateFakeAnnotations(t) {
    if (t.length !== 0) {
      for (const e of t)
        e.updateFakeAnnotationElement(this);
      this.#h();
    }
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  static get _defaultBorderStyle() {
    return I(this, "_defaultBorderStyle", Object.freeze({
      width: 1,
      rawWidth: 1,
      style: Vt.SOLID,
      dashArray: [3],
      horizontalCornerRadius: 0,
      verticalCornerRadius: 0
    }));
  }
}
const Le = /\r\n?|\n/g;
class ot extends D {
  #t = "";
  #e = `${this.id}-editor`;
  #i = null;
  #s;
  _colorPicker = null;
  static _freeTextDefaultContent = "";
  static _internalPadding = 0;
  static _defaultColor = null;
  static _defaultFontSize = 10;
  static get _keyboardManager() {
    const t = ot.prototype, e = (n) => n.isEmpty(), s = It.TRANSLATE_SMALL, i = It.TRANSLATE_BIG;
    return I(this, "_keyboardManager", new Se([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], t.commitOrRemove, {
      bubbles: !0
    }], [["ctrl+Enter", "mac+meta+Enter", "Escape", "mac+Escape"], t.commitOrRemove], [["ArrowLeft", "mac+ArrowLeft"], t._translateEmpty, {
      args: [-s, 0],
      checker: e
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t._translateEmpty, {
      args: [-i, 0],
      checker: e
    }], [["ArrowRight", "mac+ArrowRight"], t._translateEmpty, {
      args: [s, 0],
      checker: e
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t._translateEmpty, {
      args: [i, 0],
      checker: e
    }], [["ArrowUp", "mac+ArrowUp"], t._translateEmpty, {
      args: [0, -s],
      checker: e
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t._translateEmpty, {
      args: [0, -i],
      checker: e
    }], [["ArrowDown", "mac+ArrowDown"], t._translateEmpty, {
      args: [0, s],
      checker: e
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t._translateEmpty, {
      args: [0, i],
      checker: e
    }]]));
  }
  static _type = "freetext";
  static _editorType = F.FREETEXT;
  constructor(t) {
    super({
      ...t,
      name: "freeTextEditor"
    }), this.color = t.color || ot._defaultColor || D._defaultLineColor, this.#s = t.fontSize || ot._defaultFontSize, this.annotationElementId || this._uiManager.a11yAlert("pdfjs-editor-freetext-added-alert"), this.canAddComment = !1;
  }
  static initialize(t, e) {
    D.initialize(t, e);
    const s = getComputedStyle(document.documentElement);
    this._internalPadding = parseFloat(s.getPropertyValue("--freetext-padding"));
  }
  static updateDefaultParams(t, e) {
    switch (t) {
      case N.FREETEXT_SIZE:
        ot._defaultFontSize = e;
        break;
      case N.FREETEXT_COLOR:
        ot._defaultColor = e;
        break;
    }
  }
  updateParams(t, e) {
    switch (t) {
      case N.FREETEXT_SIZE:
        this.#a(e);
        break;
      case N.FREETEXT_COLOR:
        this.#r(e);
        break;
    }
  }
  static get defaultPropertiesToUpdate() {
    return [[N.FREETEXT_SIZE, ot._defaultFontSize], [N.FREETEXT_COLOR, ot._defaultColor || D._defaultLineColor]];
  }
  get propertiesToUpdate() {
    return [[N.FREETEXT_SIZE, this.#s], [N.FREETEXT_COLOR, this.color]];
  }
  get toolbarButtons() {
    return this._colorPicker ||= new be(this), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return N.FREETEXT_COLOR;
  }
  #a(t) {
    const e = (i) => {
      this.editorDiv.style.fontSize = `calc(${i}px * var(--total-scale-factor))`, this.translate(0, -(i - this.#s) * this.parentScale), this.#s = i, this.#o();
    }, s = this.#s;
    this.addCommands({
      cmd: e.bind(this, t),
      undo: e.bind(this, s),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: N.FREETEXT_SIZE,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  onUpdatedColor() {
    this.editorDiv.style.color = this.color, this._colorPicker?.update(this.color), super.onUpdatedColor();
  }
  #r(t) {
    const e = (i) => {
      this.color = i, this.onUpdatedColor();
    }, s = this.color;
    this.addCommands({
      cmd: e.bind(this, t),
      undo: e.bind(this, s),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: N.FREETEXT_COLOR,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _translateEmpty(t, e) {
    this._uiManager.translateSelectedEditors(t, e, !0);
  }
  getInitialTranslation() {
    const t = this.parentScale;
    return [-ot._internalPadding * t, -(ot._internalPadding + this.#s) * t];
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
  }
  enableEditMode() {
    if (!super.enableEditMode())
      return !1;
    this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), this.#i = new AbortController();
    const t = this._uiManager.combinedSignal(this.#i);
    return this.editorDiv.addEventListener("keydown", this.editorDivKeydown.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("focus", this.editorDivFocus.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("blur", this.editorDivBlur.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("input", this.editorDivInput.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("paste", this.editorDivPaste.bind(this), {
      signal: t
    }), !0;
  }
  disableEditMode() {
    return super.disableEditMode() ? (this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", this.#e), this._isDraggable = !0, this.#i?.abort(), this.#i = null, this.div.focus({
      preventScroll: !0
    }), this.isEditing = !1, this.parent.div.classList.add("freetextEditing"), !0) : !1;
  }
  focusin(t) {
    this._focusEventsAllowed && (super.focusin(t), t.target !== this.editorDiv && this.editorDiv.focus());
  }
  onceAdded(t) {
    this.width || (this.enableEditMode(), t && this.editorDiv.focus(), this._initialOptions?.isCentered && this.center(), this._initialOptions = null);
  }
  isEmpty() {
    return !this.editorDiv || this.editorDiv.innerText.trim() === "";
  }
  remove() {
    this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freetextEditing")), super.remove();
  }
  #n() {
    const t = [];
    this.editorDiv.normalize();
    let e = null;
    for (const s of this.editorDiv.childNodes)
      e?.nodeType === Node.TEXT_NODE && s.nodeName === "BR" || (t.push(ot.#h(s)), e = s);
    return t.join(`
`);
  }
  #o() {
    const [t, e] = this.parentDimensions;
    let s;
    if (this.isAttachedToDOM)
      s = this.div.getBoundingClientRect();
    else {
      const {
        currentLayer: i,
        div: n
      } = this, r = n.style.display, a = n.classList.contains("hidden");
      n.classList.remove("hidden"), n.style.display = "hidden", i.div.append(this.div), s = n.getBoundingClientRect(), n.remove(), n.style.display = r, n.classList.toggle("hidden", a);
    }
    this.rotation % 180 === this.parentRotation % 180 ? (this.width = s.width / t, this.height = s.height / e) : (this.width = s.height / t, this.height = s.width / e), this.fixAndSetPosition();
  }
  commit() {
    if (!this.isInEditMode())
      return;
    super.commit(), this.disableEditMode();
    const t = this.#t, e = this.#t = this.#n().trimEnd();
    if (t === e)
      return;
    const s = (i) => {
      if (this.#t = i, !i) {
        this.remove();
        return;
      }
      this.#l(), this._uiManager.rebuild(this), this.#o();
    };
    this.addCommands({
      cmd: () => {
        s(e);
      },
      undo: () => {
        s(t);
      },
      mustExec: !1
    }), this.#o();
  }
  shouldGetKeyboardEvents() {
    return this.isInEditMode();
  }
  enterInEditMode() {
    this.enableEditMode(), this.editorDiv.focus();
  }
  keydown(t) {
    t.target === this.div && t.key === "Enter" && (this.enterInEditMode(), t.preventDefault());
  }
  editorDivKeydown(t) {
    ot._keyboardManager.exec(this, t);
  }
  editorDivFocus(t) {
    this.isEditing = !0;
  }
  editorDivBlur(t) {
    this.isEditing = !1;
  }
  editorDivInput(t) {
    this.parent.div.classList.toggle("freetextEditing", this.isEmpty());
  }
  disableEditing() {
    this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
  }
  enableEditing() {
    this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
  }
  get canChangeContent() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    (this._isCopy || this.annotationElementId) && (t = this.x, e = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", this.#e), this.editorDiv.setAttribute("data-l10n-id", "pdfjs-free-text2"), this.editorDiv.setAttribute("data-l10n-attrs", "default-content"), this.enableEditing(), this.editorDiv.contentEditable = !0;
    const {
      style: s
    } = this.editorDiv;
    if (s.fontSize = `calc(${this.#s}px * var(--total-scale-factor))`, s.color = this.color, this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), this._isCopy || this.annotationElementId) {
      const [i, n] = this.parentDimensions;
      if (this.annotationElementId) {
        const {
          position: r
        } = this._initialData;
        let [a, o] = this.getInitialTranslation();
        [a, o] = this.pageTranslationToScreen(a, o);
        const [l, h] = this.pageDimensions, [c, u] = this.pageTranslation;
        let f, g;
        switch (this.rotation) {
          case 0:
            f = t + (r[0] - c) / l, g = e + this.height - (r[1] - u) / h;
            break;
          case 90:
            f = t + (r[0] - c) / l, g = e - (r[1] - u) / h, [a, o] = [o, -a];
            break;
          case 180:
            f = t - this.width + (r[0] - c) / l, g = e - (r[1] - u) / h, [a, o] = [-a, -o];
            break;
          case 270:
            f = t + (r[0] - c - this.height * h) / l, g = e + (r[1] - u - this.width * l) / h, [a, o] = [-o, a];
            break;
        }
        this.setAt(f * i, g * n, a, o);
      } else
        this._moveAfterPaste(t, e);
      this.#l(), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
    } else
      this._isDraggable = !1, this.editorDiv.contentEditable = !0;
    return this.div;
  }
  static #h(t) {
    return (t.nodeType === Node.TEXT_NODE ? t.nodeValue : t.innerText).replaceAll(Le, "");
  }
  editorDivPaste(t) {
    const e = t.clipboardData || window.clipboardData, {
      types: s
    } = e;
    if (s.length === 1 && s[0] === "text/plain")
      return;
    t.preventDefault();
    const i = ot.#d(e.getData("text") || "").replaceAll(Le, `
`);
    if (!i)
      return;
    const n = window.getSelection();
    if (!n.rangeCount)
      return;
    this.editorDiv.normalize(), n.deleteFromDocument();
    const r = n.getRangeAt(0);
    if (!i.includes(`
`)) {
      r.insertNode(document.createTextNode(i)), this.editorDiv.normalize(), n.collapseToStart();
      return;
    }
    const {
      startContainer: a,
      startOffset: o
    } = r, l = [], h = [];
    if (a.nodeType === Node.TEXT_NODE) {
      const f = a.parentElement;
      if (h.push(a.nodeValue.slice(o).replaceAll(Le, "")), f !== this.editorDiv) {
        let g = l;
        for (const p of this.editorDiv.childNodes) {
          if (p === f) {
            g = h;
            continue;
          }
          g.push(ot.#h(p));
        }
      }
      l.push(a.nodeValue.slice(0, o).replaceAll(Le, ""));
    } else if (a === this.editorDiv) {
      let f = l, g = 0;
      for (const p of this.editorDiv.childNodes)
        g++ === o && (f = h), f.push(ot.#h(p));
    }
    this.#t = `${l.join(`
`)}${i}${h.join(`
`)}`, this.#l();
    const c = new Range();
    let u = Math.sumPrecise(l.map((f) => f.length));
    for (const {
      firstChild: f
    } of this.editorDiv.childNodes)
      if (f.nodeType === Node.TEXT_NODE) {
        const g = f.nodeValue.length;
        if (u <= g) {
          c.setStart(f, u), c.setEnd(f, u);
          break;
        }
        u -= g;
      }
    n.removeAllRanges(), n.addRange(c);
  }
  #l() {
    if (this.editorDiv.replaceChildren(), !!this.#t)
      for (const t of this.#t.split(`
`)) {
        const e = document.createElement("div");
        e.append(t ? document.createTextNode(t) : document.createElement("br")), this.editorDiv.append(e);
      }
  }
  #u() {
    return this.#t.replaceAll(" ", " ");
  }
  static #d(t) {
    return t.replaceAll(" ", " ");
  }
  get contentDiv() {
    return this.editorDiv;
  }
  getPDFRect() {
    const t = ot._internalPadding * this.parentScale;
    return this.getRect(t, t);
  }
  static async deserialize(t, e, s) {
    let i = null;
    if (t instanceof zi) {
      const {
        data: {
          defaultAppearanceData: {
            fontSize: r,
            fontColor: a
          },
          rect: o,
          rotation: l,
          id: h,
          popupRef: c,
          richText: u,
          contentsObj: f,
          creationDate: g,
          modificationDate: p
        },
        textContent: b,
        textPosition: m,
        parent: {
          page: {
            pageNumber: y
          }
        }
      } = t;
      if (!b || b.length === 0)
        return null;
      i = t = {
        annotationType: F.FREETEXT,
        color: Array.from(a),
        fontSize: r,
        value: b.join(`
`),
        position: m,
        pageIndex: y - 1,
        rect: o.slice(0),
        rotation: l,
        annotationElementId: h,
        id: h,
        deleted: !1,
        popupRef: c,
        comment: f?.str || null,
        richText: u,
        creationDate: g,
        modificationDate: p
      };
    }
    const n = await super.deserialize(t, e, s);
    return n.#s = t.fontSize, n.color = T.makeHexColor(...t.color), n.#t = ot.#d(t.value), n._initialData = i, t.comment && n.setCommentData(t), n;
  }
  serialize(t = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const e = D._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : this.color), s = Object.assign(super.serialize(t), {
      color: e,
      fontSize: this.#s,
      value: this.#u()
    });
    return this.addComment(s), t ? (s.isCopy = !0, s) : this.annotationElementId && !this.#f(s) ? null : (s.id = this.annotationElementId, s);
  }
  #f(t) {
    const {
      value: e,
      fontSize: s,
      color: i,
      pageIndex: n
    } = this._initialData;
    return this.hasEditedComment || this._hasBeenMoved || t.value !== e || t.fontSize !== s || t.color.some((r, a) => r !== i[a]) || t.pageIndex !== n;
  }
  renderAnnotationElement(t) {
    const e = super.renderAnnotationElement(t);
    if (!e)
      return null;
    const {
      style: s
    } = e;
    s.fontSize = `calc(${this.#s}px * var(--total-scale-factor))`, s.color = this.color, e.replaceChildren();
    for (const i of this.#t.split(`
`)) {
      const n = document.createElement("div");
      n.append(i ? document.createTextNode(i) : document.createElement("br")), e.append(n);
    }
    return t.updateEdited({
      rect: this.getPDFRect(),
      popup: this._uiManager.hasCommentManager() || this.hasEditedComment ? this.comment : {
        text: this.#t
      }
    }), e;
  }
  resetAnnotationElement(t) {
    super.resetAnnotationElement(t), t.resetEdited();
  }
}
class P {
  static PRECISION = 1e-4;
  toSVGPath() {
    j("Abstract method `toSVGPath` must be implemented.");
  }
  get box() {
    j("Abstract getter `box` must be implemented.");
  }
  serialize(t, e) {
    j("Abstract method `serialize` must be implemented.");
  }
  static _rescale(t, e, s, i, n, r) {
    r ||= new Float32Array(t.length);
    for (let a = 0, o = t.length; a < o; a += 2)
      r[a] = e + t[a] * i, r[a + 1] = s + t[a + 1] * n;
    return r;
  }
  static _rescaleAndSwap(t, e, s, i, n, r) {
    r ||= new Float32Array(t.length);
    for (let a = 0, o = t.length; a < o; a += 2)
      r[a] = e + t[a + 1] * i, r[a + 1] = s + t[a] * n;
    return r;
  }
  static _translate(t, e, s, i) {
    i ||= new Float32Array(t.length);
    for (let n = 0, r = t.length; n < r; n += 2)
      i[n] = e + t[n], i[n + 1] = s + t[n + 1];
    return i;
  }
  static svgRound(t) {
    return Math.round(t * 1e4);
  }
  static _normalizePoint(t, e, s, i, n) {
    switch (n) {
      case 90:
        return [1 - e / s, t / i];
      case 180:
        return [1 - t / s, 1 - e / i];
      case 270:
        return [e / s, 1 - t / i];
      default:
        return [t / s, e / i];
    }
  }
  static _normalizePagePoint(t, e, s) {
    switch (s) {
      case 90:
        return [1 - e, t];
      case 180:
        return [1 - t, 1 - e];
      case 270:
        return [e, 1 - t];
      default:
        return [t, e];
    }
  }
  static createBezierPoints(t, e, s, i, n, r) {
    return [(t + 5 * s) / 6, (e + 5 * i) / 6, (5 * s + n) / 6, (5 * i + r) / 6, (s + n) / 2, (i + r) / 2];
  }
}
class Ut {
  #t;
  #e = [];
  #i;
  #s;
  #a = [];
  #r = new Float32Array(18);
  #n;
  #o;
  #h;
  #l;
  #u;
  #d;
  #f = [];
  static #m = 8;
  static #g = 2;
  static #c = Ut.#m + Ut.#g;
  constructor({
    x: t,
    y: e
  }, s, i, n, r, a = 0) {
    this.#t = s, this.#d = n * i, this.#s = r, this.#r.set([NaN, NaN, NaN, NaN, t, e], 6), this.#i = a, this.#l = Ut.#m * i, this.#h = Ut.#c * i, this.#u = i, this.#f.push(t, e);
  }
  isEmpty() {
    return isNaN(this.#r[8]);
  }
  #p() {
    const t = this.#r.subarray(4, 6), e = this.#r.subarray(16, 18), [s, i, n, r] = this.#t;
    return [(this.#n + (t[0] - e[0]) / 2 - s) / n, (this.#o + (t[1] - e[1]) / 2 - i) / r, (this.#n + (e[0] - t[0]) / 2 - s) / n, (this.#o + (e[1] - t[1]) / 2 - i) / r];
  }
  add({
    x: t,
    y: e
  }) {
    this.#n = t, this.#o = e;
    const [s, i, n, r] = this.#t;
    let [a, o, l, h] = this.#r.subarray(8, 12);
    const c = t - l, u = e - h, f = Math.hypot(c, u);
    if (f < this.#h)
      return !1;
    const g = f - this.#l, p = g / f, b = p * c, m = p * u;
    let y = a, A = o;
    a = l, o = h, l += b, h += m, this.#f?.push(t, e);
    const v = -m / g, w = b / g, S = v * this.#d, E = w * this.#d;
    return this.#r.set(this.#r.subarray(2, 8), 0), this.#r.set([l + S, h + E], 4), this.#r.set(this.#r.subarray(14, 18), 12), this.#r.set([l - S, h - E], 16), isNaN(this.#r[6]) ? (this.#a.length === 0 && (this.#r.set([a + S, o + E], 2), this.#a.push(NaN, NaN, NaN, NaN, (a + S - s) / n, (o + E - i) / r), this.#r.set([a - S, o - E], 14), this.#e.push(NaN, NaN, NaN, NaN, (a - S - s) / n, (o - E - i) / r)), this.#r.set([y, A, a, o, l, h], 6), !this.isEmpty()) : (this.#r.set([y, A, a, o, l, h], 6), Math.abs(Math.atan2(A - o, y - a) - Math.atan2(m, b)) < Math.PI / 2 ? ([a, o, l, h] = this.#r.subarray(2, 6), this.#a.push(NaN, NaN, NaN, NaN, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), [a, o, y, A] = this.#r.subarray(14, 18), this.#e.push(NaN, NaN, NaN, NaN, ((y + a) / 2 - s) / n, ((A + o) / 2 - i) / r), !0) : ([y, A, a, o, l, h] = this.#r.subarray(0, 6), this.#a.push(((y + 5 * a) / 6 - s) / n, ((A + 5 * o) / 6 - i) / r, ((5 * a + l) / 6 - s) / n, ((5 * o + h) / 6 - i) / r, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), [l, h, a, o, y, A] = this.#r.subarray(12, 18), this.#e.push(((y + 5 * a) / 6 - s) / n, ((A + 5 * o) / 6 - i) / r, ((5 * a + l) / 6 - s) / n, ((5 * o + h) / 6 - i) / r, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), !0));
  }
  toSVGPath() {
    if (this.isEmpty())
      return "";
    const t = this.#a, e = this.#e;
    if (isNaN(this.#r[6]) && !this.isEmpty())
      return this.#b();
    const s = [];
    s.push(`M${t[4]} ${t[5]}`);
    for (let i = 6; i < t.length; i += 6)
      isNaN(t[i]) ? s.push(`L${t[i + 4]} ${t[i + 5]}`) : s.push(`C${t[i]} ${t[i + 1]} ${t[i + 2]} ${t[i + 3]} ${t[i + 4]} ${t[i + 5]}`);
    this.#A(s);
    for (let i = e.length - 6; i >= 6; i -= 6)
      isNaN(e[i]) ? s.push(`L${e[i + 4]} ${e[i + 5]}`) : s.push(`C${e[i]} ${e[i + 1]} ${e[i + 2]} ${e[i + 3]} ${e[i + 4]} ${e[i + 5]}`);
    return this.#y(s), s.join(" ");
  }
  #b() {
    const [t, e, s, i] = this.#t, [n, r, a, o] = this.#p();
    return `M${(this.#r[2] - t) / s} ${(this.#r[3] - e) / i} L${(this.#r[4] - t) / s} ${(this.#r[5] - e) / i} L${n} ${r} L${a} ${o} L${(this.#r[16] - t) / s} ${(this.#r[17] - e) / i} L${(this.#r[14] - t) / s} ${(this.#r[15] - e) / i} Z`;
  }
  #y(t) {
    const e = this.#e;
    t.push(`L${e[4]} ${e[5]} Z`);
  }
  #A(t) {
    const [e, s, i, n] = this.#t, r = this.#r.subarray(4, 6), a = this.#r.subarray(16, 18), [o, l, h, c] = this.#p();
    t.push(`L${(r[0] - e) / i} ${(r[1] - s) / n} L${o} ${l} L${h} ${c} L${(a[0] - e) / i} ${(a[1] - s) / n}`);
  }
  newFreeDrawOutline(t, e, s, i, n, r) {
    return new Xi(t, e, s, i, n, r);
  }
  getOutlines() {
    const t = this.#a, e = this.#e, s = this.#r, [i, n, r, a] = this.#t, o = new Float32Array((this.#f?.length ?? 0) + 2);
    for (let c = 0, u = o.length - 2; c < u; c += 2)
      o[c] = (this.#f[c] - i) / r, o[c + 1] = (this.#f[c + 1] - n) / a;
    if (o[o.length - 2] = (this.#n - i) / r, o[o.length - 1] = (this.#o - n) / a, isNaN(s[6]) && !this.isEmpty())
      return this.#C(o);
    const l = new Float32Array(this.#a.length + 24 + this.#e.length);
    let h = t.length;
    for (let c = 0; c < h; c += 2) {
      if (isNaN(t[c])) {
        l[c] = l[c + 1] = NaN;
        continue;
      }
      l[c] = t[c], l[c + 1] = t[c + 1];
    }
    h = this.#v(l, h);
    for (let c = e.length - 6; c >= 6; c -= 6)
      for (let u = 0; u < 6; u += 2) {
        if (isNaN(e[c + u])) {
          l[h] = l[h + 1] = NaN, h += 2;
          continue;
        }
        l[h] = e[c + u], l[h + 1] = e[c + u + 1], h += 2;
      }
    return this.#E(l, h), this.newFreeDrawOutline(l, o, this.#t, this.#u, this.#i, this.#s);
  }
  #C(t) {
    const e = this.#r, [s, i, n, r] = this.#t, [a, o, l, h] = this.#p(), c = new Float32Array(36);
    return c.set([NaN, NaN, NaN, NaN, (e[2] - s) / n, (e[3] - i) / r, NaN, NaN, NaN, NaN, (e[4] - s) / n, (e[5] - i) / r, NaN, NaN, NaN, NaN, a, o, NaN, NaN, NaN, NaN, l, h, NaN, NaN, NaN, NaN, (e[16] - s) / n, (e[17] - i) / r, NaN, NaN, NaN, NaN, (e[14] - s) / n, (e[15] - i) / r], 0), this.newFreeDrawOutline(c, t, this.#t, this.#u, this.#i, this.#s);
  }
  #E(t, e) {
    const s = this.#e;
    return t.set([NaN, NaN, NaN, NaN, s[4], s[5]], e), e += 6;
  }
  #v(t, e) {
    const s = this.#r.subarray(4, 6), i = this.#r.subarray(16, 18), [n, r, a, o] = this.#t, [l, h, c, u] = this.#p();
    return t.set([NaN, NaN, NaN, NaN, (s[0] - n) / a, (s[1] - r) / o, NaN, NaN, NaN, NaN, l, h, NaN, NaN, NaN, NaN, c, u, NaN, NaN, NaN, NaN, (i[0] - n) / a, (i[1] - r) / o], e), e += 24;
  }
}
class Xi extends P {
  #t;
  #e = new Float32Array(4);
  #i;
  #s;
  #a;
  #r;
  #n;
  constructor(t, e, s, i, n, r) {
    super(), this.#n = t, this.#a = e, this.#t = s, this.#r = i, this.#i = n, this.#s = r, this.firstPoint = [NaN, NaN], this.lastPoint = [NaN, NaN], this.#o(r);
    const [a, o, l, h] = this.#e;
    for (let c = 0, u = t.length; c < u; c += 2)
      t[c] = (t[c] - a) / l, t[c + 1] = (t[c + 1] - o) / h;
    for (let c = 0, u = e.length; c < u; c += 2)
      e[c] = (e[c] - a) / l, e[c + 1] = (e[c + 1] - o) / h;
  }
  toSVGPath() {
    const t = [`M${this.#n[4]} ${this.#n[5]}`];
    for (let e = 6, s = this.#n.length; e < s; e += 6) {
      if (isNaN(this.#n[e])) {
        t.push(`L${this.#n[e + 4]} ${this.#n[e + 5]}`);
        continue;
      }
      t.push(`C${this.#n[e]} ${this.#n[e + 1]} ${this.#n[e + 2]} ${this.#n[e + 3]} ${this.#n[e + 4]} ${this.#n[e + 5]}`);
    }
    return t.push("Z"), t.join(" ");
  }
  serialize([t, e, s, i], n) {
    const r = s - t, a = i - e;
    let o, l;
    switch (n) {
      case 0:
        o = P._rescale(this.#n, t, i, r, -a), l = P._rescale(this.#a, t, i, r, -a);
        break;
      case 90:
        o = P._rescaleAndSwap(this.#n, t, e, r, a), l = P._rescaleAndSwap(this.#a, t, e, r, a);
        break;
      case 180:
        o = P._rescale(this.#n, s, e, -r, a), l = P._rescale(this.#a, s, e, -r, a);
        break;
      case 270:
        o = P._rescaleAndSwap(this.#n, s, i, -r, -a), l = P._rescaleAndSwap(this.#a, s, i, -r, -a);
        break;
    }
    return {
      outline: Array.from(o),
      points: [Array.from(l)]
    };
  }
  #o(t) {
    const e = this.#n;
    let s = e[4], i = e[5];
    const n = [s, i, s, i];
    let r = s, a = i, o = s, l = i;
    const h = t ? Math.max : Math.min, c = new Float32Array(4);
    for (let f = 6, g = e.length; f < g; f += 6) {
      const p = e[f + 4], b = e[f + 5];
      isNaN(e[f]) ? (T.pointBoundingBox(p, b, n), a > b ? (r = p, a = b) : a === b && (r = h(r, p)), l < b ? (o = p, l = b) : l === b && (o = h(o, p))) : (c[0] = c[1] = 1 / 0, c[2] = c[3] = -1 / 0, T.bezierBoundingBox(s, i, ...e.slice(f, f + 6), c), T.rectBoundingBox(c[0], c[1], c[2], c[3], n), a > c[1] ? (r = c[0], a = c[1]) : a === c[1] && (r = h(r, c[0])), l < c[3] ? (o = c[2], l = c[3]) : l === c[3] && (o = h(o, c[2]))), s = p, i = b;
    }
    const u = this.#e;
    u[0] = n[0] - this.#i, u[1] = n[1] - this.#i, u[2] = n[2] - n[0] + 2 * this.#i, u[3] = n[3] - n[1] + 2 * this.#i, this.firstPoint = [r, a], this.lastPoint = [o, l];
  }
  get box() {
    return this.#e;
  }
  newOutliner(t, e, s, i, n, r = 0) {
    return new Ut(t, e, s, i, n, r);
  }
  getNewOutline(t, e) {
    const [s, i, n, r] = this.#e, [a, o, l, h] = this.#t, c = n * l, u = r * h, f = s * l + a, g = i * h + o, p = this.newOutliner({
      x: this.#a[0] * c + f,
      y: this.#a[1] * u + g
    }, this.#t, this.#r, t, this.#s, e ?? this.#i);
    for (let b = 2; b < this.#a.length; b += 2)
      p.add({
        x: this.#a[b] * c + f,
        y: this.#a[b + 1] * u + g
      });
    return p.getOutlines();
  }
}
class ps {
  #t;
  #e;
  #i;
  #s = [];
  #a = [];
  constructor(t, e = 0, s = 0, i = !0) {
    const n = [1 / 0, 1 / 0, -1 / 0, -1 / 0], r = 10 ** -4;
    for (const {
      x: p,
      y: b,
      width: m,
      height: y
    } of t) {
      const A = Math.floor((p - e) / r) * r, v = Math.ceil((p + m + e) / r) * r, w = Math.floor((b - e) / r) * r, S = Math.ceil((b + y + e) / r) * r, E = [A, w, S, !0], _ = [v, w, S, !1];
      this.#s.push(E, _), T.rectBoundingBox(A, w, v, S, n);
    }
    const a = n[2] - n[0] + 2 * s, o = n[3] - n[1] + 2 * s, l = n[0] - s, h = n[1] - s;
    let c = i ? -1 / 0 : 1 / 0, u = 1 / 0;
    const f = this.#s.at(i ? -1 : -2), g = [f[0], f[2]];
    for (const p of this.#s) {
      const [b, m, y, A] = p;
      !A && i ? m < u ? (u = m, c = b) : m === u && (c = Math.max(c, b)) : A && !i && (m < u ? (u = m, c = b) : m === u && (c = Math.min(c, b))), p[0] = (b - l) / a, p[1] = (m - h) / o, p[2] = (y - h) / o;
    }
    this.#t = new Float32Array([l, h, a, o]), this.#e = [c, u], this.#i = g;
  }
  getOutlines() {
    this.#s.sort((e, s) => e[0] - s[0] || e[1] - s[1] || e[2] - s[2]);
    const t = [];
    for (const e of this.#s)
      e[3] ? (t.push(...this.#l(e)), this.#o(e)) : (this.#h(e), t.push(...this.#l(e)));
    return this.#r(t);
  }
  #r(t) {
    const e = [], s = /* @__PURE__ */ new Set();
    for (const r of t) {
      const [a, o, l] = r;
      e.push([a, o, r], [a, l, r]);
    }
    e.sort((r, a) => r[1] - a[1] || r[0] - a[0]);
    for (let r = 0, a = e.length; r < a; r += 2) {
      const o = e[r][2], l = e[r + 1][2];
      o.push(l), l.push(o), s.add(o), s.add(l);
    }
    const i = [];
    let n;
    for (; s.size > 0; ) {
      const r = s.values().next().value;
      let [a, o, l, h, c] = r;
      s.delete(r);
      let u = a, f = o;
      for (n = [a, l], i.push(n); ; ) {
        let g;
        if (s.has(h))
          g = h;
        else if (s.has(c))
          g = c;
        else
          break;
        s.delete(g), [a, o, l, h, c] = g, u !== a && (n.push(u, f, a, f === o ? o : l), u = a), f = f === o ? l : o;
      }
      n.push(u, f);
    }
    return new Rr(i, this.#t, this.#e, this.#i);
  }
  #n(t) {
    const e = this.#a;
    let s = 0, i = e.length - 1;
    for (; s <= i; ) {
      const n = s + i >> 1, r = e[n][0];
      if (r === t)
        return n;
      r < t ? s = n + 1 : i = n - 1;
    }
    return i + 1;
  }
  #o([, t, e]) {
    const s = this.#n(t);
    this.#a.splice(s, 0, [t, e]);
  }
  #h([, t, e]) {
    const s = this.#n(t);
    for (let i = s; i < this.#a.length; i++) {
      const [n, r] = this.#a[i];
      if (n !== t)
        break;
      if (n === t && r === e) {
        this.#a.splice(i, 1);
        return;
      }
    }
    for (let i = s - 1; i >= 0; i--) {
      const [n, r] = this.#a[i];
      if (n !== t)
        break;
      if (n === t && r === e) {
        this.#a.splice(i, 1);
        return;
      }
    }
  }
  #l(t) {
    const [e, s, i] = t, n = [[e, s, i]], r = this.#n(i);
    for (let a = 0; a < r; a++) {
      const [o, l] = this.#a[a];
      for (let h = 0, c = n.length; h < c; h++) {
        const [, u, f] = n[h];
        if (!(l <= u || f <= o)) {
          if (u >= o) {
            if (f > l)
              n[h][1] = l;
            else {
              if (c === 1)
                return [];
              n.splice(h, 1), h--, c--;
            }
            continue;
          }
          n[h][2] = o, f > l && n.push([e, l, f]);
        }
      }
    }
    return n;
  }
}
class Rr extends P {
  #t;
  #e;
  constructor(t, e, s, i) {
    super(), this.#e = t, this.#t = e, this.firstPoint = s, this.lastPoint = i;
  }
  toSVGPath() {
    const t = [];
    for (const e of this.#e) {
      let [s, i] = e;
      t.push(`M${s} ${i}`);
      for (let n = 2; n < e.length; n += 2) {
        const r = e[n], a = e[n + 1];
        r === s ? (t.push(`V${a}`), i = a) : a === i && (t.push(`H${r}`), s = r);
      }
      t.push("Z");
    }
    return t.join(" ");
  }
  serialize([t, e, s, i], n) {
    const r = [], a = s - t, o = i - e;
    for (const l of this.#e) {
      const h = new Array(l.length);
      for (let c = 0; c < l.length; c += 2)
        h[c] = t + l[c] * a, h[c + 1] = i - l[c + 1] * o;
      r.push(h);
    }
    return r;
  }
  get box() {
    return this.#t;
  }
  get classNamesForOutlining() {
    return ["highlightOutline"];
  }
}
class gs extends Ut {
  newFreeDrawOutline(t, e, s, i, n, r) {
    return new Fr(t, e, s, i, n, r);
  }
}
class Fr extends Xi {
  newOutliner(t, e, s, i, n, r = 0) {
    return new gs(t, e, s, i, n, r);
  }
}
class Z extends D {
  #t = null;
  #e = 0;
  #i;
  #s = null;
  #a = null;
  #r = null;
  #n = null;
  #o = 0;
  #h = null;
  #l = null;
  #u = null;
  #d = !1;
  #f = null;
  #m = null;
  #g = null;
  #c = "";
  #p;
  #b = "";
  static _defaultColor = null;
  static _defaultOpacity = 1;
  static _defaultThickness = 12;
  static _type = "highlight";
  static _editorType = F.HIGHLIGHT;
  static _freeHighlightId = -1;
  static _freeHighlight = null;
  static _freeHighlightClipId = "";
  static get _keyboardManager() {
    const t = Z.prototype;
    return I(this, "_keyboardManager", new Se([[["ArrowLeft", "mac+ArrowLeft"], t._moveCaret, {
      args: [0]
    }], [["ArrowRight", "mac+ArrowRight"], t._moveCaret, {
      args: [1]
    }], [["ArrowUp", "mac+ArrowUp"], t._moveCaret, {
      args: [2]
    }], [["ArrowDown", "mac+ArrowDown"], t._moveCaret, {
      args: [3]
    }]]));
  }
  constructor(t) {
    super({
      ...t,
      name: "highlightEditor"
    }), this.color = t.color || Z._defaultColor, this.#p = t.thickness || Z._defaultThickness, this.opacity = t.opacity || Z._defaultOpacity, this.#i = t.boxes || null, this.#b = t.methodOfCreation || "", this.#c = t.text || "", this._isDraggable = !1, this.defaultL10nId = "pdfjs-editor-highlight-editor", t.highlightId > -1 ? (this.#d = !0, this.#A(t), this.#w()) : this.#i && (this.#t = t.anchorNode, this.#e = t.anchorOffset, this.#n = t.focusNode, this.#o = t.focusOffset, this.#y(), this.#w(), this.rotate(this.rotation)), this.annotationElementId || this._uiManager.a11yAlert("pdfjs-editor-highlight-added-alert");
  }
  get telemetryInitialData() {
    return {
      action: "added",
      type: this.#d ? "free_highlight" : "highlight",
      color: this._uiManager.getNonHCMColorName(this.color),
      thickness: this.#p,
      methodOfCreation: this.#b
    };
  }
  get telemetryFinalData() {
    return {
      type: "highlight",
      color: this._uiManager.getNonHCMColorName(this.color)
    };
  }
  static computeTelemetryFinalData(t) {
    return {
      numberOfColors: t.get("color").size
    };
  }
  #y() {
    const t = new ps(this.#i, 1e-3);
    this.#l = t.getOutlines(), [this.x, this.y, this.width, this.height] = this.#l.box;
    const e = new ps(this.#i, 25e-4, 1e-3, this._uiManager.direction === "ltr");
    this.#r = e.getOutlines();
    const {
      firstPoint: s
    } = this.#l;
    this.#f = [(s[0] - this.x) / this.width, (s[1] - this.y) / this.height];
    const {
      lastPoint: i
    } = this.#r;
    this.#m = [(i[0] - this.x) / this.width, (i[1] - this.y) / this.height];
  }
  #A({
    highlightOutlines: t,
    highlightId: e,
    clipPathId: s
  }) {
    this.#l = t;
    const i = 1.5;
    if (this.#r = t.getNewOutline(this.#p / 2 + i, 25e-4), e >= 0)
      this.#u = e, this.#s = s, this.parent.drawLayer.finalizeDraw(e, {
        bbox: t.box,
        path: {
          d: t.toSVGPath()
        }
      }), this.#g = this.parent.drawLayer.drawOutline({
        rootClass: {
          highlightOutline: !0,
          free: !0
        },
        bbox: this.#r.box,
        path: {
          d: this.#r.toSVGPath()
        }
      }, !0);
    else if (this.parent) {
      const c = this.parent.viewport.rotation;
      this.parent.drawLayer.updateProperties(this.#u, {
        bbox: Z.#_(this.#l.box, (c - this.rotation + 360) % 360),
        path: {
          d: t.toSVGPath()
        }
      }), this.parent.drawLayer.updateProperties(this.#g, {
        bbox: Z.#_(this.#r.box, c),
        path: {
          d: this.#r.toSVGPath()
        }
      });
    }
    const [n, r, a, o] = t.box;
    switch (this.rotation) {
      case 0:
        this.x = n, this.y = r, this.width = a, this.height = o;
        break;
      case 90: {
        const [c, u] = this.parentDimensions;
        this.x = r, this.y = 1 - n, this.width = a * u / c, this.height = o * c / u;
        break;
      }
      case 180:
        this.x = 1 - n, this.y = 1 - r, this.width = a, this.height = o;
        break;
      case 270: {
        const [c, u] = this.parentDimensions;
        this.x = 1 - r, this.y = n, this.width = a * u / c, this.height = o * c / u;
        break;
      }
    }
    const {
      firstPoint: l
    } = t;
    this.#f = [(l[0] - n) / a, (l[1] - r) / o];
    const {
      lastPoint: h
    } = this.#r;
    this.#m = [(h[0] - n) / a, (h[1] - r) / o];
  }
  static initialize(t, e) {
    D.initialize(t, e), Z._defaultColor ||= e.highlightColors?.values().next().value || "#fff066";
  }
  static updateDefaultParams(t, e) {
    switch (t) {
      case N.HIGHLIGHT_COLOR:
        Z._defaultColor = e;
        break;
      case N.HIGHLIGHT_THICKNESS:
        Z._defaultThickness = e;
        break;
    }
  }
  translateInPage(t, e) {
  }
  get toolbarPosition() {
    return this.#m;
  }
  get commentButtonPosition() {
    return this.#f;
  }
  updateParams(t, e) {
    switch (t) {
      case N.HIGHLIGHT_COLOR:
        this.#C(e);
        break;
      case N.HIGHLIGHT_THICKNESS:
        this.#E(e);
        break;
    }
  }
  static get defaultPropertiesToUpdate() {
    return [[N.HIGHLIGHT_COLOR, Z._defaultColor], [N.HIGHLIGHT_THICKNESS, Z._defaultThickness]];
  }
  get propertiesToUpdate() {
    return [[N.HIGHLIGHT_COLOR, this.color || Z._defaultColor], [N.HIGHLIGHT_THICKNESS, this.#p || Z._defaultThickness], [N.HIGHLIGHT_FREE, this.#d]];
  }
  onUpdatedColor() {
    this.parent?.drawLayer.updateProperties(this.#u, {
      root: {
        fill: this.color,
        "fill-opacity": this.opacity
      }
    }), this.#a?.updateColor(this.color), super.onUpdatedColor();
  }
  #C(t) {
    const e = (n, r) => {
      this.color = n, this.opacity = r, this.onUpdatedColor();
    }, s = this.color, i = this.opacity;
    this.addCommands({
      cmd: e.bind(this, t, Z._defaultOpacity),
      undo: e.bind(this, s, i),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: N.HIGHLIGHT_COLOR,
      overwriteIfSameType: !0,
      keepUndo: !0
    }), this._reportTelemetry({
      action: "color_changed",
      color: this._uiManager.getNonHCMColorName(t)
    }, !0);
  }
  #E(t) {
    const e = this.#p, s = (i) => {
      this.#p = i, this.#v(i);
    };
    this.addCommands({
      cmd: s.bind(this, t),
      undo: s.bind(this, e),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: N.INK_THICKNESS,
      overwriteIfSameType: !0,
      keepUndo: !0
    }), this._reportTelemetry({
      action: "thickness_changed",
      thickness: t
    }, !0);
  }
  get toolbarButtons() {
    return this._uiManager.highlightColors ? [["colorPicker", this.#a = new At({
      editor: this
    })]] : super.toolbarButtons;
  }
  disableEditing() {
    super.disableEditing(), this.div.classList.toggle("disabled", !0);
  }
  enableEditing() {
    super.enableEditing(), this.div.classList.toggle("disabled", !1);
  }
  fixAndSetPosition() {
    return super.fixAndSetPosition(this.#k());
  }
  getBaseTranslation() {
    return [0, 0];
  }
  getRect(t, e) {
    return super.getRect(t, e, this.#k());
  }
  onceAdded(t) {
    this.annotationElementId || this.parent.addUndoableEditor(this), t && this.div.focus();
  }
  remove() {
    this.#x(), this._reportTelemetry({
      action: "deleted"
    }), super.remove();
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.#w(), this.isAttachedToDOM || this.parent.add(this)));
  }
  setParent(t) {
    let e = !1;
    this.parent && !t ? this.#x() : t && (this.#w(t), e = !this.parent && this.div?.classList.contains("selectedEditor")), super.setParent(t), this.show(this._isVisible), e && this.select();
  }
  #v(t) {
    this.#d && (this.#A({
      highlightOutlines: this.#l.getNewOutline(t / 2)
    }), this.fixAndSetPosition(), this.setDims());
  }
  #x() {
    this.#u === null || !this.parent || (this.parent.drawLayer.remove(this.#u), this.#u = null, this.parent.drawLayer.remove(this.#g), this.#g = null);
  }
  #w(t = this.parent) {
    this.#u === null && ({
      id: this.#u,
      clipPathId: this.#s
    } = t.drawLayer.draw({
      bbox: this.#l.box,
      root: {
        viewBox: "0 0 1 1",
        fill: this.color,
        "fill-opacity": this.opacity
      },
      rootClass: {
        highlight: !0,
        free: this.#d
      },
      path: {
        d: this.#l.toSVGPath()
      }
    }, !1, !0), this.#g = t.drawLayer.drawOutline({
      rootClass: {
        highlightOutline: !0,
        free: this.#d
      },
      bbox: this.#r.box,
      path: {
        d: this.#r.toSVGPath()
      }
    }, this.#d), this.#h && (this.#h.style.clipPath = this.#s));
  }
  static #_([t, e, s, i], n) {
    switch (n) {
      case 90:
        return [1 - e - i, t, i, s];
      case 180:
        return [1 - t - s, 1 - e - i, s, i];
      case 270:
        return [e, 1 - t - s, i, s];
    }
    return [t, e, s, i];
  }
  rotate(t) {
    const {
      drawLayer: e
    } = this.parent;
    let s;
    this.#d ? (t = (t - this.rotation + 360) % 360, s = Z.#_(this.#l.box, t)) : s = Z.#_([this.x, this.y, this.width, this.height], t), e.updateProperties(this.#u, {
      bbox: s,
      root: {
        "data-main-rotation": t
      }
    }), e.updateProperties(this.#g, {
      bbox: Z.#_(this.#r.box, t),
      root: {
        "data-main-rotation": t
      }
    });
  }
  render() {
    if (this.div)
      return this.div;
    const t = super.render();
    this.#c && (t.setAttribute("aria-label", this.#c), t.setAttribute("role", "mark")), this.#d ? t.classList.add("free") : this.div.addEventListener("keydown", this.#M.bind(this), {
      signal: this._uiManager._signal
    });
    const e = this.#h = document.createElement("div");
    return t.append(e), e.setAttribute("aria-hidden", "true"), e.className = "internal", e.style.clipPath = this.#s, this.setDims(), wi(this, this.#h, ["pointerover", "pointerleave"]), this.enableEditing(), t;
  }
  pointerover() {
    this.isSelected || this.parent?.drawLayer.updateProperties(this.#g, {
      rootClass: {
        hovered: !0
      }
    });
  }
  pointerleave() {
    this.isSelected || this.parent?.drawLayer.updateProperties(this.#g, {
      rootClass: {
        hovered: !1
      }
    });
  }
  #M(t) {
    Z._keyboardManager.exec(this, t);
  }
  _moveCaret(t) {
    switch (this.parent.unselect(this), t) {
      case 0:
      case 2:
        this.#P(!0);
        break;
      case 1:
      case 3:
        this.#P(!1);
        break;
    }
  }
  #P(t) {
    if (!this.#t)
      return;
    const e = window.getSelection();
    t ? e.setPosition(this.#t, this.#e) : e.setPosition(this.#n, this.#o);
  }
  select() {
    super.select(), this.#g && this.parent?.drawLayer.updateProperties(this.#g, {
      rootClass: {
        hovered: !1,
        selected: !0
      }
    });
  }
  unselect() {
    super.unselect(), this.#g && (this.parent?.drawLayer.updateProperties(this.#g, {
      rootClass: {
        selected: !1
      }
    }), this.#d || this.#P(!1));
  }
  get _mustFixPosition() {
    return !this.#d;
  }
  show(t = this._isVisible) {
    super.show(t), this.parent && (this.parent.drawLayer.updateProperties(this.#u, {
      rootClass: {
        hidden: !t
      }
    }), this.parent.drawLayer.updateProperties(this.#g, {
      rootClass: {
        hidden: !t
      }
    }));
  }
  #k() {
    return this.#d ? this.rotation : 0;
  }
  #O() {
    if (this.#d)
      return null;
    const [t, e] = this.pageDimensions, [s, i] = this.pageTranslation, n = this.#i, r = new Float32Array(n.length * 8);
    let a = 0;
    for (const {
      x: o,
      y: l,
      width: h,
      height: c
    } of n) {
      const u = o * t + s, f = (1 - l) * e + i;
      r[a] = r[a + 4] = u, r[a + 1] = r[a + 3] = f, r[a + 2] = r[a + 6] = u + h * t, r[a + 5] = r[a + 7] = f - c * e, a += 8;
    }
    return r;
  }
  #L(t) {
    return this.#l.serialize(t, this.#k());
  }
  static startHighlighting(t, e, {
    target: s,
    x: i,
    y: n
  }) {
    const {
      x: r,
      y: a,
      width: o,
      height: l
    } = s.getBoundingClientRect(), h = new AbortController(), c = t.combinedSignal(h), u = (f) => {
      h.abort(), this.#B(t, f);
    };
    window.addEventListener("blur", u, {
      signal: c
    }), window.addEventListener("pointerup", u, {
      signal: c
    }), window.addEventListener("pointerdown", K, {
      capture: !0,
      passive: !1,
      signal: c
    }), window.addEventListener("contextmenu", wt, {
      signal: c
    }), s.addEventListener("pointermove", this.#R.bind(this, t), {
      signal: c
    }), this._freeHighlight = new gs({
      x: i,
      y: n
    }, [r, a, o, l], t.scale, this._defaultThickness / 2, e, 1e-3), {
      id: this._freeHighlightId,
      clipPathId: this._freeHighlightClipId
    } = t.drawLayer.draw({
      bbox: [0, 0, 1, 1],
      root: {
        viewBox: "0 0 1 1",
        fill: this._defaultColor,
        "fill-opacity": this._defaultOpacity
      },
      rootClass: {
        highlight: !0,
        free: !0
      },
      path: {
        d: this._freeHighlight.toSVGPath()
      }
    }, !0, !0);
  }
  static #R(t, e) {
    this._freeHighlight.add(e) && t.drawLayer.updateProperties(this._freeHighlightId, {
      path: {
        d: this._freeHighlight.toSVGPath()
      }
    });
  }
  static #B(t, e) {
    this._freeHighlight.isEmpty() ? t.drawLayer.remove(this._freeHighlightId) : t.createAndAddNewEditor(e, !1, {
      highlightId: this._freeHighlightId,
      highlightOutlines: this._freeHighlight.getOutlines(),
      clipPathId: this._freeHighlightClipId,
      methodOfCreation: "main_toolbar"
    }), this._freeHighlightId = -1, this._freeHighlight = null, this._freeHighlightClipId = "";
  }
  static async deserialize(t, e, s) {
    let i = null;
    if (t instanceof Vi) {
      const {
        data: {
          quadPoints: g,
          rect: p,
          rotation: b,
          id: m,
          color: y,
          opacity: A,
          popupRef: v,
          richText: w,
          contentsObj: S,
          creationDate: E,
          modificationDate: _
        },
        parent: {
          page: {
            pageNumber: C
          }
        }
      } = t;
      i = t = {
        annotationType: F.HIGHLIGHT,
        color: Array.from(y),
        opacity: A,
        quadPoints: g,
        boxes: null,
        pageIndex: C - 1,
        rect: p.slice(0),
        rotation: b,
        annotationElementId: m,
        id: m,
        deleted: !1,
        popupRef: v,
        richText: w,
        comment: S?.str || null,
        creationDate: E,
        modificationDate: _
      };
    } else if (t instanceof Ds) {
      const {
        data: {
          inkLists: g,
          rect: p,
          rotation: b,
          id: m,
          color: y,
          borderStyle: {
            rawWidth: A
          },
          popupRef: v,
          richText: w,
          contentsObj: S,
          creationDate: E,
          modificationDate: _
        },
        parent: {
          page: {
            pageNumber: C
          }
        }
      } = t;
      i = t = {
        annotationType: F.HIGHLIGHT,
        color: Array.from(y),
        thickness: A,
        inkLists: g,
        boxes: null,
        pageIndex: C - 1,
        rect: p.slice(0),
        rotation: b,
        annotationElementId: m,
        id: m,
        deleted: !1,
        popupRef: v,
        richText: w,
        comment: S?.str || null,
        creationDate: E,
        modificationDate: _
      };
    }
    const {
      color: n,
      quadPoints: r,
      inkLists: a,
      opacity: o
    } = t, l = await super.deserialize(t, e, s);
    l.color = T.makeHexColor(...n), l.opacity = o || 1, a && (l.#p = t.thickness), l._initialData = i, t.comment && l.setCommentData(t);
    const [h, c] = l.pageDimensions, [u, f] = l.pageTranslation;
    if (r) {
      const g = l.#i = [];
      for (let p = 0; p < r.length; p += 8)
        g.push({
          x: (r[p] - u) / h,
          y: 1 - (r[p + 1] - f) / c,
          width: (r[p + 2] - r[p]) / h,
          height: (r[p + 1] - r[p + 5]) / c
        });
      l.#y(), l.#w(), l.rotate(l.rotation);
    } else if (a) {
      l.#d = !0;
      const g = a[0], p = {
        x: g[0] - u,
        y: c - (g[1] - f)
      }, b = new gs(p, [0, 0, h, c], 1, l.#p / 2, !0, 1e-3);
      for (let A = 0, v = g.length; A < v; A += 2)
        p.x = g[A] - u, p.y = c - (g[A + 1] - f), b.add(p);
      const {
        id: m,
        clipPathId: y
      } = e.drawLayer.draw({
        bbox: [0, 0, 1, 1],
        root: {
          viewBox: "0 0 1 1",
          fill: l.color,
          "fill-opacity": l._defaultOpacity
        },
        rootClass: {
          highlight: !0,
          free: !0
        },
        path: {
          d: b.toSVGPath()
        }
      }, !0, !0);
      l.#A({
        highlightOutlines: b.getOutlines(),
        highlightId: m,
        clipPathId: y
      }), l.#w(), l.rotate(l.parentRotation);
    }
    return l;
  }
  serialize(t = !1) {
    if (this.isEmpty() || t)
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const e = D._colorManager.convert(this._uiManager.getNonHCMColor(this.color)), s = super.serialize(t);
    return Object.assign(s, {
      color: e,
      opacity: this.opacity,
      thickness: this.#p,
      quadPoints: this.#O(),
      outlines: this.#L(s.rect)
    }), this.addComment(s), this.annotationElementId && !this.#F(s) ? null : (s.id = this.annotationElementId, s);
  }
  #F(t) {
    const {
      color: e
    } = this._initialData;
    return this.hasEditedComment || t.color.some((s, i) => s !== e[i]);
  }
  renderAnnotationElement(t) {
    return this.deleted ? (t.hide(), null) : (t.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
  static canCreateNewEmptyEditor() {
    return !1;
  }
}
class Yi {
  #t = /* @__PURE__ */ Object.create(null);
  updateProperty(t, e) {
    this[t] = e, this.updateSVGProperty(t, e);
  }
  updateProperties(t) {
    if (t)
      for (const [e, s] of Object.entries(t))
        e.startsWith("_") || this.updateProperty(e, s);
  }
  updateSVGProperty(t, e) {
    this.#t[t] = e;
  }
  toSVGProperties() {
    const t = this.#t;
    return this.#t = /* @__PURE__ */ Object.create(null), {
      root: t
    };
  }
  reset() {
    this.#t = /* @__PURE__ */ Object.create(null);
  }
  updateAll(t = this) {
    this.updateProperties(t);
  }
  clone() {
    j("Not implemented");
  }
}
class U extends D {
  #t = null;
  #e;
  _colorPicker = null;
  _drawId = null;
  static _currentDrawId = -1;
  static _currentParent = null;
  static #i = null;
  static #s = null;
  static #a = null;
  static _INNER_MARGIN = 3;
  constructor(t) {
    super(t), this.#e = t.mustBeCommitted || !1, this._addOutlines(t);
  }
  onUpdatedColor() {
    this._colorPicker?.update(this.color), super.onUpdatedColor();
  }
  _addOutlines(t) {
    t.drawOutlines && (this.#r(t), this.#h());
  }
  #r({
    drawOutlines: t,
    drawId: e,
    drawingOptions: s
  }) {
    this.#t = t, this._drawingOptions ||= s, this.annotationElementId || this._uiManager.a11yAlert(`pdfjs-editor-${this.editorType}-added-alert`), e >= 0 ? (this._drawId = e, this.parent.drawLayer.finalizeDraw(e, t.defaultProperties)) : this._drawId = this.#n(t, this.parent), this.#d(t.box);
  }
  #n(t, e) {
    const {
      id: s
    } = e.drawLayer.draw(U._mergeSVGProperties(this._drawingOptions.toSVGProperties(), t.defaultSVGProperties), !1, !1);
    return s;
  }
  static _mergeSVGProperties(t, e) {
    const s = new Set(Object.keys(t));
    for (const [i, n] of Object.entries(e))
      s.has(i) ? Object.assign(t[i], n) : t[i] = n;
    return t;
  }
  static getDefaultDrawingOptions(t) {
    j("Not implemented");
  }
  static get typesMap() {
    j("Not implemented");
  }
  static get isDrawer() {
    return !0;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  static updateDefaultParams(t, e) {
    const s = this.typesMap.get(t);
    s && this._defaultDrawingOptions.updateProperty(s, e), this._currentParent && (U.#i.updateProperty(s, e), this._currentParent.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  updateParams(t, e) {
    const s = this.constructor.typesMap.get(t);
    s && this._updateProperty(t, s, e);
  }
  static get defaultPropertiesToUpdate() {
    const t = [], e = this._defaultDrawingOptions;
    for (const [s, i] of this.typesMap)
      t.push([s, e[i]]);
    return t;
  }
  get propertiesToUpdate() {
    const t = [], {
      _drawingOptions: e
    } = this;
    for (const [s, i] of this.constructor.typesMap)
      t.push([s, e[i]]);
    return t;
  }
  _updateProperty(t, e, s) {
    const i = this._drawingOptions, n = i[e], r = (a) => {
      i.updateProperty(e, a);
      const o = this.#t.updateProperty(e, a);
      o && this.#d(o), this.parent?.drawLayer.updateProperties(this._drawId, i.toSVGProperties()), t === this.colorType && this.onUpdatedColor();
    };
    this.addCommands({
      cmd: r.bind(this, s),
      undo: r.bind(this, n),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: t,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _onResizing() {
    this.parent?.drawLayer.updateProperties(this._drawId, U._mergeSVGProperties(this.#t.getPathResizingSVGProperties(this.#u()), {
      bbox: this.#f()
    }));
  }
  _onResized() {
    this.parent?.drawLayer.updateProperties(this._drawId, U._mergeSVGProperties(this.#t.getPathResizedSVGProperties(this.#u()), {
      bbox: this.#f()
    }));
  }
  _onTranslating(t, e) {
    this.parent?.drawLayer.updateProperties(this._drawId, {
      bbox: this.#f()
    });
  }
  _onTranslated() {
    this.parent?.drawLayer.updateProperties(this._drawId, U._mergeSVGProperties(this.#t.getPathTranslatedSVGProperties(this.#u(), this.parentDimensions), {
      bbox: this.#f()
    }));
  }
  _onStartDragging() {
    this.parent?.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !0
      }
    });
  }
  _onStopDragging() {
    this.parent?.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !1
      }
    });
  }
  commit() {
    super.commit(), this.disableEditMode(), this.disableEditing();
  }
  disableEditing() {
    super.disableEditing(), this.div.classList.toggle("disabled", !0);
  }
  enableEditing() {
    super.enableEditing(), this.div.classList.toggle("disabled", !1);
  }
  getBaseTranslation() {
    return [0, 0];
  }
  get isResizable() {
    return !0;
  }
  onceAdded(t) {
    this.annotationElementId || this.parent.addUndoableEditor(this), this._isDraggable = !0, this.#e && (this.#e = !1, this.commit(), this.parent.setSelected(this), t && this.isOnScreen && this.div.focus());
  }
  remove() {
    this.#o(), super.remove();
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.#h(), this.#d(this.#t.box), this.isAttachedToDOM || this.parent.add(this)));
  }
  setParent(t) {
    let e = !1;
    this.parent && !t ? (this._uiManager.removeShouldRescale(this), this.#o()) : t && (this._uiManager.addShouldRescale(this), this.#h(t), e = !this.parent && this.div?.classList.contains("selectedEditor")), super.setParent(t), e && this.select();
  }
  #o() {
    this._drawId === null || !this.parent || (this.parent.drawLayer.remove(this._drawId), this._drawId = null, this._drawingOptions.reset());
  }
  #h(t = this.parent) {
    if (!(this._drawId !== null && this.parent === t)) {
      if (this._drawId !== null) {
        this.parent.drawLayer.updateParent(this._drawId, t.drawLayer);
        return;
      }
      this._drawingOptions.updateAll(), this._drawId = this.#n(this.#t, t);
    }
  }
  #l([t, e, s, i]) {
    const {
      parentDimensions: [n, r],
      rotation: a
    } = this;
    switch (a) {
      case 90:
        return [e, 1 - t, s * (r / n), i * (n / r)];
      case 180:
        return [1 - t, 1 - e, s, i];
      case 270:
        return [1 - e, t, s * (r / n), i * (n / r)];
      default:
        return [t, e, s, i];
    }
  }
  #u() {
    const {
      x: t,
      y: e,
      width: s,
      height: i,
      parentDimensions: [n, r],
      rotation: a
    } = this;
    switch (a) {
      case 90:
        return [1 - e, t, s * (n / r), i * (r / n)];
      case 180:
        return [1 - t, 1 - e, s, i];
      case 270:
        return [e, 1 - t, s * (n / r), i * (r / n)];
      default:
        return [t, e, s, i];
    }
  }
  #d(t) {
    [this.x, this.y, this.width, this.height] = this.#l(t), this.div && (this.fixAndSetPosition(), this.setDims()), this._onResized();
  }
  #f() {
    const {
      x: t,
      y: e,
      width: s,
      height: i,
      rotation: n,
      parentRotation: r,
      parentDimensions: [a, o]
    } = this;
    switch ((n * 4 + r) / 90) {
      case 1:
        return [1 - e - i, t, i, s];
      case 2:
        return [1 - t - s, 1 - e - i, s, i];
      case 3:
        return [e, 1 - t - s, i, s];
      case 4:
        return [t, e - s * (a / o), i * (o / a), s * (a / o)];
      case 5:
        return [1 - e, t, s * (a / o), i * (o / a)];
      case 6:
        return [1 - t - i * (o / a), 1 - e, i * (o / a), s * (a / o)];
      case 7:
        return [e - s * (a / o), 1 - t - i * (o / a), s * (a / o), i * (o / a)];
      case 8:
        return [t - s, e - i, s, i];
      case 9:
        return [1 - e, t - s, i, s];
      case 10:
        return [1 - t, 1 - e, s, i];
      case 11:
        return [e - i, 1 - t, i, s];
      case 12:
        return [t - i * (o / a), e, i * (o / a), s * (a / o)];
      case 13:
        return [1 - e - s * (a / o), t - i * (o / a), s * (a / o), i * (o / a)];
      case 14:
        return [1 - t, 1 - e - s * (a / o), i * (o / a), s * (a / o)];
      case 15:
        return [e, 1 - t, s * (a / o), i * (o / a)];
      default:
        return [t, e, s, i];
    }
  }
  rotate() {
    this.parent && this.parent.drawLayer.updateProperties(this._drawId, U._mergeSVGProperties({
      bbox: this.#f()
    }, this.#t.updateRotation((this.parentRotation - this.rotation + 360) % 360)));
  }
  onScaleChanging() {
    this.parent && this.#d(this.#t.updateParentDimensions(this.parentDimensions, this.parent.scale));
  }
  static onScaleChangingWhenDrawing() {
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    this._isCopy && (t = this.x, e = this.y);
    const s = super.render();
    s.classList.add("draw");
    const i = document.createElement("div");
    return s.append(i), i.setAttribute("aria-hidden", "true"), i.className = "internal", this.setDims(), this._uiManager.addShouldRescale(this), this.disableEditing(), this._isCopy && this._moveAfterPaste(t, e), s;
  }
  static createDrawerInstance(t, e, s, i, n) {
    j("Not implemented");
  }
  static startDrawing(t, e, s, i) {
    const {
      target: n,
      offsetX: r,
      offsetY: a,
      pointerId: o,
      pointerType: l
    } = i;
    if (H.isInitializedAndDifferentPointerType(l))
      return;
    const {
      viewport: {
        rotation: h
      }
    } = t, {
      width: c,
      height: u
    } = n.getBoundingClientRect(), f = U.#s = new AbortController(), g = t.combinedSignal(f);
    if (H.setPointer(l, o), window.addEventListener("pointerup", (p) => {
      H.isSamePointerIdOrRemove(p.pointerId) && this._endDraw(p);
    }, {
      signal: g
    }), window.addEventListener("pointercancel", (p) => {
      H.isSamePointerIdOrRemove(p.pointerId) && this._currentParent.endDrawingSession();
    }, {
      signal: g
    }), window.addEventListener("pointerdown", (p) => {
      H.isSamePointerType(p.pointerType) && (H.initializeAndAddPointerId(p.pointerId), U.#i.isCancellable() && (U.#i.removeLastElement(), U.#i.isEmpty() ? this._currentParent.endDrawingSession(!0) : this._endDraw(null)));
    }, {
      capture: !0,
      passive: !1,
      signal: g
    }), window.addEventListener("contextmenu", wt, {
      signal: g
    }), n.addEventListener("pointermove", this._drawMove.bind(this), {
      signal: g
    }), n.addEventListener("touchmove", (p) => {
      H.isSameTimeStamp(p.timeStamp) && K(p);
    }, {
      signal: g
    }), t.toggleDrawing(), e._editorUndoBar?.hide(), U.#i) {
      t.drawLayer.updateProperties(this._currentDrawId, U.#i.startNew(r, a, c, u, h));
      return;
    }
    e.updateUIForDefaultProperties(this), U.#i = this.createDrawerInstance(r, a, c, u, h), U.#a = this.getDefaultDrawingOptions(), this._currentParent = t, {
      id: this._currentDrawId
    } = t.drawLayer.draw(this._mergeSVGProperties(U.#a.toSVGProperties(), U.#i.defaultSVGProperties), !0, !1);
  }
  static _drawMove(t) {
    if (H.isSameTimeStamp(t.timeStamp), !U.#i)
      return;
    const {
      offsetX: e,
      offsetY: s,
      pointerId: i
    } = t;
    if (H.isSamePointerId(i)) {
      if (H.isUsingMultiplePointers()) {
        this._endDraw(t);
        return;
      }
      this._currentParent.drawLayer.updateProperties(this._currentDrawId, U.#i.add(e, s)), H.setTimeStamp(t.timeStamp), K(t);
    }
  }
  static _cleanup(t) {
    t && (this._currentDrawId = -1, this._currentParent = null, U.#i = null, U.#a = null, H.clearTimeStamp()), U.#s && (U.#s.abort(), U.#s = null, H.clearPointerIds());
  }
  static _endDraw(t) {
    const e = this._currentParent;
    if (e) {
      if (e.toggleDrawing(!0), this._cleanup(!1), t?.target === e.div && e.drawLayer.updateProperties(this._currentDrawId, U.#i.end(t.offsetX, t.offsetY)), this.supportMultipleDrawings) {
        const s = U.#i, i = this._currentDrawId, n = s.getLastElement();
        e.addCommands({
          cmd: () => {
            e.drawLayer.updateProperties(i, s.setLastElement(n));
          },
          undo: () => {
            e.drawLayer.updateProperties(i, s.removeLastElement());
          },
          mustExec: !1,
          type: N.DRAW_STEP
        });
        return;
      }
      this.endDrawing(!1);
    }
  }
  static endDrawing(t) {
    const e = this._currentParent;
    if (!e)
      return null;
    if (e.toggleDrawing(!0), e.cleanUndoStack(N.DRAW_STEP), !U.#i.isEmpty()) {
      const {
        pageDimensions: [s, i],
        scale: n
      } = e, r = e.createAndAddNewEditor({
        offsetX: 0,
        offsetY: 0
      }, !1, {
        drawId: this._currentDrawId,
        drawOutlines: U.#i.getOutlines(s * n, i * n, n, this._INNER_MARGIN),
        drawingOptions: U.#a,
        mustBeCommitted: !t
      });
      return this._cleanup(!0), r;
    }
    return e.drawLayer.remove(this._currentDrawId), this._cleanup(!0), null;
  }
  createDrawingOptions(t) {
  }
  static deserializeDraw(t, e, s, i, n, r) {
    j("Not implemented");
  }
  static async deserialize(t, e, s) {
    const {
      rawDims: {
        pageWidth: i,
        pageHeight: n,
        pageX: r,
        pageY: a
      }
    } = e.viewport, o = this.deserializeDraw(r, a, i, n, this._INNER_MARGIN, t), l = await super.deserialize(t, e, s);
    return l.createDrawingOptions(t), l.#r({
      drawOutlines: o
    }), l.#h(), l.onScaleChanging(), l.rotate(), l;
  }
  serializeDraw(t) {
    const [e, s] = this.pageTranslation, [i, n] = this.pageDimensions;
    return this.#t.serialize([e, s, i, n], t);
  }
  renderAnnotationElement(t) {
    return t.updateEdited({
      rect: this.getPDFRect()
    }), null;
  }
  static canCreateNewEmptyEditor() {
    return !1;
  }
}
class Nr {
  #t = new Float64Array(6);
  #e;
  #i;
  #s;
  #a;
  #r;
  #n = "";
  #o = 0;
  #h = new _e();
  #l;
  #u;
  constructor(t, e, s, i, n, r) {
    this.#l = s, this.#u = i, this.#s = n, this.#a = r, [t, e] = this.#d(t, e);
    const a = this.#e = [NaN, NaN, NaN, NaN, t, e];
    this.#r = [t, e], this.#i = [{
      line: a,
      points: this.#r
    }], this.#t.set(a, 0);
  }
  updateProperty(t, e) {
    t === "stroke-width" && (this.#a = e);
  }
  #d(t, e) {
    return P._normalizePoint(t, e, this.#l, this.#u, this.#s);
  }
  isEmpty() {
    return !this.#i || this.#i.length === 0;
  }
  isCancellable() {
    return this.#r.length <= 10;
  }
  add(t, e) {
    [t, e] = this.#d(t, e);
    const [s, i, n, r] = this.#t.subarray(2, 6), a = t - n, o = e - r;
    return Math.hypot(this.#l * a, this.#u * o) <= 2 ? null : (this.#r.push(t, e), isNaN(s) ? (this.#t.set([n, r, t, e], 2), this.#e.push(NaN, NaN, NaN, NaN, t, e), {
      path: {
        d: this.toSVGPath()
      }
    }) : (isNaN(this.#t[0]) && this.#e.splice(6, 6), this.#t.set([s, i, n, r, t, e], 0), this.#e.push(...P.createBezierPoints(s, i, n, r, t, e)), {
      path: {
        d: this.toSVGPath()
      }
    }));
  }
  end(t, e) {
    const s = this.add(t, e);
    return s || (this.#r.length === 2 ? {
      path: {
        d: this.toSVGPath()
      }
    } : null);
  }
  startNew(t, e, s, i, n) {
    this.#l = s, this.#u = i, this.#s = n, [t, e] = this.#d(t, e);
    const r = this.#e = [NaN, NaN, NaN, NaN, t, e];
    this.#r = [t, e];
    const a = this.#i.at(-1);
    return a && (a.line = new Float32Array(a.line), a.points = new Float32Array(a.points)), this.#i.push({
      line: r,
      points: this.#r
    }), this.#t.set(r, 0), this.#o = 0, this.toSVGPath(), null;
  }
  getLastElement() {
    return this.#i.at(-1);
  }
  setLastElement(t) {
    return this.#i ? (this.#i.push(t), this.#e = t.line, this.#r = t.points, this.#o = 0, {
      path: {
        d: this.toSVGPath()
      }
    }) : this.#h.setLastElement(t);
  }
  removeLastElement() {
    if (!this.#i)
      return this.#h.removeLastElement();
    this.#i.pop(), this.#n = "";
    for (let t = 0, e = this.#i.length; t < e; t++) {
      const {
        line: s,
        points: i
      } = this.#i[t];
      this.#e = s, this.#r = i, this.#o = 0, this.toSVGPath();
    }
    return {
      path: {
        d: this.#n
      }
    };
  }
  toSVGPath() {
    const t = P.svgRound(this.#e[4]), e = P.svgRound(this.#e[5]);
    if (this.#r.length === 2)
      return this.#n = `${this.#n} M ${t} ${e} Z`, this.#n;
    if (this.#r.length <= 6) {
      const i = this.#n.lastIndexOf("M");
      this.#n = `${this.#n.slice(0, i)} M ${t} ${e}`, this.#o = 6;
    }
    if (this.#r.length === 4) {
      const i = P.svgRound(this.#e[10]), n = P.svgRound(this.#e[11]);
      return this.#n = `${this.#n} L ${i} ${n}`, this.#o = 12, this.#n;
    }
    const s = [];
    this.#o === 0 && (s.push(`M ${t} ${e}`), this.#o = 6);
    for (let i = this.#o, n = this.#e.length; i < n; i += 6) {
      const [r, a, o, l, h, c] = this.#e.slice(i, i + 6).map(P.svgRound);
      s.push(`C${r} ${a} ${o} ${l} ${h} ${c}`);
    }
    return this.#n += s.join(" "), this.#o = this.#e.length, this.#n;
  }
  getOutlines(t, e, s, i) {
    const n = this.#i.at(-1);
    return n.line = new Float32Array(n.line), n.points = new Float32Array(n.points), this.#h.build(this.#i, t, e, s, this.#s, this.#a, i), this.#t = null, this.#e = null, this.#i = null, this.#n = null, this.#h;
  }
  get defaultSVGProperties() {
    return {
      root: {
        viewBox: "0 0 10000 10000"
      },
      rootClass: {
        draw: !0
      },
      bbox: [0, 0, 1, 1]
    };
  }
}
class _e extends P {
  #t;
  #e = 0;
  #i;
  #s;
  #a;
  #r;
  #n;
  #o;
  #h;
  build(t, e, s, i, n, r, a) {
    this.#a = e, this.#r = s, this.#n = i, this.#o = n, this.#h = r, this.#i = a ?? 0, this.#s = t, this.#d();
  }
  get thickness() {
    return this.#h;
  }
  setLastElement(t) {
    return this.#s.push(t), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  removeLastElement() {
    return this.#s.pop(), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  toSVGPath() {
    const t = [];
    for (const {
      line: e
    } of this.#s) {
      if (t.push(`M${P.svgRound(e[4])} ${P.svgRound(e[5])}`), e.length === 6) {
        t.push("Z");
        continue;
      }
      if (e.length === 12 && isNaN(e[6])) {
        t.push(`L${P.svgRound(e[10])} ${P.svgRound(e[11])}`);
        continue;
      }
      for (let s = 6, i = e.length; s < i; s += 6) {
        const [n, r, a, o, l, h] = e.subarray(s, s + 6).map(P.svgRound);
        t.push(`C${n} ${r} ${a} ${o} ${l} ${h}`);
      }
    }
    return t.join("");
  }
  serialize([t, e, s, i], n) {
    const r = [], a = [], [o, l, h, c] = this.#u();
    let u, f, g, p, b, m, y, A, v;
    switch (this.#o) {
      case 0:
        v = P._rescale, u = t, f = e + i, g = s, p = -i, b = t + o * s, m = e + (1 - l - c) * i, y = t + (o + h) * s, A = e + (1 - l) * i;
        break;
      case 90:
        v = P._rescaleAndSwap, u = t, f = e, g = s, p = i, b = t + l * s, m = e + o * i, y = t + (l + c) * s, A = e + (o + h) * i;
        break;
      case 180:
        v = P._rescale, u = t + s, f = e, g = -s, p = i, b = t + (1 - o - h) * s, m = e + l * i, y = t + (1 - o) * s, A = e + (l + c) * i;
        break;
      case 270:
        v = P._rescaleAndSwap, u = t + s, f = e + i, g = -s, p = -i, b = t + (1 - l - c) * s, m = e + (1 - o - h) * i, y = t + (1 - l) * s, A = e + (1 - o) * i;
        break;
    }
    for (const {
      line: w,
      points: S
    } of this.#s)
      r.push(v(w, u, f, g, p, n ? new Array(w.length) : null)), a.push(v(S, u, f, g, p, n ? new Array(S.length) : null));
    return {
      lines: r,
      points: a,
      rect: [b, m, y, A]
    };
  }
  static deserialize(t, e, s, i, n, {
    paths: {
      lines: r,
      points: a
    },
    rotation: o,
    thickness: l
  }) {
    const h = [];
    let c, u, f, g, p;
    switch (o) {
      case 0:
        p = P._rescale, c = -t / s, u = e / i + 1, f = 1 / s, g = -1 / i;
        break;
      case 90:
        p = P._rescaleAndSwap, c = -e / i, u = -t / s, f = 1 / i, g = 1 / s;
        break;
      case 180:
        p = P._rescale, c = t / s + 1, u = -e / i, f = -1 / s, g = 1 / i;
        break;
      case 270:
        p = P._rescaleAndSwap, c = e / i + 1, u = t / s + 1, f = -1 / i, g = -1 / s;
        break;
    }
    if (!r) {
      r = [];
      for (const m of a) {
        const y = m.length;
        if (y === 2) {
          r.push(new Float32Array([NaN, NaN, NaN, NaN, m[0], m[1]]));
          continue;
        }
        if (y === 4) {
          r.push(new Float32Array([NaN, NaN, NaN, NaN, m[0], m[1], NaN, NaN, NaN, NaN, m[2], m[3]]));
          continue;
        }
        const A = new Float32Array(3 * (y - 2));
        r.push(A);
        let [v, w, S, E] = m.subarray(0, 4);
        A.set([NaN, NaN, NaN, NaN, v, w], 0);
        for (let _ = 4; _ < y; _ += 2) {
          const C = m[_], k = m[_ + 1];
          A.set(P.createBezierPoints(v, w, S, E, C, k), (_ - 2) * 3), [v, w, S, E] = [S, E, C, k];
        }
      }
    }
    for (let m = 0, y = r.length; m < y; m++)
      h.push({
        line: p(r[m].map((A) => A ?? NaN), c, u, f, g),
        points: p(a[m].map((A) => A ?? NaN), c, u, f, g)
      });
    const b = new this.prototype.constructor();
    return b.build(h, s, i, 1, o, l, n), b;
  }
  #l(t = this.#h) {
    const e = this.#i + t / 2 * this.#n;
    return this.#o % 180 === 0 ? [e / this.#a, e / this.#r] : [e / this.#r, e / this.#a];
  }
  #u() {
    const [t, e, s, i] = this.#t, [n, r] = this.#l(0);
    return [t + n, e + r, s - 2 * n, i - 2 * r];
  }
  #d() {
    const t = this.#t = new Float32Array([1 / 0, 1 / 0, -1 / 0, -1 / 0]);
    for (const {
      line: i
    } of this.#s) {
      if (i.length <= 12) {
        for (let a = 4, o = i.length; a < o; a += 6)
          T.pointBoundingBox(i[a], i[a + 1], t);
        continue;
      }
      let n = i[4], r = i[5];
      for (let a = 6, o = i.length; a < o; a += 6) {
        const [l, h, c, u, f, g] = i.subarray(a, a + 6);
        T.bezierBoundingBox(n, r, l, h, c, u, f, g, t), n = f, r = g;
      }
    }
    const [e, s] = this.#l();
    t[0] = ct(t[0] - e, 0, 1), t[1] = ct(t[1] - s, 0, 1), t[2] = ct(t[2] + e, 0, 1), t[3] = ct(t[3] + s, 0, 1), t[2] -= t[0], t[3] -= t[1];
  }
  get box() {
    return this.#t;
  }
  updateProperty(t, e) {
    return t === "stroke-width" ? this.#f(e) : null;
  }
  #f(t) {
    const [e, s] = this.#l();
    this.#h = t;
    const [i, n] = this.#l(), [r, a] = [i - e, n - s], o = this.#t;
    return o[0] -= r, o[1] -= a, o[2] += 2 * r, o[3] += 2 * a, o;
  }
  updateParentDimensions([t, e], s) {
    const [i, n] = this.#l();
    this.#a = t, this.#r = e, this.#n = s;
    const [r, a] = this.#l(), o = r - i, l = a - n, h = this.#t;
    return h[0] -= o, h[1] -= l, h[2] += 2 * o, h[3] += 2 * l, h;
  }
  updateRotation(t) {
    return this.#e = t, {
      path: {
        transform: this.rotationTransform
      }
    };
  }
  get viewBox() {
    return this.#t.map(P.svgRound).join(" ");
  }
  get defaultProperties() {
    const [t, e] = this.#t;
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${P.svgRound(t)} ${P.svgRound(e)}`
      }
    };
  }
  get rotationTransform() {
    const [, , t, e] = this.#t;
    let s = 0, i = 0, n = 0, r = 0, a = 0, o = 0;
    switch (this.#e) {
      case 90:
        i = e / t, n = -t / e, a = t;
        break;
      case 180:
        s = -1, r = -1, a = t, o = e;
        break;
      case 270:
        i = -e / t, n = t / e, o = e;
        break;
      default:
        return "";
    }
    return `matrix(${s} ${i} ${n} ${r} ${P.svgRound(a)} ${P.svgRound(o)})`;
  }
  getPathResizingSVGProperties([t, e, s, i]) {
    const [n, r] = this.#l(), [a, o, l, h] = this.#t;
    if (Math.abs(l - n) <= P.PRECISION || Math.abs(h - r) <= P.PRECISION) {
      const p = t + s / 2 - (a + l / 2), b = e + i / 2 - (o + h / 2);
      return {
        path: {
          "transform-origin": `${P.svgRound(t)} ${P.svgRound(e)}`,
          transform: `${this.rotationTransform} translate(${p} ${b})`
        }
      };
    }
    const c = (s - 2 * n) / (l - 2 * n), u = (i - 2 * r) / (h - 2 * r), f = l / s, g = h / i;
    return {
      path: {
        "transform-origin": `${P.svgRound(a)} ${P.svgRound(o)}`,
        transform: `${this.rotationTransform} scale(${f} ${g}) translate(${P.svgRound(n)} ${P.svgRound(r)}) scale(${c} ${u}) translate(${P.svgRound(-n)} ${P.svgRound(-r)})`
      }
    };
  }
  getPathResizedSVGProperties([t, e, s, i]) {
    const [n, r] = this.#l(), a = this.#t, [o, l, h, c] = a;
    if (a[0] = t, a[1] = e, a[2] = s, a[3] = i, Math.abs(h - n) <= P.PRECISION || Math.abs(c - r) <= P.PRECISION) {
      const b = t + s / 2 - (o + h / 2), m = e + i / 2 - (l + c / 2);
      for (const {
        line: y,
        points: A
      } of this.#s)
        P._translate(y, b, m, y), P._translate(A, b, m, A);
      return {
        root: {
          viewBox: this.viewBox
        },
        path: {
          "transform-origin": `${P.svgRound(t)} ${P.svgRound(e)}`,
          transform: this.rotationTransform || null,
          d: this.toSVGPath()
        }
      };
    }
    const u = (s - 2 * n) / (h - 2 * n), f = (i - 2 * r) / (c - 2 * r), g = -u * (o + n) + t + n, p = -f * (l + r) + e + r;
    if (u !== 1 || f !== 1 || g !== 0 || p !== 0)
      for (const {
        line: b,
        points: m
      } of this.#s)
        P._rescale(b, g, p, u, f, b), P._rescale(m, g, p, u, f, m);
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${P.svgRound(t)} ${P.svgRound(e)}`,
        transform: this.rotationTransform || null,
        d: this.toSVGPath()
      }
    };
  }
  getPathTranslatedSVGProperties([t, e], s) {
    const [i, n] = s, r = this.#t, a = t - r[0], o = e - r[1];
    if (this.#a === i && this.#r === n)
      for (const {
        line: l,
        points: h
      } of this.#s)
        P._translate(l, a, o, l), P._translate(h, a, o, h);
    else {
      const l = this.#a / i, h = this.#r / n;
      this.#a = i, this.#r = n;
      for (const {
        line: c,
        points: u
      } of this.#s)
        P._rescale(c, a, o, l, h, c), P._rescale(u, a, o, l, h, u);
      r[2] *= l, r[3] *= h;
    }
    return r[0] = t, r[1] = e, {
      root: {
        viewBox: this.viewBox
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${P.svgRound(t)} ${P.svgRound(e)}`
      }
    };
  }
  get defaultSVGProperties() {
    const t = this.#t;
    return {
      root: {
        viewBox: this.viewBox
      },
      rootClass: {
        draw: !0
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${P.svgRound(t[0])} ${P.svgRound(t[1])}`,
        transform: this.rotationTransform || null
      },
      bbox: t
    };
  }
}
class qe extends Yi {
  constructor(t) {
    super(), this._viewParameters = t, super.updateProperties({
      fill: "none",
      stroke: D._defaultLineColor,
      "stroke-opacity": 1,
      "stroke-width": 1,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-miterlimit": 10
    });
  }
  updateSVGProperty(t, e) {
    t === "stroke-width" && (e ??= this["stroke-width"], e *= this._viewParameters.realScale), super.updateSVGProperty(t, e);
  }
  clone() {
    const t = new qe(this._viewParameters);
    return t.updateAll(this), t;
  }
}
class Ls extends U {
  static _type = "ink";
  static _editorType = F.INK;
  static _defaultDrawingOptions = null;
  constructor(t) {
    super({
      ...t,
      name: "inkEditor"
    }), this._willKeepAspectRatio = !0, this.defaultL10nId = "pdfjs-editor-ink-editor";
  }
  static initialize(t, e) {
    D.initialize(t, e), this._defaultDrawingOptions = new qe(e.viewParameters);
  }
  static getDefaultDrawingOptions(t) {
    const e = this._defaultDrawingOptions.clone();
    return e.updateProperties(t), e;
  }
  static get supportMultipleDrawings() {
    return !0;
  }
  static get typesMap() {
    return I(this, "typesMap", /* @__PURE__ */ new Map([[N.INK_THICKNESS, "stroke-width"], [N.INK_COLOR, "stroke"], [N.INK_OPACITY, "stroke-opacity"]]));
  }
  static createDrawerInstance(t, e, s, i, n) {
    return new Nr(t, e, s, i, n, this._defaultDrawingOptions["stroke-width"]);
  }
  static deserializeDraw(t, e, s, i, n, r) {
    return _e.deserialize(t, e, s, i, n, r);
  }
  static async deserialize(t, e, s) {
    let i = null;
    if (t instanceof Ds) {
      const {
        data: {
          inkLists: r,
          rect: a,
          rotation: o,
          id: l,
          color: h,
          opacity: c,
          borderStyle: {
            rawWidth: u
          },
          popupRef: f,
          richText: g,
          contentsObj: p,
          creationDate: b,
          modificationDate: m
        },
        parent: {
          page: {
            pageNumber: y
          }
        }
      } = t;
      i = t = {
        annotationType: F.INK,
        color: Array.from(h),
        thickness: u,
        opacity: c,
        paths: {
          points: r
        },
        boxes: null,
        pageIndex: y - 1,
        rect: a.slice(0),
        rotation: o,
        annotationElementId: l,
        id: l,
        deleted: !1,
        popupRef: f,
        richText: g,
        comment: p?.str || null,
        creationDate: b,
        modificationDate: m
      };
    }
    const n = await super.deserialize(t, e, s);
    return n._initialData = i, t.comment && n.setCommentData(t), n;
  }
  get toolbarButtons() {
    return this._colorPicker ||= new be(this), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return N.INK_COLOR;
  }
  get color() {
    return this._drawingOptions.stroke;
  }
  get opacity() {
    return this._drawingOptions["stroke-opacity"];
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    super.onScaleChanging();
    const {
      _drawId: t,
      _drawingOptions: e,
      parent: s
    } = this;
    e.updateSVGProperty("stroke-width"), s.drawLayer.updateProperties(t, e.toSVGProperties());
  }
  static onScaleChangingWhenDrawing() {
    const t = this._currentParent;
    t && (super.onScaleChangingWhenDrawing(), this._defaultDrawingOptions.updateSVGProperty("stroke-width"), t.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  createDrawingOptions({
    color: t,
    thickness: e,
    opacity: s
  }) {
    this._drawingOptions = Ls.getDefaultDrawingOptions({
      stroke: T.makeHexColor(...t),
      "stroke-width": e,
      "stroke-opacity": s
    });
  }
  serialize(t = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const {
      lines: e,
      points: s
    } = this.serializeDraw(t), {
      _drawingOptions: {
        stroke: i,
        "stroke-opacity": n,
        "stroke-width": r
      }
    } = this, a = Object.assign(super.serialize(t), {
      color: D._colorManager.convert(i),
      opacity: n,
      thickness: r,
      paths: {
        lines: e,
        points: s
      }
    });
    return this.addComment(a), t ? (a.isCopy = !0, a) : this.annotationElementId && !this.#t(a) ? null : (a.id = this.annotationElementId, a);
  }
  #t(t) {
    const {
      color: e,
      thickness: s,
      opacity: i,
      pageIndex: n
    } = this._initialData;
    return this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized || t.color.some((r, a) => r !== e[a]) || t.thickness !== s || t.opacity !== i || t.pageIndex !== n;
  }
  renderAnnotationElement(t) {
    if (this.deleted)
      return t.hide(), null;
    const {
      points: e,
      rect: s
    } = this.serializeDraw(!1);
    return t.updateEdited({
      rect: s,
      thickness: this._drawingOptions["stroke-width"],
      points: e,
      popup: this.comment
    }), null;
  }
}
class ms extends _e {
  toSVGPath() {
    let t = super.toSVGPath();
    return t.endsWith("Z") || (t += "Z"), t;
  }
}
const Ie = 8, he = 3;
class Bt {
  static #t = {
    maxDim: 512,
    sigmaSFactor: 0.02,
    sigmaR: 25,
    kernelSize: 16
  };
  static #e(t, e, s, i) {
    return s -= t, i -= e, s === 0 ? i > 0 ? 0 : 4 : s === 1 ? i + 6 : 2 - i;
  }
  static #i = new Int32Array([0, 1, -1, 1, -1, 0, -1, -1, 0, -1, 1, -1, 1, 0, 1, 1]);
  static #s(t, e, s, i, n, r, a) {
    const o = this.#e(s, i, n, r);
    for (let l = 0; l < 8; l++) {
      const h = (-l + o - a + 16) % 8, c = this.#i[2 * h], u = this.#i[2 * h + 1];
      if (t[(s + c) * e + (i + u)] !== 0)
        return h;
    }
    return -1;
  }
  static #a(t, e, s, i, n, r, a) {
    const o = this.#e(s, i, n, r);
    for (let l = 0; l < 8; l++) {
      const h = (l + o + a + 16) % 8, c = this.#i[2 * h], u = this.#i[2 * h + 1];
      if (t[(s + c) * e + (i + u)] !== 0)
        return h;
    }
    return -1;
  }
  static #r(t, e, s, i) {
    const n = t.length, r = new Int32Array(n);
    for (let h = 0; h < n; h++)
      r[h] = t[h] <= i ? 1 : 0;
    for (let h = 1; h < s - 1; h++)
      r[h * e] = r[h * e + e - 1] = 0;
    for (let h = 0; h < e; h++)
      r[h] = r[e * s - 1 - h] = 0;
    let a = 1, o;
    const l = [];
    for (let h = 1; h < s - 1; h++) {
      o = 1;
      for (let c = 1; c < e - 1; c++) {
        const u = h * e + c, f = r[u];
        if (f === 0)
          continue;
        let g = h, p = c;
        if (f === 1 && r[u - 1] === 0)
          a += 1, p -= 1;
        else if (f >= 1 && r[u + 1] === 0)
          a += 1, p += 1, f > 1 && (o = f);
        else {
          f !== 1 && (o = Math.abs(f));
          continue;
        }
        const b = [c, h], m = p === c + 1, y = {
          isHole: m,
          points: b,
          id: a,
          parent: 0
        };
        l.push(y);
        let A;
        for (const x of l)
          if (x.id === o) {
            A = x;
            break;
          }
        A ? A.isHole ? y.parent = m ? A.parent : o : y.parent = m ? o : A.parent : y.parent = m ? o : 0;
        const v = this.#s(r, e, h, c, g, p, 0);
        if (v === -1) {
          r[u] = -a, r[u] !== 1 && (o = Math.abs(r[u]));
          continue;
        }
        let w = this.#i[2 * v], S = this.#i[2 * v + 1];
        const E = h + w, _ = c + S;
        g = E, p = _;
        let C = h, k = c;
        for (; ; ) {
          const x = this.#a(r, e, C, k, g, p, 1);
          w = this.#i[2 * x], S = this.#i[2 * x + 1];
          const z = C + w, W = k + S;
          b.push(W, z);
          const O = C * e + k;
          if (r[O + 1] === 0 ? r[O] = -a : r[O] === 1 && (r[O] = a), z === h && W === c && C === E && k === _) {
            r[u] !== 1 && (o = Math.abs(r[u]));
            break;
          } else
            g = C, p = k, C = z, k = W;
        }
      }
    }
    return l;
  }
  static #n(t, e, s, i) {
    if (s - e <= 4) {
      for (let E = e; E < s - 2; E += 2)
        i.push(t[E], t[E + 1]);
      return;
    }
    const n = t[e], r = t[e + 1], a = t[s - 4] - n, o = t[s - 3] - r, l = Math.hypot(a, o), h = a / l, c = o / l, u = h * r - c * n, f = o / a, g = 1 / l, p = Math.atan(f), b = Math.cos(p), m = Math.sin(p), y = g * (Math.abs(b) + Math.abs(m)), A = g * (1 - y + y ** 2), v = Math.max(Math.atan(Math.abs(m + b) * A), Math.atan(Math.abs(m - b) * A));
    let w = 0, S = e;
    for (let E = e + 2; E < s - 2; E += 2) {
      const _ = Math.abs(u - h * t[E + 1] + c * t[E]);
      _ > w && (S = E, w = _);
    }
    w > (l * v) ** 2 ? (this.#n(t, e, S + 2, i), this.#n(t, S, s, i)) : i.push(n, r);
  }
  static #o(t) {
    const e = [], s = t.length;
    return this.#n(t, 0, s, e), e.push(t[s - 2], t[s - 1]), e.length <= 4 ? null : e;
  }
  static #h(t, e, s, i, n, r) {
    const a = new Float32Array(r ** 2), o = -2 * i ** 2, l = r >> 1;
    for (let p = 0; p < r; p++) {
      const b = (p - l) ** 2;
      for (let m = 0; m < r; m++)
        a[p * r + m] = Math.exp((b + (m - l) ** 2) / o);
    }
    const h = new Float32Array(256), c = -2 * n ** 2;
    for (let p = 0; p < 256; p++)
      h[p] = Math.exp(p ** 2 / c);
    const u = t.length, f = new Uint8Array(u), g = new Uint32Array(256);
    for (let p = 0; p < s; p++)
      for (let b = 0; b < e; b++) {
        const m = p * e + b, y = t[m];
        let A = 0, v = 0;
        for (let S = 0; S < r; S++) {
          const E = p + S - l;
          if (!(E < 0 || E >= s))
            for (let _ = 0; _ < r; _++) {
              const C = b + _ - l;
              if (C < 0 || C >= e)
                continue;
              const k = t[E * e + C], x = a[S * r + _] * h[Math.abs(k - y)];
              A += k * x, v += x;
            }
        }
        const w = f[m] = Math.round(A / v);
        g[w]++;
      }
    return [f, g];
  }
  static #l(t) {
    const e = new Uint32Array(256);
    for (const s of t)
      e[s]++;
    return e;
  }
  static #u(t) {
    const e = t.length, s = new Uint8ClampedArray(e >> 2);
    let i = -1 / 0, n = 1 / 0;
    for (let a = 0, o = s.length; a < o; a++) {
      const l = s[a] = t[a << 2];
      i = Math.max(i, l), n = Math.min(n, l);
    }
    const r = 255 / (i - n);
    for (let a = 0, o = s.length; a < o; a++)
      s[a] = (s[a] - n) * r;
    return s;
  }
  static #d(t) {
    let e, s = -1 / 0, i = -1 / 0;
    const n = t.findIndex((o) => o !== 0);
    let r = n, a = n;
    for (e = n; e < 256; e++) {
      const o = t[e];
      o > s && (e - r > i && (i = e - r, a = e - 1), s = o, r = e);
    }
    for (e = a - 1; e >= 0 && !(t[e] > t[e + 1]); e--)
      ;
    return e;
  }
  static #f(t) {
    const e = t, {
      width: s,
      height: i
    } = t, {
      maxDim: n
    } = this.#t;
    let r = s, a = i;
    if (s > n || i > n) {
      let u = s, f = i, g = Math.log2(Math.max(s, i) / n);
      const p = Math.floor(g);
      g = g === p ? p - 1 : p;
      for (let m = 0; m < g; m++) {
        r = Math.ceil(u / 2), a = Math.ceil(f / 2);
        const y = new OffscreenCanvas(r, a);
        y.getContext("2d").drawImage(t, 0, 0, u, f, 0, 0, r, a), u = r, f = a, t !== e && t.close(), t = y.transferToImageBitmap();
      }
      const b = Math.min(n / r, n / a);
      r = Math.round(r * b), a = Math.round(a * b);
    }
    const l = new OffscreenCanvas(r, a).getContext("2d", {
      willReadFrequently: !0
    });
    l.fillStyle = "white", l.fillRect(0, 0, r, a), l.filter = "grayscale(1)", l.drawImage(t, 0, 0, t.width, t.height, 0, 0, r, a);
    const h = l.getImageData(0, 0, r, a).data;
    return [this.#u(h), r, a];
  }
  static extractContoursFromText(t, {
    fontFamily: e,
    fontStyle: s,
    fontWeight: i
  }, n, r, a, o) {
    let l = new OffscreenCanvas(1, 1), h = l.getContext("2d", {
      alpha: !1
    });
    const c = 200, u = h.font = `${s} ${i} ${c}px ${e}`, {
      actualBoundingBoxLeft: f,
      actualBoundingBoxRight: g,
      actualBoundingBoxAscent: p,
      actualBoundingBoxDescent: b,
      fontBoundingBoxAscent: m,
      fontBoundingBoxDescent: y,
      width: A
    } = h.measureText(t), v = 1.5, w = Math.ceil(Math.max(Math.abs(f) + Math.abs(g) || 0, A) * v), S = Math.ceil(Math.max(Math.abs(p) + Math.abs(b) || c, Math.abs(m) + Math.abs(y) || c) * v);
    l = new OffscreenCanvas(w, S), h = l.getContext("2d", {
      alpha: !0,
      willReadFrequently: !0
    }), h.font = u, h.filter = "grayscale(1)", h.fillStyle = "white", h.fillRect(0, 0, w, S), h.fillStyle = "black", h.fillText(t, w * (v - 1) / 2, S * (3 - v) / 2);
    const E = this.#u(h.getImageData(0, 0, w, S).data), _ = this.#l(E), C = this.#d(_), k = this.#r(E, w, S, C);
    return this.processDrawnLines({
      lines: {
        curves: k,
        width: w,
        height: S
      },
      pageWidth: n,
      pageHeight: r,
      rotation: a,
      innerMargin: o,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static process(t, e, s, i, n) {
    const [r, a, o] = this.#f(t), [l, h] = this.#h(r, a, o, Math.hypot(a, o) * this.#t.sigmaSFactor, this.#t.sigmaR, this.#t.kernelSize), c = this.#d(h), u = this.#r(l, a, o, c);
    return this.processDrawnLines({
      lines: {
        curves: u,
        width: a,
        height: o
      },
      pageWidth: e,
      pageHeight: s,
      rotation: i,
      innerMargin: n,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static processDrawnLines({
    lines: t,
    pageWidth: e,
    pageHeight: s,
    rotation: i,
    innerMargin: n,
    mustSmooth: r,
    areContours: a
  }) {
    i % 180 !== 0 && ([e, s] = [s, e]);
    const {
      curves: o,
      width: l,
      height: h
    } = t, c = t.thickness ?? 0, u = [], f = Math.min(e / l, s / h), g = f / e, p = f / s, b = [];
    for (const {
      points: y
    } of o) {
      const A = r ? this.#o(y) : y;
      if (!A)
        continue;
      b.push(A);
      const v = A.length, w = new Float32Array(v), S = new Float32Array(3 * (v === 2 ? 2 : v - 2));
      if (u.push({
        line: S,
        points: w
      }), v === 2) {
        w[0] = A[0] * g, w[1] = A[1] * p, S.set([NaN, NaN, NaN, NaN, w[0], w[1]], 0);
        continue;
      }
      let [E, _, C, k] = A;
      E *= g, _ *= p, C *= g, k *= p, w.set([E, _, C, k], 0), S.set([NaN, NaN, NaN, NaN, E, _], 0);
      for (let x = 4; x < v; x += 2) {
        const z = w[x] = A[x] * g, W = w[x + 1] = A[x + 1] * p;
        S.set(P.createBezierPoints(E, _, C, k, z, W), (x - 2) * 3), [E, _, C, k] = [C, k, z, W];
      }
    }
    if (u.length === 0)
      return null;
    const m = a ? new ms() : new _e();
    return m.build(u, e, s, 1, i, a ? 0 : c, n), {
      outline: m,
      newCurves: b,
      areContours: a,
      thickness: c,
      width: l,
      height: h
    };
  }
  static async compressSignature({
    outlines: t,
    areContours: e,
    thickness: s,
    width: i,
    height: n
  }) {
    let r = 1 / 0, a = -1 / 0, o = 0;
    for (const A of t) {
      o += A.length;
      for (let v = 2, w = A.length; v < w; v++) {
        const S = A[v] - A[v - 2];
        r = Math.min(r, S), a = Math.max(a, S);
      }
    }
    let l;
    r >= -128 && a <= 127 ? l = Int8Array : r >= -32768 && a <= 32767 ? l = Int16Array : l = Int32Array;
    const h = t.length, c = Ie + he * h, u = new Uint32Array(c);
    let f = 0;
    u[f++] = c * Uint32Array.BYTES_PER_ELEMENT + (o - 2 * h) * l.BYTES_PER_ELEMENT, u[f++] = 0, u[f++] = i, u[f++] = n, u[f++] = e ? 0 : 1, u[f++] = Math.max(0, Math.floor(s ?? 0)), u[f++] = h, u[f++] = l.BYTES_PER_ELEMENT;
    for (const A of t)
      u[f++] = A.length - 2, u[f++] = A[0], u[f++] = A[1];
    const g = new CompressionStream("deflate-raw"), p = g.writable.getWriter();
    await p.ready, p.write(u);
    const b = l.prototype.constructor;
    for (const A of t) {
      const v = new b(A.length - 2);
      for (let w = 2, S = A.length; w < S; w++)
        v[w - 2] = A[w] - A[w - 2];
      p.write(v);
    }
    p.close();
    const m = await new Response(g.readable).arrayBuffer();
    return new Uint8Array(m).toBase64();
  }
  static async decompressSignature(t) {
    try {
      const e = Uint8Array.fromBase64(t), {
        readable: s,
        writable: i
      } = new DecompressionStream("deflate-raw"), n = i.getWriter();
      await n.ready, n.write(e).then(async () => {
        await n.ready, await n.close();
      }).catch(() => {
      });
      let r = null, a = 0;
      for await (const A of s)
        r ||= new Uint8Array(new Uint32Array(A.buffer, 0, 4)[0]), r.set(A, a), a += A.length;
      const o = new Uint32Array(r.buffer, 0, r.length >> 2), l = o[1];
      if (l !== 0)
        throw new Error(`Invalid version: ${l}`);
      const h = o[2], c = o[3], u = o[4] === 0, f = o[5], g = o[6], p = o[7], b = [], m = (Ie + he * g) * Uint32Array.BYTES_PER_ELEMENT;
      let y;
      switch (p) {
        case Int8Array.BYTES_PER_ELEMENT:
          y = new Int8Array(r.buffer, m);
          break;
        case Int16Array.BYTES_PER_ELEMENT:
          y = new Int16Array(r.buffer, m);
          break;
        case Int32Array.BYTES_PER_ELEMENT:
          y = new Int32Array(r.buffer, m);
          break;
      }
      a = 0;
      for (let A = 0; A < g; A++) {
        const v = o[he * A + Ie], w = new Float32Array(v + 2);
        b.push(w);
        for (let S = 0; S < he - 1; S++)
          w[S] = o[he * A + Ie + S + 1];
        for (let S = 0; S < v; S++)
          w[S + 2] = w[S] + y[a++];
      }
      return {
        areContours: u,
        thickness: f,
        outlines: b,
        width: h,
        height: c
      };
    } catch (e) {
      return R(`decompressSignature: ${e}`), null;
    }
  }
}
class Is extends Yi {
  constructor() {
    super(), super.updateProperties({
      fill: D._defaultLineColor,
      "stroke-width": 0
    });
  }
  clone() {
    const t = new Is();
    return t.updateAll(this), t;
  }
}
class Rs extends qe {
  constructor(t) {
    super(t), super.updateProperties({
      stroke: D._defaultLineColor,
      "stroke-width": 1
    });
  }
  clone() {
    const t = new Rs(this._viewParameters);
    return t.updateAll(this), t;
  }
}
class Tt extends U {
  #t = !1;
  #e = null;
  #i = null;
  #s = null;
  static _type = "signature";
  static _editorType = F.SIGNATURE;
  static _defaultDrawingOptions = null;
  constructor(t) {
    super({
      ...t,
      mustBeCommitted: !0,
      name: "signatureEditor"
    }), this._willKeepAspectRatio = !0, this.#i = t.signatureData || null, this.#e = null, this.defaultL10nId = "pdfjs-editor-signature-editor1";
  }
  static initialize(t, e) {
    D.initialize(t, e), this._defaultDrawingOptions = new Is(), this._defaultDrawnSignatureOptions = new Rs(e.viewParameters);
  }
  static getDefaultDrawingOptions(t) {
    const e = this._defaultDrawingOptions.clone();
    return e.updateProperties(t), e;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  static get typesMap() {
    return I(this, "typesMap", /* @__PURE__ */ new Map());
  }
  static get isDrawer() {
    return !1;
  }
  get telemetryFinalData() {
    return {
      type: "signature",
      hasDescription: !!this.#e
    };
  }
  static computeTelemetryFinalData(t) {
    const e = t.get("hasDescription");
    return {
      hasAltText: e.get(!0) ?? 0,
      hasNoAltText: e.get(!1) ?? 0
    };
  }
  get isResizable() {
    return !0;
  }
  onScaleChanging() {
    this._drawId !== null && super.onScaleChanging();
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    const {
      _isCopy: s
    } = this;
    if (s && (this._isCopy = !1, t = this.x, e = this.y), super.render(), this._drawId === null)
      if (this.#i) {
        const {
          lines: i,
          mustSmooth: n,
          areContours: r,
          description: a,
          uuid: o,
          heightInPage: l
        } = this.#i, {
          rawDims: {
            pageWidth: h,
            pageHeight: c
          },
          rotation: u
        } = this.parent.viewport, f = Bt.processDrawnLines({
          lines: i,
          pageWidth: h,
          pageHeight: c,
          rotation: u,
          innerMargin: Tt._INNER_MARGIN,
          mustSmooth: n,
          areContours: r
        });
        this.addSignature(f, l, a, o);
      } else
        this.div.setAttribute("data-l10n-args", JSON.stringify({
          description: ""
        })), this.div.hidden = !0, this._uiManager.getSignature(this);
    else
      this.div.setAttribute("data-l10n-args", JSON.stringify({
        description: this.#e || ""
      }));
    return s && (this._isCopy = !0, this._moveAfterPaste(t, e)), this.div;
  }
  setUuid(t) {
    this.#s = t, this.addEditToolbar();
  }
  getUuid() {
    return this.#s;
  }
  get description() {
    return this.#e;
  }
  set description(t) {
    this.#e = t, this.div && (this.div.setAttribute("data-l10n-args", JSON.stringify({
      description: t
    })), super.addEditToolbar().then((e) => {
      e?.updateEditSignatureButton(t);
    }));
  }
  getSignaturePreview() {
    const {
      newCurves: t,
      areContours: e,
      thickness: s,
      width: i,
      height: n
    } = this.#i, r = Math.max(i, n), a = Bt.processDrawnLines({
      lines: {
        curves: t.map((o) => ({
          points: o
        })),
        thickness: s,
        width: i,
        height: n
      },
      pageWidth: r,
      pageHeight: r,
      rotation: 0,
      innerMargin: 0,
      mustSmooth: !1,
      areContours: e
    });
    return {
      areContours: e,
      outline: a.outline
    };
  }
  get toolbarButtons() {
    return this._uiManager.signatureManager ? [["editSignature", this._uiManager.signatureManager]] : super.toolbarButtons;
  }
  addSignature(t, e, s, i) {
    const {
      x: n,
      y: r
    } = this, {
      outline: a
    } = this.#i = t;
    this.#t = a instanceof ms, this.description = s;
    let o;
    this.#t ? o = Tt.getDefaultDrawingOptions() : (o = Tt._defaultDrawnSignatureOptions.clone(), o.updateProperties({
      "stroke-width": a.thickness
    })), this._addOutlines({
      drawOutlines: a,
      drawingOptions: o
    });
    const [, l] = this.pageDimensions;
    let h = e / l;
    h = h >= 1 ? 0.5 : h, this.width *= h / this.height, this.width >= 1 && (h *= 0.9 / this.width, this.width = 0.9), this.height = h, this.setDims(), this.x = n, this.y = r, this.center(), this._onResized(), this.onScaleChanging(), this.rotate(), this._uiManager.addToAnnotationStorage(this), this.setUuid(i), this._reportTelemetry({
      action: "pdfjs.signature.inserted",
      data: {
        hasBeenSaved: !!i,
        hasDescription: !!s
      }
    }), this.div.hidden = !1;
  }
  getFromImage(t) {
    const {
      rawDims: {
        pageWidth: e,
        pageHeight: s
      },
      rotation: i
    } = this.parent.viewport;
    return Bt.process(t, e, s, i, Tt._INNER_MARGIN);
  }
  getFromText(t, e) {
    const {
      rawDims: {
        pageWidth: s,
        pageHeight: i
      },
      rotation: n
    } = this.parent.viewport;
    return Bt.extractContoursFromText(t, e, s, i, n, Tt._INNER_MARGIN);
  }
  getDrawnSignature(t) {
    const {
      rawDims: {
        pageWidth: e,
        pageHeight: s
      },
      rotation: i
    } = this.parent.viewport;
    return Bt.processDrawnLines({
      lines: t,
      pageWidth: e,
      pageHeight: s,
      rotation: i,
      innerMargin: Tt._INNER_MARGIN,
      mustSmooth: !1,
      areContours: !1
    });
  }
  createDrawingOptions({
    areContours: t,
    thickness: e
  }) {
    t ? this._drawingOptions = Tt.getDefaultDrawingOptions() : (this._drawingOptions = Tt._defaultDrawnSignatureOptions.clone(), this._drawingOptions.updateProperties({
      "stroke-width": e
    }));
  }
  serialize(t = !1) {
    if (this.isEmpty())
      return null;
    const {
      lines: e,
      points: s
    } = this.serializeDraw(t), {
      _drawingOptions: {
        "stroke-width": i
      }
    } = this, n = Object.assign(super.serialize(t), {
      isSignature: !0,
      areContours: this.#t,
      color: [0, 0, 0],
      thickness: this.#t ? 0 : i
    });
    return this.addComment(n), t ? (n.paths = {
      lines: e,
      points: s
    }, n.uuid = this.#s, n.isCopy = !0) : n.lines = e, this.#e && (n.accessibilityData = {
      type: "Figure",
      alt: this.#e
    }), n;
  }
  static deserializeDraw(t, e, s, i, n, r) {
    return r.areContours ? ms.deserialize(t, e, s, i, n, r) : _e.deserialize(t, e, s, i, n, r);
  }
  static async deserialize(t, e, s) {
    const i = await super.deserialize(t, e, s);
    return i.#t = t.areContours, i.description = t.accessibilityData?.alt || "", i.#s = t.uuid, i;
  }
}
class Or extends D {
  #t = null;
  #e = null;
  #i = null;
  #s = null;
  #a = null;
  #r = "";
  #n = null;
  #o = !1;
  #h = null;
  #l = !1;
  #u = !1;
  static _type = "stamp";
  static _editorType = F.STAMP;
  constructor(t) {
    super({
      ...t,
      name: "stampEditor"
    }), this.#s = t.bitmapUrl, this.#a = t.bitmapFile, this.defaultL10nId = "pdfjs-editor-stamp-editor";
  }
  static initialize(t, e) {
    D.initialize(t, e);
  }
  static isHandlingMimeForPasting(t) {
    return Ne.includes(t);
  }
  static paste(t, e) {
    e.pasteEditor({
      mode: F.STAMP
    }, {
      bitmapFile: t.getAsFile()
    });
  }
  altTextFinish() {
    this._uiManager.useNewAltTextFlow && (this.div.hidden = !1), super.altTextFinish();
  }
  get telemetryFinalData() {
    return {
      type: "stamp",
      hasAltText: !!this.altTextData?.altText
    };
  }
  static computeTelemetryFinalData(t) {
    const e = t.get("hasAltText");
    return {
      hasAltText: e.get(!0) ?? 0,
      hasNoAltText: e.get(!1) ?? 0
    };
  }
  #d(t, e = !1) {
    if (!t) {
      this.remove();
      return;
    }
    this.#t = t.bitmap, e || (this.#e = t.id, this.#l = t.isSvg), t.file && (this.#r = t.file.name), this.#g();
  }
  #f() {
    if (this.#i = null, this._uiManager.enableWaiting(!1), !!this.#n) {
      if (this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && this.#t) {
        this.addEditToolbar().then(() => {
          this._editToolbar.hide(), this._uiManager.editAltText(this, !0);
        });
        return;
      }
      if (!this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && this.#t) {
        this._reportTelemetry({
          action: "pdfjs.image.image_added",
          data: {
            alt_text_modal: !1,
            alt_text_type: "empty"
          }
        });
        try {
          this.mlGuessAltText();
        } catch {
        }
      }
      this.div.focus();
    }
  }
  async mlGuessAltText(t = null, e = !0) {
    if (this.hasAltTextData())
      return null;
    const {
      mlManager: s
    } = this._uiManager;
    if (!s)
      throw new Error("No ML.");
    if (!await s.isEnabledFor("altText"))
      throw new Error("ML isn't enabled for alt text.");
    const {
      data: i,
      width: n,
      height: r
    } = t || this.copyCanvas(null, null, !0).imageData, a = await s.guess({
      name: "altText",
      request: {
        data: i,
        width: n,
        height: r,
        channels: i.length / (n * r)
      }
    });
    if (!a)
      throw new Error("No response from the AI service.");
    if (a.error)
      throw new Error("Error from the AI service.");
    if (a.cancel)
      return null;
    if (!a.output)
      throw new Error("No valid response from the AI service.");
    const o = a.output;
    return await this.setGuessedAltText(o), e && !this.hasAltTextData() && (this.altTextData = {
      alt: o,
      decorative: !1
    }), o;
  }
  #m() {
    if (this.#e) {
      this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(this.#e).then((s) => this.#d(s, !0)).finally(() => this.#f());
      return;
    }
    if (this.#s) {
      const s = this.#s;
      this.#s = null, this._uiManager.enableWaiting(!0), this.#i = this._uiManager.imageManager.getFromUrl(s).then((i) => this.#d(i)).finally(() => this.#f());
      return;
    }
    if (this.#a) {
      const s = this.#a;
      this.#a = null, this._uiManager.enableWaiting(!0), this.#i = this._uiManager.imageManager.getFromFile(s).then((i) => this.#d(i)).finally(() => this.#f());
      return;
    }
    const t = document.createElement("input");
    t.type = "file", t.accept = Ne.join(",");
    const e = this._uiManager._signal;
    this.#i = new Promise((s) => {
      t.addEventListener("change", async () => {
        if (!t.files || t.files.length === 0)
          this.remove();
        else {
          this._uiManager.enableWaiting(!0);
          const i = await this._uiManager.imageManager.getFromFile(t.files[0]);
          this._reportTelemetry({
            action: "pdfjs.image.image_selected",
            data: {
              alt_text_modal: this._uiManager.useNewAltTextFlow
            }
          }), this.#d(i);
        }
        s();
      }, {
        signal: e
      }), t.addEventListener("cancel", () => {
        this.remove(), s();
      }, {
        signal: e
      });
    }).finally(() => this.#f()), t.click();
  }
  remove() {
    this.#e && (this.#t = null, this._uiManager.imageManager.deleteId(this.#e), this.#n?.remove(), this.#n = null, this.#h && (clearTimeout(this.#h), this.#h = null)), super.remove();
  }
  rebuild() {
    if (!this.parent) {
      this.#e && this.#m();
      return;
    }
    super.rebuild(), this.div !== null && (this.#e && this.#n === null && this.#m(), this.isAttachedToDOM || this.parent.add(this));
  }
  onceAdded(t) {
    this._isDraggable = !0, t && this.div.focus();
  }
  isEmpty() {
    return !(this.#i || this.#t || this.#s || this.#a || this.#e || this.#o);
  }
  get toolbarButtons() {
    return [["altText", this.createAltText()]];
  }
  get isResizable() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    return this._isCopy && (t = this.x, e = this.y), super.render(), this.div.hidden = !0, this.createAltText(), this.#o || (this.#t ? this.#g() : this.#m()), this._isCopy && this._moveAfterPaste(t, e), this._uiManager.addShouldRescale(this), this.div;
  }
  setCanvas(t, e) {
    const {
      id: s,
      bitmap: i
    } = this._uiManager.imageManager.getFromCanvas(t, e);
    e.remove(), s && this._uiManager.imageManager.isValidId(s) && (this.#e = s, i && (this.#t = i), this.#o = !1, this.#g());
  }
  _onResized() {
    this.onScaleChanging();
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    this.#h !== null && clearTimeout(this.#h);
    const t = 200;
    this.#h = setTimeout(() => {
      this.#h = null, this.#p();
    }, t);
  }
  #g() {
    const {
      div: t
    } = this;
    let {
      width: e,
      height: s
    } = this.#t;
    const [i, n] = this.pageDimensions, r = 0.75;
    if (this.width)
      e = this.width * i, s = this.height * n;
    else if (e > r * i || s > r * n) {
      const o = Math.min(r * i / e, r * n / s);
      e *= o, s *= o;
    }
    this._uiManager.enableWaiting(!1);
    const a = this.#n = document.createElement("canvas");
    a.setAttribute("role", "img"), this.addContainer(a), this.width = e / i, this.height = s / n, this.setDims(), this._initialOptions?.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, (!this._uiManager.useNewAltTextWhenAddingImage || !this._uiManager.useNewAltTextFlow || this.annotationElementId) && (t.hidden = !1), this.#p(), this.#u || (this.parent.addUndoableEditor(this), this.#u = !0), this._reportTelemetry({
      action: "inserted_image"
    }), this.#r && this.div.setAttribute("aria-description", this.#r), this.annotationElementId || this._uiManager.a11yAlert("pdfjs-editor-stamp-added-alert");
  }
  copyCanvas(t, e, s = !1) {
    t || (t = 224);
    const {
      width: i,
      height: n
    } = this.#t, r = new Et();
    let a = this.#t, o = i, l = n, h = null;
    if (e) {
      if (i > e || n > e) {
        const S = Math.min(e / i, e / n);
        o = Math.floor(i * S), l = Math.floor(n * S);
      }
      h = document.createElement("canvas");
      const u = h.width = Math.ceil(o * r.sx), f = h.height = Math.ceil(l * r.sy);
      this.#l || (a = this.#c(u, f));
      const g = h.getContext("2d");
      g.filter = this._uiManager.hcmFilter;
      let p = "white", b = "#cfcfd8";
      this._uiManager.hcmFilter !== "none" ? b = "black" : cn.isDarkMode && (p = "#8f8f9d", b = "#42414d");
      const m = 15, y = m * r.sx, A = m * r.sy, v = new OffscreenCanvas(y * 2, A * 2), w = v.getContext("2d");
      w.fillStyle = p, w.fillRect(0, 0, y * 2, A * 2), w.fillStyle = b, w.fillRect(0, 0, y, A), w.fillRect(y, A, y, A), g.fillStyle = g.createPattern(v, "repeat"), g.fillRect(0, 0, u, f), g.drawImage(a, 0, 0, a.width, a.height, 0, 0, u, f);
    }
    let c = null;
    if (s) {
      let u, f;
      if (r.symmetric && a.width < t && a.height < t)
        u = a.width, f = a.height;
      else if (a = this.#t, i > t || n > t) {
        const b = Math.min(t / i, t / n);
        u = Math.floor(i * b), f = Math.floor(n * b), this.#l || (a = this.#c(u, f));
      }
      const p = new OffscreenCanvas(u, f).getContext("2d", {
        willReadFrequently: !0
      });
      p.drawImage(a, 0, 0, a.width, a.height, 0, 0, u, f), c = {
        width: u,
        height: f,
        data: p.getImageData(0, 0, u, f).data
      };
    }
    return {
      canvas: h,
      width: o,
      height: l,
      imageData: c
    };
  }
  #c(t, e) {
    const {
      width: s,
      height: i
    } = this.#t;
    let n = s, r = i, a = this.#t;
    for (; n > 2 * t || r > 2 * e; ) {
      const o = n, l = r;
      n > 2 * t && (n = n >= 16384 ? Math.floor(n / 2) - 1 : Math.ceil(n / 2)), r > 2 * e && (r = r >= 16384 ? Math.floor(r / 2) - 1 : Math.ceil(r / 2));
      const h = new OffscreenCanvas(n, r);
      h.getContext("2d").drawImage(a, 0, 0, o, l, 0, 0, n, r), a = h.transferToImageBitmap();
    }
    return a;
  }
  #p() {
    const [t, e] = this.parentDimensions, {
      width: s,
      height: i
    } = this, n = new Et(), r = Math.ceil(s * t * n.sx), a = Math.ceil(i * e * n.sy), o = this.#n;
    if (!o || o.width === r && o.height === a)
      return;
    o.width = r, o.height = a;
    const l = this.#l ? this.#t : this.#c(r, a), h = o.getContext("2d");
    h.filter = this._uiManager.hcmFilter, h.drawImage(l, 0, 0, l.width, l.height, 0, 0, r, a);
  }
  #b(t) {
    if (t) {
      if (this.#l) {
        const i = this._uiManager.imageManager.getSvgUrl(this.#e);
        if (i)
          return i;
      }
      const e = document.createElement("canvas");
      return {
        width: e.width,
        height: e.height
      } = this.#t, e.getContext("2d").drawImage(this.#t, 0, 0), e.toDataURL();
    }
    if (this.#l) {
      const [e, s] = this.pageDimensions, i = Math.round(this.width * e * Ht.PDF_TO_CSS_UNITS), n = Math.round(this.height * s * Ht.PDF_TO_CSS_UNITS), r = new OffscreenCanvas(i, n);
      return r.getContext("2d").drawImage(this.#t, 0, 0, this.#t.width, this.#t.height, 0, 0, i, n), r.transferToImageBitmap();
    }
    return structuredClone(this.#t);
  }
  static async deserialize(t, e, s) {
    let i = null, n = !1;
    if (t instanceof Wi) {
      const {
        data: {
          rect: p,
          rotation: b,
          id: m,
          structParent: y,
          popupRef: A,
          richText: v,
          contentsObj: w,
          creationDate: S,
          modificationDate: E
        },
        container: _,
        parent: {
          page: {
            pageNumber: C
          }
        },
        canvas: k
      } = t;
      let x, z;
      k ? (delete t.canvas, {
        id: x,
        bitmap: z
      } = s.imageManager.getFromCanvas(_.id, k), k.remove()) : (n = !0, t._hasNoCanvas = !0);
      const W = (await e._structTree.getAriaAttributes(`${Xt}${m}`))?.get("aria-label") || "";
      i = t = {
        annotationType: F.STAMP,
        bitmapId: x,
        bitmap: z,
        pageIndex: C - 1,
        rect: p.slice(0),
        rotation: b,
        annotationElementId: m,
        id: m,
        deleted: !1,
        accessibilityData: {
          decorative: !1,
          altText: W
        },
        isSvg: !1,
        structParent: y,
        popupRef: A,
        richText: v,
        comment: w?.str || null,
        creationDate: S,
        modificationDate: E
      };
    }
    const r = await super.deserialize(t, e, s), {
      rect: a,
      bitmap: o,
      bitmapUrl: l,
      bitmapId: h,
      isSvg: c,
      accessibilityData: u
    } = t;
    n ? (s.addMissingCanvas(t.id, r), r.#o = !0) : h && s.imageManager.isValidId(h) ? (r.#e = h, o && (r.#t = o)) : r.#s = l, r.#l = c;
    const [f, g] = r.pageDimensions;
    return r.width = (a[2] - a[0]) / f, r.height = (a[3] - a[1]) / g, u && (r.altTextData = u), r._initialData = i, t.comment && r.setCommentData(t), r.#u = !!i, r;
  }
  serialize(t = !1, e = null) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const s = Object.assign(super.serialize(t), {
      bitmapId: this.#e,
      isSvg: this.#l
    });
    if (this.addComment(s), t)
      return s.bitmapUrl = this.#b(!0), s.accessibilityData = this.serializeAltText(!0), s.isCopy = !0, s;
    const {
      decorative: i,
      altText: n
    } = this.serializeAltText(!1);
    if (!i && n && (s.accessibilityData = {
      type: "Figure",
      alt: n
    }), this.annotationElementId) {
      const a = this.#y(s);
      return a.isSame ? null : (a.isSameAltText ? delete s.accessibilityData : s.accessibilityData.structParent = this._initialData.structParent ?? -1, s.id = this.annotationElementId, delete s.bitmapId, s);
    }
    if (e === null)
      return s;
    e.stamps ||= /* @__PURE__ */ new Map();
    const r = this.#l ? (s.rect[2] - s.rect[0]) * (s.rect[3] - s.rect[1]) : null;
    if (!e.stamps.has(this.#e))
      e.stamps.set(this.#e, {
        area: r,
        serialized: s
      }), s.bitmap = this.#b(!1);
    else if (this.#l) {
      const a = e.stamps.get(this.#e);
      r > a.area && (a.area = r, a.serialized.bitmap.close(), a.serialized.bitmap = this.#b(!1));
    }
    return s;
  }
  #y(t) {
    const {
      pageIndex: e,
      accessibilityData: {
        altText: s
      }
    } = this._initialData, i = t.pageIndex === e, n = (t.accessibilityData?.alt || "") === s;
    return {
      isSame: !this.hasEditedComment && !this._hasBeenMoved && !this._hasBeenResized && i && n,
      isSameAltText: n
    };
  }
  renderAnnotationElement(t) {
    return this.deleted ? (t.hide(), null) : (t.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
}
class Pt {
  #t;
  #e = !1;
  #i = null;
  #s = null;
  #a = null;
  #r = /* @__PURE__ */ new Map();
  #n = !1;
  #o = !1;
  #h = !1;
  #l = null;
  #u = null;
  #d = null;
  #f = null;
  #m = null;
  #g = -1;
  #c;
  static _initialized = !1;
  static #p = new Map([ot, Ls, Or, Z, Tt].map((t) => [t._editorType, t]));
  constructor({
    uiManager: t,
    pageIndex: e,
    div: s,
    structTreeLayer: i,
    accessibilityManager: n,
    annotationLayer: r,
    drawLayer: a,
    textLayer: o,
    viewport: l,
    l10n: h
  }) {
    const c = [...Pt.#p.values()];
    if (!Pt._initialized) {
      Pt._initialized = !0;
      for (const u of c)
        u.initialize(h, t);
    }
    t.registerEditorTypes(c), this.#c = t, this.pageIndex = e, this.div = s, this.#t = n, this.#i = r, this.viewport = l, this.#d = o, this.drawLayer = a, this._structTree = i, this.#c.addLayer(this);
  }
  updatePageIndex(t) {
    this.pageIndex = t;
  }
  get isEmpty() {
    return this.#r.size === 0;
  }
  get isInvisible() {
    return this.isEmpty && this.#c.getMode() === F.NONE;
  }
  updateToolbar(t) {
    this.#c.updateToolbar(t);
  }
  updateMode(t = this.#c.getMode()) {
    switch (this.#v(), t) {
      case F.NONE:
        this.div.classList.toggle("nonEditing", !0), this.disableTextSelection(), this.togglePointerEvents(!1), this.toggleAnnotationLayerPointerEvents(!0), this.disableClick();
        return;
      case F.INK:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
        break;
      case F.HIGHLIGHT:
        this.enableTextSelection(), this.togglePointerEvents(!1), this.disableClick();
        break;
      default:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
    }
    this.toggleAnnotationLayerPointerEvents(!1);
    const {
      classList: e
    } = this.div;
    if (e.toggle("nonEditing", !1), t === F.POPUP)
      e.toggle("commentEditing", !0);
    else {
      e.toggle("commentEditing", !1);
      for (const s of Pt.#p.values())
        e.toggle(`${s._type}Editing`, t === s._editorType);
    }
    this.div.hidden = !1;
  }
  hasTextLayer(t) {
    return t === this.#d?.div;
  }
  setEditingState(t) {
    this.#c.setEditingState(t);
  }
  addCommands(t) {
    this.#c.addCommands(t);
  }
  cleanUndoStack(t) {
    this.#c.cleanUndoStack(t);
  }
  toggleDrawing(t = !1) {
    this.div.classList.toggle("drawing", !t);
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  toggleAnnotationLayerPointerEvents(t = !1) {
    this.#i?.togglePointerEvents(t);
  }
  get #b() {
    return this.#r.size !== 0 ? this.#r.values() : this.#c.getEditors(this.pageIndex);
  }
  async enable() {
    this.#h = !0, this.div.tabIndex = 0, this.togglePointerEvents(!0), this.div.classList.toggle("nonEditing", !1), this.#m?.abort(), this.#m = null;
    const t = /* @__PURE__ */ new Set();
    for (const s of this.#b)
      s.enableEditing(), s.show(!0), s.annotationElementId && (this.#c.removeChangedExistingAnnotation(s), t.add(s.annotationElementId));
    const e = this.#i;
    if (e)
      for (const s of e.getEditableAnnotations()) {
        if (s.hide(), this.#c.isDeletedAnnotationElement(s.data.id) || t.has(s.data.id))
          continue;
        const i = await this.deserialize(s);
        i && (this.addOrRebuild(i), i.enableEditing());
      }
    this.#h = !1, this.#c._eventBus.dispatch("editorsrendered", {
      source: this,
      pageNumber: this.pageIndex + 1
    });
  }
  disable() {
    if (this.#o = !0, this.div.tabIndex = -1, this.togglePointerEvents(!1), this.div.classList.toggle("nonEditing", !0), this.#d && !this.#m) {
      this.#m = new AbortController();
      const i = this.#c.combinedSignal(this.#m);
      this.#d.div.addEventListener("pointerdown", (n) => {
        const {
          clientX: a,
          clientY: o,
          timeStamp: l
        } = n, h = this.#g;
        if (l - h > 500) {
          this.#g = l;
          return;
        }
        this.#g = -1;
        const {
          classList: c
        } = this.div;
        c.toggle("getElements", !0);
        const u = document.elementsFromPoint(a, o);
        if (c.toggle("getElements", !1), !this.div.contains(u[0]))
          return;
        let f;
        const g = new RegExp(`^${pe}[0-9]+$`);
        for (const b of u)
          if (g.test(b.id)) {
            f = b.id;
            break;
          }
        if (!f)
          return;
        const p = this.#r.get(f);
        p?.annotationElementId === null && (n.stopPropagation(), n.preventDefault(), p.dblclick(n));
      }, {
        signal: i,
        capture: !0
      });
    }
    const t = this.#i, e = [];
    if (t) {
      const i = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
      for (const a of this.#b) {
        if (a.disableEditing(), !a.annotationElementId) {
          e.push(a);
          continue;
        }
        if (a.serialize() !== null) {
          i.set(a.annotationElementId, a);
          continue;
        } else
          n.set(a.annotationElementId, a);
        this.getEditableAnnotation(a.annotationElementId)?.show(), a.remove();
      }
      const r = t.getEditableAnnotations();
      for (const a of r) {
        const {
          id: o
        } = a.data;
        if (this.#c.isDeletedAnnotationElement(o)) {
          a.updateEdited({
            deleted: !0
          });
          continue;
        }
        let l = n.get(o);
        if (l) {
          l.resetAnnotationElement(a), l.show(!1), a.show();
          continue;
        }
        l = i.get(o), l && (this.#c.addChangedExistingAnnotation(l), l.renderAnnotationElement(a) && l.show(!1)), a.show();
      }
    }
    this.#v(), this.isEmpty && (this.div.hidden = !0);
    const {
      classList: s
    } = this.div;
    for (const i of Pt.#p.values())
      s.remove(`${i._type}Editing`);
    this.disableTextSelection(), this.toggleAnnotationLayerPointerEvents(!0), t?.updateFakeAnnotations(e), this.#o = !1;
  }
  getEditableAnnotation(t) {
    return this.#i?.getEditableAnnotation(t) || null;
  }
  setActiveEditor(t) {
    this.#c.getActive() !== t && this.#c.setActiveEditor(t);
  }
  enableTextSelection() {
    if (this.div.tabIndex = -1, this.#d?.div && !this.#f) {
      this.#f = new AbortController();
      const t = this.#c.combinedSignal(this.#f);
      this.#d.div.addEventListener("pointerdown", this.#y.bind(this), {
        signal: t
      }), this.#d.div.classList.add("highlighting");
    }
  }
  disableTextSelection() {
    this.div.tabIndex = 0, this.#d?.div && this.#f && (this.#f.abort(), this.#f = null, this.#d.div.classList.remove("highlighting"));
  }
  #y(t) {
    this.#c.unselectAll();
    const {
      target: e
    } = t;
    if (e === this.#d.div || (e.getAttribute("role") === "img" || e.classList.contains("endOfContent")) && this.#d.div.contains(e)) {
      const {
        isMac: s
      } = nt.platform;
      if (t.button !== 0 || t.ctrlKey && s)
        return;
      this.#c.showAllEditors("highlight", !0, !0), this.#d.div.classList.add("free"), this.toggleDrawing(), Z.startHighlighting(this, this.#c.direction === "ltr", {
        target: this.#d.div,
        x: t.x,
        y: t.y
      }), this.#d.div.addEventListener("pointerup", () => {
        this.#d.div.classList.remove("free"), this.toggleDrawing(!0);
      }, {
        once: !0,
        signal: this.#c._signal
      }), t.preventDefault();
    }
  }
  enableClick() {
    if (this.#s)
      return;
    this.#s = new AbortController();
    const t = this.#c.combinedSignal(this.#s);
    this.div.addEventListener("pointerdown", this.pointerdown.bind(this), {
      signal: t
    });
    const e = this.pointerup.bind(this);
    this.div.addEventListener("pointerup", e, {
      signal: t
    }), this.div.addEventListener("pointercancel", e, {
      signal: t
    });
  }
  disableClick() {
    this.#s?.abort(), this.#s = null;
  }
  attach(t) {
    this.#r.set(t.id, t);
    const {
      annotationElementId: e
    } = t;
    e && this.#c.isDeletedAnnotationElement(e) && this.#c.removeDeletedAnnotationElement(t);
  }
  detach(t) {
    this.#r.delete(t.id), this.#t?.removePointerInTextLayer(t.contentDiv), !this.#o && t.annotationElementId && this.#c.addDeletedAnnotationElement(t);
  }
  remove(t) {
    this.detach(t), this.#c.removeEditor(t), t.div.remove(), t.isAttachedToDOM = !1;
  }
  changeParent(t) {
    t.parent !== this && (t.parent && t.annotationElementId && (this.#c.addDeletedAnnotationElement(t), D.deleteAnnotationElement(t), t.annotationElementId = null), this.attach(t), t.parent?.detach(t), t.setParent(this), t.div && t.isAttachedToDOM && (t.div.remove(), this.div.append(t.div)));
  }
  add(t) {
    if (!(t.parent === this && t.isAttachedToDOM)) {
      if (this.changeParent(t), this.#c.addEditor(t), this.attach(t), !t.isAttachedToDOM) {
        const e = t.render();
        this.div.append(e), t.isAttachedToDOM = !0;
      }
      t.fixAndSetPosition(), t.onceAdded(!this.#h), this.#c.addToAnnotationStorage(t), t._reportTelemetry(t.telemetryInitialData);
    }
  }
  moveEditorInDOM(t) {
    if (!t.isAttachedToDOM)
      return;
    const {
      activeElement: e
    } = document;
    t.div.contains(e) && !this.#a && (t._focusEventsAllowed = !1, this.#a = setTimeout(() => {
      this.#a = null, t.div.contains(document.activeElement) ? t._focusEventsAllowed = !0 : (t.div.addEventListener("focusin", () => {
        t._focusEventsAllowed = !0;
      }, {
        once: !0,
        signal: this.#c._signal
      }), e.focus());
    }, 0)), t._structTreeParentId = this.#t?.moveElementInDOM(this.div, t.div, t.contentDiv, !0);
  }
  addOrRebuild(t) {
    t.needsToBeRebuilt() ? (t.parent ||= this, t.rebuild(), t.show()) : this.add(t);
  }
  addUndoableEditor(t) {
    const e = () => t._uiManager.rebuild(t), s = () => {
      t.remove();
    };
    this.addCommands({
      cmd: e,
      undo: s,
      mustExec: !1
    });
  }
  getEditorByUID(t) {
    for (const e of this.#r.values())
      if (e.uid === t)
        return e;
    return null;
  }
  getNextId() {
    return this.#c.getId();
  }
  get #A() {
    return Pt.#p.get(this.#c.getMode());
  }
  combinedSignal(t) {
    return this.#c.combinedSignal(t);
  }
  #C(t) {
    const e = this.#A;
    return e ? new e.prototype.constructor(t) : null;
  }
  canCreateNewEmptyEditor() {
    return this.#A?.canCreateNewEmptyEditor();
  }
  async pasteEditor(t, e) {
    this.updateToolbar(t), await this.#c.updateMode(t.mode);
    const {
      offsetX: s,
      offsetY: i
    } = this.#E(), n = this.getNextId(), r = this.#C({
      parent: this,
      id: n,
      x: s,
      y: i,
      uiManager: this.#c,
      isCentered: !0,
      ...e
    });
    r && this.add(r);
  }
  async deserialize(t) {
    return await Pt.#p.get(t.annotationType ?? t.annotationEditorType)?.deserialize(t, this, this.#c) || null;
  }
  createAndAddNewEditor(t, e, s = {}) {
    const i = this.getNextId(), n = this.#C({
      parent: this,
      id: i,
      x: t.offsetX,
      y: t.offsetY,
      uiManager: this.#c,
      isCentered: e,
      ...s
    });
    return n && this.add(n), n;
  }
  get boundingClientRect() {
    return this.div.getBoundingClientRect();
  }
  #E() {
    const {
      x: t,
      y: e,
      width: s,
      height: i
    } = this.boundingClientRect, n = Math.max(0, t), r = Math.max(0, e), a = Math.min(window.innerWidth, t + s), o = Math.min(window.innerHeight, e + i), l = (n + a) / 2 - t, h = (r + o) / 2 - e, [c, u] = this.viewport.rotation % 180 === 0 ? [l, h] : [h, l];
    return {
      offsetX: c,
      offsetY: u
    };
  }
  addNewEditor(t = {}) {
    this.createAndAddNewEditor(this.#E(), !0, t);
  }
  setSelected(t) {
    this.#c.setSelected(t);
  }
  toggleSelected(t) {
    this.#c.toggleSelected(t);
  }
  unselect(t) {
    this.#c.unselect(t);
  }
  pointerup(t) {
    const {
      isMac: e
    } = nt.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div || !this.#n || (this.#n = !1, this.#A?.isDrawer && this.#A.supportMultipleDrawings))
      return;
    if (!this.#e) {
      this.#e = !0;
      return;
    }
    const s = this.#c.getMode();
    if (s === F.STAMP || s === F.SIGNATURE) {
      this.#c.unselectAll();
      return;
    }
    this.createAndAddNewEditor(t, !1);
  }
  pointerdown(t) {
    if (this.#c.getMode() === F.HIGHLIGHT && this.enableTextSelection(), this.#n) {
      this.#n = !1;
      return;
    }
    const {
      isMac: e
    } = nt.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div)
      return;
    if (this.#n = !0, this.#A?.isDrawer) {
      this.startDrawingSession(t);
      return;
    }
    const s = this.#c.getActive();
    this.#e = !s || s.isEmpty();
  }
  startDrawingSession(t) {
    if (this.div.focus({
      preventScroll: !0
    }), this.#l) {
      this.#A.startDrawing(this, this.#c, !1, t);
      return;
    }
    this.#c.setCurrentDrawingSession(this), this.#l = new AbortController();
    const e = this.#c.combinedSignal(this.#l);
    this.div.addEventListener("blur", ({
      relatedTarget: s
    }) => {
      s && !this.div.contains(s) && (this.#u = null, this.commitOrRemove());
    }, {
      signal: e
    }), this.#A.startDrawing(this, this.#c, !1, t);
  }
  pause(t) {
    if (t) {
      const {
        activeElement: e
      } = document;
      this.div.contains(e) && (this.#u = e);
      return;
    }
    this.#u && setTimeout(() => {
      this.#u?.focus(), this.#u = null;
    }, 0);
  }
  endDrawingSession(t = !1) {
    return this.#l ? (this.#c.setCurrentDrawingSession(null), this.#l.abort(), this.#l = null, this.#u = null, this.#A.endDrawing(t)) : null;
  }
  findNewParent(t, e, s) {
    const i = this.#c.findParent(e, s);
    return i === null || i === this ? !1 : (i.changeParent(t), !0);
  }
  commitOrRemove() {
    return this.#l ? (this.endDrawingSession(), !0) : !1;
  }
  onScaleChanging() {
    this.#l && this.#A.onScaleChangingWhenDrawing(this);
  }
  destroy() {
    this.commitOrRemove(), this.#c.getActive()?.parent === this && (this.#c.commitOrRemove(), this.#c.setActiveEditor(null)), this.#a && (clearTimeout(this.#a), this.#a = null);
    for (const t of this.#r.values())
      this.#t?.removePointerInTextLayer(t.contentDiv), t.setParent(null), t.isAttachedToDOM = !1, t.div.remove();
    this.div = null, this.#r.clear(), this.#c.removeLayer(this);
  }
  #v() {
    for (const t of this.#r.values())
      t.isEmpty() && t.remove();
  }
  render({
    viewport: t
  }) {
    this.viewport = t, Nt(this.div, t);
    for (const e of this.#c.getEditors(this.pageIndex))
      this.add(e), e.rebuild();
    this.updateMode();
  }
  update({
    viewport: t
  }) {
    this.#c.commitOrRemove(), this.#v();
    const e = this.viewport.rotation, s = t.rotation;
    if (this.viewport = t, Nt(this.div, {
      rotation: s
    }), e !== s)
      for (const i of this.#r.values())
        i.rotate(s);
  }
  get pageDimensions() {
    const {
      pageWidth: t,
      pageHeight: e
    } = this.viewport.rawDims;
    return [t, e];
  }
  get scale() {
    return this.#c.viewParameters.realScale;
  }
}
class lt {
  #t = null;
  #e = /* @__PURE__ */ new Map();
  #i = /* @__PURE__ */ new Map();
  static #s = 0;
  setParent(t) {
    if (!this.#t) {
      this.#t = t;
      return;
    }
    if (this.#t !== t) {
      if (this.#e.size > 0)
        for (const e of this.#e.values())
          e.remove(), t.append(e);
      this.#t = t;
    }
  }
  static get _svgFactory() {
    return I(this, "_svgFactory", new Ae());
  }
  static #a(t, [e, s, i, n]) {
    const {
      style: r
    } = t;
    r.top = `${100 * s}%`, r.left = `${100 * e}%`, r.width = `${100 * i}%`, r.height = `${100 * n}%`;
  }
  #r() {
    const t = lt._svgFactory.create(1, 1, !0);
    return this.#t.append(t), t.setAttribute("aria-hidden", !0), t;
  }
  #n(t, e) {
    const s = lt._svgFactory.createElement("clipPath");
    t.append(s);
    const i = `clip_${e}`;
    s.setAttribute("id", i), s.setAttribute("clipPathUnits", "objectBoundingBox");
    const n = lt._svgFactory.createElement("use");
    return s.append(n), n.setAttribute("href", `#${e}`), n.classList.add("clip"), i;
  }
  #o(t, e) {
    for (const [s, i] of Object.entries(e))
      i === null ? t.removeAttribute(s) : t.setAttribute(s, i);
  }
  draw(t, e = !1, s = !1) {
    const i = lt.#s++, n = this.#r(), r = lt._svgFactory.createElement("defs");
    n.append(r);
    const a = lt._svgFactory.createElement("path");
    r.append(a);
    const o = `path_${i}`;
    a.setAttribute("id", o), a.setAttribute("vector-effect", "non-scaling-stroke"), e && this.#i.set(i, a);
    const l = s ? this.#n(r, o) : null, h = lt._svgFactory.createElement("use");
    return n.append(h), h.setAttribute("href", `#${o}`), this.updateProperties(n, t), this.#e.set(i, n), {
      id: i,
      clipPathId: `url(#${l})`
    };
  }
  drawOutline(t, e) {
    const s = lt.#s++, i = this.#r(), n = lt._svgFactory.createElement("defs");
    i.append(n);
    const r = lt._svgFactory.createElement("path");
    n.append(r);
    const a = `path_${s}`;
    r.setAttribute("id", a), r.setAttribute("vector-effect", "non-scaling-stroke");
    let o;
    if (e) {
      const c = lt._svgFactory.createElement("mask");
      n.append(c), o = `mask_${s}`, c.setAttribute("id", o), c.setAttribute("maskUnits", "objectBoundingBox");
      const u = lt._svgFactory.createElement("rect");
      c.append(u), u.setAttribute("width", "1"), u.setAttribute("height", "1"), u.setAttribute("fill", "white");
      const f = lt._svgFactory.createElement("use");
      c.append(f), f.setAttribute("href", `#${a}`), f.setAttribute("stroke", "none"), f.setAttribute("fill", "black"), f.setAttribute("fill-rule", "nonzero"), f.classList.add("mask");
    }
    const l = lt._svgFactory.createElement("use");
    i.append(l), l.setAttribute("href", `#${a}`), o && l.setAttribute("mask", `url(#${o})`);
    const h = l.cloneNode();
    return i.append(h), l.classList.add("mainOutline"), h.classList.add("secondaryOutline"), this.updateProperties(i, t), this.#e.set(s, i), s;
  }
  finalizeDraw(t, e) {
    this.#i.delete(t), this.updateProperties(t, e);
  }
  updateProperties(t, e) {
    if (!e)
      return;
    const {
      root: s,
      bbox: i,
      rootClass: n,
      path: r
    } = e, a = typeof t == "number" ? this.#e.get(t) : t;
    if (a) {
      if (s && this.#o(a, s), i && lt.#a(a, i), n) {
        const {
          classList: o
        } = a;
        for (const [l, h] of Object.entries(n))
          o.toggle(l, h);
      }
      if (r) {
        const l = a.firstElementChild.firstElementChild;
        this.#o(l, r);
      }
    }
  }
  updateParent(t, e) {
    if (e === this)
      return;
    const s = this.#e.get(t);
    s && (e.#t.append(s), this.#e.delete(t), e.#e.set(t, s));
  }
  remove(t) {
    this.#i.delete(t), this.#t !== null && (this.#e.get(t).remove(), this.#e.delete(t));
  }
  destroy() {
    this.#t = null;
    for (const t of this.#e.values())
      t.remove();
    this.#e.clear(), this.#i.clear();
  }
}
globalThis._pdfjsTestingUtils = {
  HighlightOutliner: ps
};
globalThis.pdfjsLib = {
  AbortException: Lt,
  AnnotationEditorLayer: Pt,
  AnnotationEditorParamsType: N,
  AnnotationEditorType: F,
  AnnotationEditorUIManager: It,
  AnnotationLayer: Ye,
  AnnotationMode: Dt,
  AnnotationType: J,
  applyOpacity: bi,
  build: $i,
  ColorPicker: At,
  createValidAbsoluteUrl: bs,
  CSSConstants: mi,
  DOMSVGFactory: Ae,
  DrawLayer: lt,
  FeatureTest: nt,
  fetchData: ee,
  findContrastColor: Ai,
  getDocument: Ui,
  getFilenameFromUrl: fi,
  getPdfFilenameFromUrl: pi,
  getRGB: se,
  getUuid: ys,
  getXfaPageViewport: gi,
  GlobalWorkerOptions: Zt,
  ImageKind: ue,
  InvalidPDFException: Re,
  isDataScheme: ve,
  isPdfFile: je,
  isValidExplicitDest: Ei,
  MathClamp: ct,
  noContextMenu: wt,
  normalizeUnicode: ui,
  OPS: te,
  OutputScale: Et,
  PagesMapper: B,
  PasswordResponses: di,
  PDFDataRangeTransport: ks,
  PDFDateString: Fe,
  PDFWorker: ht,
  PermissionFlag: ci,
  PixelsPerInch: Ht,
  RenderingCancelledException: $e,
  renderRichText: vs,
  ResponseException: ge,
  setLayerDimensions: Nt,
  shadow: I,
  SignatureExtractor: Bt,
  stopEvent: K,
  SupportedImageMimeTypes: Ne,
  TextLayer: gt,
  TouchManager: Ee,
  updateUrlHash: As,
  Util: T,
  VerbosityLevel: ye,
  version: Hi,
  XfaLayer: ws
};
const Br = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AbortException: Lt,
  AnnotationEditorLayer: Pt,
  AnnotationEditorParamsType: N,
  AnnotationEditorType: F,
  AnnotationEditorUIManager: It,
  AnnotationLayer: Ye,
  AnnotationMode: Dt,
  AnnotationType: J,
  CSSConstants: mi,
  ColorPicker: At,
  DOMSVGFactory: Ae,
  DrawLayer: lt,
  FeatureTest: nt,
  GlobalWorkerOptions: Zt,
  ImageKind: ue,
  InvalidPDFException: Re,
  MathClamp: ct,
  OPS: te,
  OutputScale: Et,
  PDFDataRangeTransport: ks,
  PDFDateString: Fe,
  PDFWorker: ht,
  PagesMapper: B,
  PasswordResponses: di,
  PermissionFlag: ci,
  PixelsPerInch: Ht,
  RenderingCancelledException: $e,
  ResponseException: ge,
  SignatureExtractor: Bt,
  SupportedImageMimeTypes: Ne,
  TextLayer: gt,
  TouchManager: Ee,
  Util: T,
  VerbosityLevel: ye,
  XfaLayer: ws,
  applyOpacity: bi,
  build: $i,
  createValidAbsoluteUrl: bs,
  fetchData: ee,
  findContrastColor: Ai,
  getDocument: Ui,
  getFilenameFromUrl: fi,
  getPdfFilenameFromUrl: pi,
  getRGB: se,
  getUuid: ys,
  getXfaPageViewport: gi,
  isDataScheme: ve,
  isPdfFile: je,
  isValidExplicitDest: Ei,
  noContextMenu: wt,
  normalizeUnicode: ui,
  renderRichText: vs,
  setLayerDimensions: Nt,
  shadow: I,
  stopEvent: K,
  updateUrlHash: As,
  version: Hi
}, Symbol.toStringTag, { value: "Module" }));
export {
  Br as default
};
//# sourceMappingURL=pdfjs.js.map
