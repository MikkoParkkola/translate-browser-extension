function e(n){return{debug:(o,...r)=>console.log(`[${n}]`,o,...r),info:(o,...r)=>console.log(`[${n}]`,o,...r),warn:(o,...r)=>console.warn(`[${n}]`,o,...r),error:(o,...r)=>console.error(`[${n}]`,o,...r)}}export{e as c};
//# sourceMappingURL=logger-B_opVjnm.js.map
