import{c as o}from"./logger-B_opVjnm.js";const t=typeof browser<"u"?browser:chrome,a=o("Storage");async function n(r){try{return await t.storage.local.get(r)}catch(e){return a.warn("Storage get failed:",e),{}}}async function c(r){try{return await t.storage.local.set(r),!0}catch(e){return a.warn("Storage set failed:",e),!1}}export{c as a,t as b,n as s};
//# sourceMappingURL=storage-CL8XEX39.js.map
